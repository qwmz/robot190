'use strict';
/* زبان رفتار ربات: هوش مصنوعی یک «برنامه‌ی JSON» می‌نویسد، این ماژول آن را اعتبارسنجی، اجرا و به فارسی توصیف می‌کند.
   هیچ کد دلخواهی اجرا نمی‌شود: فقط آجرهای فهرست زیر، با عمق و اندازه و بازه‌ی عددی محدود.
   هم در Node (سرور و تست) و هم در مرورگر (window.Behavior) کار می‌کند. زمان‌ها به ثانیه‌اند (۶۰ تیک در ثانیه). */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.Behavior=factory();})(typeof self!=='undefined'?self:this,function(){
const TPS=60,MAX_NODES=80,MAX_DEPTH=9,MAX_STEPS=16,MAX_STATES=10,MAX_VARS=8;
const has=(o,k)=>typeof k==='string'&&Object.prototype.hasOwnProperty.call(o,k);
const num=(v,lo,hi,d)=>{const n=Number(v);return Number.isFinite(n)?Math.min(hi,Math.max(lo,n)):d;};
const name=v=>typeof v==='string'&&/^[a-z_][a-z0-9_]{0,15}$/i.test(v)?v:null;

/* ---------- حسگرها: [توضیح، نوع (n عدد، b درست/نادرست)، پارامتر r] ---------- */
const SENSORS={
 hp:{fa:'جان من (٪)',t:'n'},
 dist_nearest:{fa:'فاصله تا نزدیک‌ترین دشمن',t:'n'},
 enemies:{fa:'تعداد دشمن‌های دیده‌شده',t:'n'},
 enemies_within:{fa:'تعداد دشمن در شعاع r',t:'n',r:[50,1200,450]},
 enemy_hp:{fa:'جان نزدیک‌ترین دشمن (٪)',t:'n'},
 x_pct:{fa:'جای افقی من در زمین (٪ از چپ)',t:'n'},
 y_pct:{fa:'جای عمودی من در زمین (٪ از بالا)',t:'n'},
 wall_dist:{fa:'فاصله تا نزدیک‌ترین دیوار یا مانع',t:'n'},
 time:{fa:'ثانیه‌ی گذشته از شروع',t:'n'},
 still_time:{fa:'چند ثانیه است که تکان نخورده‌ام',t:'n'},
 hit:{fa:'در یک ثانیه‌ی اخیر آسیب دیدم',t:'b'},
 bullet:{fa:'گلوله‌ای به‌سمتم می‌آید',t:'b'},
 exposed:{fa:'دشمن مرا می‌بیند',t:'b'},
 runner:{fa:'دشمن تندرو دیده می‌شود',t:'b'},
 spitter:{fa:'دشمن تیرانداز دیده می‌شود',t:'b'},
 brute:{fa:'دشمن غول دیده می‌شود',t:'b'},
 cubes:{fa:'تعداد انرژی‌های باقی‌مانده',t:'n'},
 dist_cube:{fa:'فاصله تا نزدیک‌ترین انرژی',t:'n'},
 chest:{fa:'صندوق گنج سالم در زمین هست',t:'b'},
 dist_chest:{fa:'فاصله تا صندوق گنج',t:'n'},
 safe_cube:{fa:'انرژیی هست که ربات دیگری نزدیکش نیست',t:'b'},
 dist_safe_cube:{fa:'فاصله تا نزدیک‌ترین انرژیِ بدون ربات نزدیک',t:'n'},
 power:{fa:'قدرت من (۱ + تعداد انرژی‌هایی که برداشته‌ام)',t:'n'},
 enemy_power:{fa:'قدرت نزدیک‌ترین ربات دشمن',t:'n'},
 robots_left:{fa:'تعداد ربات‌های زنده در زمین (با خودم)',t:'n'},
 var:{fa:'متغیر شمارنده',t:'n',name:1}};
const OPS={'<':(a,b)=>a<b,'<=':(a,b)=>a<=b,'>':(a,b)=>a>b,'>=':(a,b)=>a>=b,'==':(a,b)=>a===b,'!=':(a,b)=>a!==b};
const DIRS={up:0,right:90,down:180,left:270};
const PICKS={nearest:'نزدیک‌ترین',farthest:'دورترین',weakest:'ضعیف‌ترین',strongest:'قوی‌ترین',runner:'تندروها',spitter:'تیراندازها',brute:'غول‌ها',chest:'صندوق گنج'};
const POINTS={center:'مرکز زمین',start:'جای شروع',nearest:'نزدیک‌ترین دشمن',farthest:'دورترین دشمن',top:'بالای زمین',bottom:'پایین زمین',left:'چپ زمین',right:'راست زمین',gem:'انرژی',cube:'نزدیک‌ترین انرژی',safe_cube:'نزدیک‌ترین انرژیِ بدون ربات نزدیک',chest:'صندوق گنج'};
const LEGACY={cover:'پشت مانع پناه بگیر',breakout:'از محاصره بیرون بزن',go_safest:'به امن‌ترین جای نزدیک برو',go_empty_side:'به سمت خلوت‌تر برو'};

const kids=n=>{const r=[];if(n.steps)n.steps.forEach(x=>r.push(x.n));if(n.then)r.push(n.then);if(n.else)r.push(n.else);if(n.s)Object.values(n.s).forEach(x=>r.push(x.n));return r;};
const walk=(n,f)=>{if(!n||typeof n!=='object')return;f(n);kids(n).forEach(c=>walk(c,f));};
const LAYERS=['move','target','fire'],MOVERS=['go','goto','orbit','ellipse','keep','flee','legacy'];
/* ---------- اعتبارسنجی: هر چیز ناشناخته حذف یا خطا می‌شود ---------- */
function compile(input){
 const errors=[];let count=0;
 const err=m=>{if(errors.length<12)errors.push(m);};
 function value(v){return num(v,-1e5,1e5,0);}
 function cond(c,d){
  if(!c||typeof c!=='object'||Array.isArray(c)||d>MAX_DEPTH){err('شرط نامعتبر');return null;}
  if(c.all||c.any){const key=c.all?'all':'any',list=(Array.isArray(c[key])?c[key]:[]).slice(0,6).map(x=>cond(x,d+1)).filter(Boolean);return list.length?{[key]:list}:null;}
  if(c.not){const x=cond(c.not,d+1);return x?{not:x}:null;}
  if(c.always===true)return{always:true};
  if(!has(SENSORS,c.s)){err('حسگر ناشناخته: '+String(c.s).slice(0,20));return null;}
  const S=SENSORS[c.s],o={s:c.s};
  if(S.r)o.r=Math.round(num(c.r,S.r[0],S.r[1],S.r[2]));
  if(S.name){const nm=name(c.name);if(!nm){err('نام متغیر نامعتبر');return null;}o.name=nm;}
  if(S.t==='b'){o.op='==';o.v=c.op==='!='||c.v===false?0:1;return o;}
  if(!has(OPS,c.op)){err('مقایسه‌ی نامعتبر برای '+c.s);return null;}
  o.op=c.op;o.v=value(c.v);return o;}
 function effects(e){if(!e||typeof e!=='object')return undefined;const o={};let n=0;
  for(const k of Object.keys(e)){if(n>=MAX_VARS)break;const nm=name(k);if(!nm)continue;const v=e[k];
   if(typeof v==='number')o[nm]={set:value(v)};else if(v&&typeof v==='object'&&typeof v.add==='number')o[nm]={add:num(v.add,-1000,1000,1)};else continue;n++;}
  return n?o:undefined;}
 function point(n,o){// نقطه‌ی هدف: نام آماده یا کسری از زمین
  if(has(POINTS,n.to))o.to=n.to;else if(n.x!==undefined||n.y!==undefined){o.x=num(n.x,0,1,.5);o.y=num(n.y,0,1,.5);}else return false;return true;}
 function node(n,d){
  if(typeof n==='string')n=nodeFromString(n);
  if(!n||typeof n!=='object'||Array.isArray(n)){err('گره نامعتبر');return null;}
  if(d>MAX_DEPTH){err('برنامه بیش‌ازحد تو در تو است');return null;}
  if(++count>MAX_NODES){err('برنامه بیش‌ازحد بزرگ است');return null;}
  const o={k:n.k};
  switch(n.k){
   case 'seq':{const steps=[];for(const s of(Array.isArray(n.steps)?n.steps:[]).slice(0,MAX_STEPS)){
     if(!s||typeof s!=='object')continue;const c=node(s.n,d+1);if(!c)continue;const st={n:c};
     if(s.t!==undefined)st.t=num(s.t,0,3600,1);if(s.until){const u=cond(s.until,d+1);if(u)st.until=u;}if(s.reach===true)st.reach=true;
     if(st.t===undefined&&!st.until&&!st.reach)st.t=1;const e=effects(s.set);if(e)st.set=e;steps.push(st);}
    if(!steps.length){err('دنباله خالی است');return null;}o.steps=steps;o.loop=n.loop===true;return o;}
   case 'if':{const c=cond(n.c,d+1);if(!c)return null;o.c=c;const a=n.then!==undefined?node(n.then,d+1):null,b=n.else!==undefined?node(n.else,d+1):null;
    if(!a&&!b){err('شرط بدون کار');return null;}if(a)o.then=a;if(b)o.else=b;return o;}
   case 'states':{const src=n.s&&typeof n.s==='object'?n.s:{},keys=Object.keys(src).map(name).filter(Boolean).slice(0,MAX_STATES);
    if(!keys.length){err('حالتی تعریف نشده');return null;}o.s={};
    for(const k of keys){const st=src[k];if(!st||typeof st!=='object')continue;const c=node(st.n,d+1);if(!c)continue;const e={n:c,to:[]};
     for(const t of(Array.isArray(st.to)?st.to:[]).slice(0,6)){const cc=cond(t.c,d+1);const go=name(t.go);if(cc&&go&&keys.includes(go)){const x={c:cc,go};const ef=effects(t.set);if(ef)x.set=ef;e.to.push(x);}}
     o.s[k]=e;}
    o.start=keys.includes(n.start)?n.start:keys[0];if(!o.s[o.start]){err('حالت شروع نامعتبر');return null;}return o;}
   case 'go':{if(typeof n.dir==='number')o.dir=((n.dir%360)+360)%360;else if(has(DIRS,n.dir)||n.dir==='toward'||n.dir==='away')o.dir=n.dir;else{err('جهت نامعتبر');return null;}
    o.spd=num(n.spd,.2,1.2,1);return o;}
   case 'goto':{if(!point(n,o)){err('مقصد نامعتبر');return null;}o.spd=num(n.spd,.2,1.2,1);return o;}
   case 'orbit':{o.around=has(POINTS,n.around)?n.around:'nearest';o.r=Math.round(num(n.r,40,900,260));o.cw=n.cw!==false;o.spd=num(n.spd,.2,1.2,1);return o;}
   case 'ellipse':{o.around=has(POINTS,n.around)?n.around:'nearest';o.a=Math.round(num(n.a,60,900,380));o.b=Math.round(num(n.b,40,700,180));o.cw=n.cw!==false;o.spd=num(n.spd,.2,1.2,1);return o;}
   case 'keep':{o.dist=Math.round(num(n.dist,60,700,230));return o;}
   case 'flee':case 'stop':return o;
   case 'legacy':{if(!has(LEGACY,n.a)){err('کار ناشناخته');return null;}o.a=n.a;return o;}
   case 'pick':{if(!has(PICKS,n.who)){err('انتخاب هدف نامعتبر');return null;}o.who=n.who;return o;}
   case 'fire':{o.on=n.on!==false;o.range=Math.round(num(n.range,100,900,680));return o;}
   default:err('نوع گره ناشناخته: '+String(n.k).slice(0,20));return null;}}
 function nodeFromString(s){return has(PICKS,s)?{k:'pick',who:s}:s==='always'?{k:'fire',on:true}:s==='never'?{k:'fire',on:false}:null;}
 const prog={};
 if(!input||typeof input!=='object'||Array.isArray(input))return{ok:false,errors:['برنامه باید یک شیء باشد'],prog:null};
 for(const layer of LAYERS){if(input[layer]===undefined||input[layer]===null)continue;const n=node(input[layer],0);if(n)prog[layer]=n;}
 if(typeof input.say==='string')prog.say=input.say.replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,200);
 if(!prog.move&&!prog.target&&!prog.fire){err('برنامه هیچ کاری نمی‌کند');return{ok:false,errors,prog:null};}
 let id=0;for(const l of LAYERS)walk(prog[l],n=>{n.id=++id;});
 return{ok:true,errors,prog};
}

/* ---------- اجرا ---------- */
function subtree(n,acc){walk(n,x=>acc.push(x.id));return acc;}
function runner(prog){
 const rt={},vars={},subs={};
 for(const l of LAYERS)walk(prog[l],n=>{subs[n.id]=subtree(n,[]);});
 const reset=n=>{for(const i of subs[n.id]||[])delete rt[i];};
 const apply=e=>{if(!e)return;for(const k of Object.keys(e)){const f=e[k];vars[k]=f.set!==undefined?f.set:(vars[k]||0)+f.add;}};
 function check(c,x){
  if(c.always)return true;if(c.all)return c.all.every(y=>check(y,x));if(c.any)return c.any.some(y=>check(y,x));if(c.not)return!check(c.not,x);
  const v=c.s==='var'?(vars[c.name]||0):x.sensor(c.s,c.r);const a=typeof v==='boolean'?(v?1:0):Number(v)||0;return OPS[c.op](a,c.v);}
 function run(n,x){
  switch(n.k){
   case 'if':{const b=check(n.c,x)?n.then:n.else;return b?run(b,x):null;}
   case 'seq':{let st=rt[n.id];if(!st){st=rt[n.id]={i:0,t0:x.tick,en:false};}
    for(let guard=0;guard<n.steps.length+1;guard++){const s=n.steps[st.i];if(!st.en){st.en=true;st.t0=x.tick;apply(s.set);}
     let end=false;if(s.t!==undefined&&x.tick-st.t0>=s.t*TPS)end=true;if(s.until&&check(s.until,x))end=true;
     if(s.reach&&s.n.k==='goto'&&x.reached&&x.reached(pointOf(s.n,x)))end=true;
     if(!end)return run(s.n,x);
     if(st.i<n.steps.length-1){reset(s.n);st.i++;st.en=false;}else if(n.loop){reset(s.n);st.i=0;st.en=false;}else return run(s.n,x);}
    return null;}
   case 'states':{let st=rt[n.id];if(!st){st=rt[n.id]={cur:n.start,t0:x.tick};}
    for(const t of n.s[st.cur].to){if(check(t.c,x)){reset(n.s[st.cur].n);apply(t.set);st.cur=t.go;st.t0=x.tick;break;}}
    x.stateTime=(x.tick-st.t0)/TPS;return run(n.s[st.cur].n,x);}
   case 'go':return{kind:'go',dir:n.dir,spd:n.spd};
   case 'goto':return{kind:'goto',...pointOf(n,x),spd:n.spd};
   case 'orbit':return{kind:'orbit',around:n.around,r:n.r,cw:n.cw,spd:n.spd};
   case 'ellipse':return{kind:'ellipse',around:n.around,a:n.a,b:n.b,cw:n.cw,spd:n.spd};
   case 'keep':return{kind:'keep',dist:n.dist};
   case 'flee':return{kind:'flee'};case 'stop':return{kind:'stop'};
   case 'legacy':return{kind:'legacy',a:n.a};
   case 'pick':return{kind:'pick',who:n.who};
   case 'fire':return{kind:'fire',on:n.on,range:n.range};}
  return null;}
 const pointOf=(n,x)=>n.to?{to:n.to}:{px:n.x,py:n.y};
 return{vars,
  /* x: {tick, sensor(name,r), reached(point)} ← {move,target,fire} */
  step(x){const out={};for(const l of LAYERS)out[l]=prog[l]?run(prog[l],x):null;return out;}};
}

/* ---------- توصیف فارسی (برای نمایش به کاربر) ---------- */
const OPFA={'<':'کمتر از','<=':'حداکثر','>':'بیشتر از','>=':'حداقل','==':'برابر','!=':'نابرابر'};
function descCond(c){
 if(c.always)return 'همیشه';if(c.all)return c.all.map(descCond).join(' و ');if(c.any)return '('+c.any.map(descCond).join(' یا ')+')';if(c.not)return 'نه '+descCond(c.not);
 const S=SENSORS[c.s];if(S.t==='b')return c.op==='!='||c.v===0?'نه: '+S.fa:S.fa;
 const nm=c.s==='var'?'متغیر '+c.name:S.fa.replace('r',c.r||'');return nm+' '+OPFA[c.op]+' '+c.v;}
function descMove(n,ind,L){
 const pad='  '.repeat(ind),add=t=>L.push(pad+t);
 switch(n.k){
  case 'go':add('برو '+(typeof n.dir==='number'?n.dir+' درجه':n.dir==='toward'?'به‌سمت دشمن':n.dir==='away'?'دور از دشمن':{up:'بالا',down:'پایین',left:'چپ',right:'راست'}[n.dir]));break;
  case 'goto':add('برو به '+(n.to?POINTS[n.to]:'نقطه ('+Math.round(n.x*100)+'٪، '+Math.round(n.y*100)+'٪)'));break;
  case 'orbit':add('دور '+POINTS[n.around]+' بچرخ، شعاع '+n.r+(n.cw?' (ساعتگرد)':' (پادساعتگرد)'));break;
  case 'ellipse':add('دور '+POINTS[n.around]+' روی بیضی بچرخ (قطر بزرگ '+n.a*2+'، قطر کوچک '+n.b*2+'؛ قطر بزرگ عمود بر خط من و او)');break;
  case 'keep':add('فاصله‌ات را با دشمن '+n.dist+' نگه دار');break;
  case 'flee':add('از دشمن‌ها فرار کن');break;case 'stop':add('بایست');break;
  case 'legacy':add(LEGACY[n.a]);break;
  case 'pick':add('هدف: '+PICKS[n.who]);break;
  case 'fire':add(n.on?'شلیک کن (تا '+n.range+')':'شلیک نکن');break;
  case 'if':add('اگر '+descCond(n.c)+':');if(n.then)descMove(n.then,ind+1,L);if(n.else){add('وگرنه:');descMove(n.else,ind+1,L);}break;
  case 'seq':add(n.loop?'پشت‌سرهم و تکراری:':'پشت‌سرهم:');n.steps.forEach((s,i)=>{const dur=s.t!==undefined&&!s.until&&!s.reach?s.t+' ثانیه':s.reach?'تا برسد':'تا '+descCond(s.until);add('  '+(i+1)+') ('+dur+')');descMove(s.n,ind+2,L);});break;
  case 'states':add('حالت‌ها (شروع: '+n.start+'):');for(const k of Object.keys(n.s)){add('  حالت «'+k+'»:');descMove(n.s[k].n,ind+2,L);for(const t of n.s[k].to)add('    اگر '+descCond(t.c)+' ← برو به «'+t.go+'»');}break;}}
function describe(prog){const L=[];for(const [l,fa] of [['move','حرکت'],['target','هدف'],['fire','شلیک']])if(prog[l]){L.push(fa+':');descMove(prog[l],1,L);}return L;}

/* ---------- ویژگی‌های برنامه (برای آموزش) ---------- */
function features(prog){
 const f={move:false,fire:false,target:false,sensors:new Set(),kinds:new Set()};
 const c=x=>{if(!x)return;if(x.s)f.sensors.add(x.s);(x.all||x.any||[]).forEach(c);if(x.not)c(x.not);};
 for(const l of LAYERS)walk(prog[l],n=>{f.kinds.add(n.k);if(MOVERS.includes(n.k))f.move=true;if(n.k==='fire'&&n.on)f.fire=true;if(n.k==='pick')f.target=true;
  c(n.c);if(n.steps)n.steps.forEach(s=>c(s.until));if(n.s)Object.values(n.s).forEach(s=>s.to.forEach(t=>c(t.c)));});
 return f;}

return{TPS,SENSORS,PICKS,POINTS,LEGACY,DIRS,compile,runner,describe,features};
});
