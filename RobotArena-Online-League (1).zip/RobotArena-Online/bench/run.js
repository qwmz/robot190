'use strict';
// بنچ‌مارک مفسر پرامپت: چند مدل هم‌قیمت را روی جمله‌های طلایی (همان کار واقعی بازی) می‌سنجد.
// اجرا:   $env:OPENROUTER_API_KEY="sk-or-..."   سپس   node bench/run.js [مدل1 مدل2 ...]
// هر مدل یک درخواست می‌گیرد (مثل خود بازی: همهٔ بخش‌ها با هم)، پس هزینهٔ کل کل بنچ‌مارک چند سنت است.
const ai=require('../ai');
const KEY=process.env.OPENROUTER_API_KEY||(String(process.env.ANTHROPIC_API_KEY||'').startsWith('sk-or-')?process.env.ANTHROPIC_API_KEY:'');
if(!KEY){console.error('کلید OpenRouter را در OPENROUTER_API_KEY بگذار.');process.exit(1);}
const MODELS=process.argv.slice(2).length?process.argv.slice(2):[
 'anthropic/claude-haiku-5.5','openai/gpt-5-nano','deepseek/deepseek-v4-flash','deepseek/deepseek-v4.1-flash','qwen/qwen3.7-flash',
 'qwen/qwen3.5-flash-02-23','google/gemma-4-26b-a4b-it','z-ai/glm-5.3-flash','mistralai/mistral-small-3.2-24b-instruct','openai/gpt-oss-20b','nvidia/nemotron-3-nano-30b-a3b'];

// انتظار: c = شرط‌هایی که باید جایی در قانون باشند، a = کارهای لازم (با | یعنی هرکدام)، v = مقدار عددی با خطای مجاز، bad = باید رد شود
const T=[
 ['move','وقتی جانم زیر ۴۰ درصد شد عقب بکش',{c:['hp_low'],a:['retreat'],v:{hp_low:[40,5]}}],
 ['move','اگه محاصره شدم از محاصره بیرون بزن',{c:['surrounded'],a:['breakout']}],
 ['move','وقتی گوشه گیر کردم پشت دیوار پناه بگیر',{c:['cornered'],a:['cover']}],
 ['move','همیشه ۳۰۰ پیکسل از دشمن فاصله بگیر',{a:['keep'],v:{keep:[300,40]}}],
 ['move','وقتی یک طرف ۱۰ تا دشمن هست و یک طرف ۱ دونه، به سمت خلوت‌تر برو',{c:['side_diff'],a:['go_empty_side'],v:{side_diff:[9,2]}}],
 ['move','اگر زامبی نزدیک شد و جونم کم بود فرار کن',{c:['near','hp_low'],a:['retreat']}],
 ['move','وقتی فقط یک دشمن در دید هست هر نیم ثانیه زاویه‌ات رو با دشمن ۳۰ درجه و منفی ۳۰ تغییر بده',{c:['enemies_in'],a:['move_rel'],w:{move_rel:[30,10]}}],
 ['move','تا وقتی پشت دیوارم سر جات بایست',{c:['covered'],a:['hold']}],
 ['move','اگه ۳ ثانیه تکون نخوردم و گیر کردم راه باز کن بیرون بزن',{c:['stuck'],a:['breakout|go_empty_side|go_safest'],v:{stuck:[3,1]}}],
 ['move','وقتی محاصره شدم یا گوشه گیر کردم و جونم زیر ۴۰ بود بیرون بزن',{c:['surrounded','cornered','hp_low'],a:['breakout'],v:{hp_low:[40,5]}}],
 ['move','وقتی ربات دشمن رو دید برعکس اون حرکت کنه',{a:['retreat|move_rel']}],
 ['move','باید خیلی دور باشه از دشمن',{a:['keep|retreat'],v:{keep:[450,100]}}],
 ['shoot','غول‌ها رو اول بزن',{a:['t_danger']}],
 ['shoot','فقط تا فاصله ۳۰۰ شلیک کن',{a:['fire_range'],v:{fire_range:[300,30]}}],
 ['shoot','وقتی جونم کم شد شلیک تند بزن',{c:['hp_low'],a:['rapid']}],
 ['shoot','وقتی دشمن دور بود شلیک نکن',{c:['far'],a:['cease_fire']}],
 ['skill','اگه تیر به سمتم اومد جاخالی بده',{c:['bullet'],a:['dash']}],
 ['skill','وقتی جانم تند افت کرد سپر بزن',{c:['hp_drop'],a:['shield']}],
 ['skill','وقتی محاصره شدم هم سپر بزن هم جاخالی بده',{c:['surrounded'],a:['shield','dash']}],
 ['move','بهترین ربات دنیا رو برام بساز',{bad:1}],
 ['shoot','عقب بکش و فرار کن',{bad:1}],
 ['move','ربات رو هوشمندتر کن',{bad:1}]];

function judge(r,e){
 if(!r)return'بدون پاسخ';
 if(e.bad)return r.status==='bad'?null:'باید رد می‌شد';
 if(r.status!=='ok')return'رد شد: '+String(r.msg||'').slice(0,50);
 const groups=[r,...(r.alts||[])],conds=[];for(const g of groups){conds.push(g);for(const x of g.x||[])conds.push(x);for(const x of r.x||[])conds.push(x);}
 const keys=new Set(conds.map(q=>q.c)),acts=r.acts.map(a=>a.a);
 for(const c of e.c||[])if(!keys.has(c))return'شرط نیامد: '+c;
 for(const a of e.a||[])if(!a.split('|').some(k=>acts.includes(k)))return'کار نیامد: '+a;
 for(const [k,[v,tol]] of Object.entries(e.v||{})){const all=[...conds.filter(q=>q.c===k).map(q=>q.cv),...r.acts.filter(q=>q.a===k).map(q=>q.av)].filter(x=>x!=null);if(!all.some(x=>Math.abs(x-v)<=tol))return`مقدار ${k}: ${all.join(',')||'-'}، انتظار ${v}`;}
 for(const [k,[v,tol]] of Object.entries(e.w||{})){const all=r.acts.filter(q=>q.a===k).map(q=>q.av2);if(!all.some(x=>x!=null&&Math.abs(x-v)<=tol))return`تکان ${k}: ${all.join(',')||'-'}`;}
 return null;}

(async()=>{
 const price={};try{const j=await(await fetch('https://openrouter.ai/api/v1/models')).json();for(const m of j.data)price[m.id]=[+m.pricing.prompt,+m.pricing.completion];}catch{}
 const inputs={move:[],shoot:[],skill:[]},idx=T.map(([t,x])=>{inputs[t].push(x);return[t,inputs[t].length-1];});
 const rows=[];
 for(const model of MODELS){
  let usage=null;const t0=Date.now();
  const f=async(u,init)=>{const r=await fetch(u,init);const j=await r.json().catch(()=>({}));usage=j.usage||null;return{ok:r.ok,status:r.status,json:async()=>j};};
  let out,err=null;
  try{out=await ai.call(inputs,KEY,{model,fetch:f});}catch(e){err=e.message;}
  const fails=[];let pass=0;
  T.forEach(([t,x,e],n)=>{const why=err?err:judge(out&&out[t][idx[n][1]],e);if(why)fails.push(`  ✗ ${x.slice(0,42)} — ${why}`);else pass++;});
  const pin=usage?usage.prompt_tokens:0,pout=usage?usage.completion_tokens:0,p=price[model]||[0,0];
  rows.push({model,pass,pin,pout,cost:pin*p[0]+pout*p[1],sec:(Date.now()-t0)/1000,fails});
 }
 rows.sort((a,b)=>b.pass-a.pass||a.cost-b.cost);
 console.log('\nمدل'.padEnd(46)+'درست'.padEnd(8)+'ورودی'.padEnd(8)+'خروجی'.padEnd(8)+'هزینه(دلار)'.padEnd(14)+'ثانیه');
 for(const r of rows)console.log(r.model.padEnd(45)+(r.pass+'/'+T.length).padEnd(8)+String(r.pin).padEnd(8)+String(r.pout).padEnd(8)+r.cost.toFixed(6).padEnd(14)+r.sec.toFixed(1));
 console.log('\nخطاها:');for(const r of rows){console.log('\n'+r.model+(r.fails.length?'':'  (بی‌خطا)'));for(const f of r.fails)console.log(f);}
})();
