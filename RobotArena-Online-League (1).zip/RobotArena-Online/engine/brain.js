'use strict';
/* مغز ربات برنامه‌دار: پورت public/brain.js (حس‌گرها، مقصدها، دنبال‌کردن مسیر) + حرکت‌های قدیمی (پناه، شکستن محاصره، …) از index.html.
   یک نمونه برای هر ربات: createBrain(B, core, prog) ← {tick(P, Z)} */
const Behavior=require('../behavior');
const{BASE_SPEED,PLAYER_CD,clamp,normAng}=require('./core');
const PSPD=BASE_SPEED*.9;
const rectDist=(x,y,o)=>{const dx=Math.max(o.x-x,0,x-(o.x+o.w)),dy=Math.max(o.y-y,0,y-(o.y+o.h));return Math.hypot(dx,dy);};
const hyp=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);

function createBrain(B,core,prog){
 const{rnd,hasLOS,hitWall,wallInPath,findPath,simplePathStep,requestMotion,fireBulletFrom}=core;
 let st=null;
 const cubesSafe=robots=>B.cubes.filter(q=>!robots.some(z=>Math.hypot(z.x-q.x,z.y-q.y)<350));

 function sensors(P,Z){
  const all=Z.filter(z=>z.alive!==false),real=all.filter(z=>!z.chest),live=real.length?real:all,dist=z=>Math.hypot(z.x-P.x,z.y-P.y);
  let nearest=null,nd=1e9;for(const z of live){const d=dist(z);if(d<nd){nd=d;nearest=z;}}
  const safeCubes=()=>cubesSafe(real);
  return function(name,r){
   switch(name){
    case 'hp':return P.hp/P.maxHp*100;
    case 'dist_nearest':return nearest?nd:9999;
    case 'enemies':return live.filter(z=>dist(z)<900).length;
    case 'enemies_within':return live.filter(z=>dist(z)<(r||450)).length;
    case 'enemy_hp':return nearest?nearest.hp/nearest.maxHp*100:100;
    case 'x_pct':return P.x/B.w*100;
    case 'y_pct':return P.y/B.h*100;
    case 'wall_dist':{let m=1e9;for(const o of B.obstacles)m=Math.min(m,rectDist(P.x,P.y,o)-P.r);return Math.max(0,Math.min(m,2000));}
    case 'time':return B.tick/60;
    case 'still_time':return(B.tick-st.moveTick)/60;
    case 'hit':return B.tick-st.hitTick<60;
    case 'bullet':return B.bullets.some(b=>b.owner!==P&&Math.hypot(b.x-P.x,b.y-P.y)<280&&(b.vx*(P.x-b.x)+b.vy*(P.y-b.y))>0);
    case 'exposed':return live.some(z=>dist(z)<700&&hasLOS(z,P));
    case 'runner':case 'spitter':case 'brute':return false;/* نوع دشمن در رویال وجود ندارد */
    case 'cubes':return B.cubes.length;
    case 'dist_cube':{let m=9999;for(const q of B.cubes)m=Math.min(m,Math.hypot(q.x-P.x,q.y-P.y));return m;}
    case 'chest':return all.some(z=>z.chest);
    case 'dist_chest':{let m=9999;for(const z of all)if(z.chest)m=Math.min(m,dist(z));return m;}
    case 'safe_cube':return safeCubes().length>0;
    case 'dist_safe_cube':{let m=9999;for(const q of safeCubes())m=Math.min(m,Math.hypot(q.x-P.x,q.y-P.y));return m;}
    case 'power':return(P.cubes||0)+1;
    case 'enemy_power':return nearest?(nearest.cubes||0)+1:1;
    case 'robots_left':return real.length+1;}
   return 0;};
 }
 const nearestCube=(P,list)=>{let b=null,d=1e9;for(const q of list){const k=Math.hypot(q.x-P.x,q.y-P.y);if(k<d){d=k;b=q;}}return b?{x:b.x,y:b.y}:null;};
 function resolvePt(spec,P,Z){
  const all=Z.filter(z=>z.alive!==false),real=all.filter(z=>!z.chest),live=real.length?real:all;
  const by=f=>{let b=null,v=-1e9;for(const z of live){const s=f(z);if(s>v){v=s;b=z;}}return b;};
  if(spec.to==='center')return{x:B.w/2,y:B.h/2};
  if(spec.to==='start')return{x:st.x0,y:st.y0};
  if(spec.to==='nearest'){const z=by(z=>-Math.hypot(z.x-P.x,z.y-P.y));return z?{x:z.x,y:z.y}:null;}
  if(spec.to==='farthest'){const z=by(z=>Math.hypot(z.x-P.x,z.y-P.y));return z?{x:z.x,y:z.y}:null;}
  if(spec.to==='chest'){const z=all.find(z=>z.chest);return z?{x:z.x,y:z.y}:null;}
  if(spec.to==='safe_cube')return nearestCube(P,cubesSafe(real));
  if(spec.to==='cube'||spec.to==='gem')return nearestCube(P,B.cubes);
  if(spec.to==='top')return{x:B.w/2,y:B.h*.1};
  if(spec.to==='bottom')return{x:B.w/2,y:B.h*.9};
  if(spec.to==='left')return{x:B.w*.1,y:B.h/2};
  if(spec.to==='right')return{x:B.w*.9,y:B.h/2};
  if(spec.px!==undefined)return{x:B.w*spec.px,y:B.h*spec.py};
  return null;}
 const clampPt=(x,y)=>({x:Math.max(70,Math.min(B.w-70,x)),y:Math.max(70,Math.min(B.h-70,y))});
 function pickTarget(P,Z,who){
  let vis=Z.filter(z=>z.alive!==false&&Math.hypot(z.x-P.x,z.y-P.y)<900);if(who!=='chest'&&vis.some(z=>!z.chest))vis=vis.filter(z=>!z.chest);
  let best=null,bs=-1e9;
  for(const z of vis){const d=Math.hypot(z.x-P.x,z.y-P.y);
   const s=who==='farthest'?d:who==='weakest'?-z.hp*1000-d:who==='strongest'?z.hp*1000-d:who==='chest'?(z.chest?1e4:0)-d:-d;/* تندرو/تیرانداز/غول در رویال نیستند: نزدیک‌ترین */
   if(s>bs){bs=s;best=z;}}
  return best;}
 function goAngle(m,P,ne){
  if(typeof m.dir==='number')return(m.dir-90)*Math.PI/180;
  if(m.dir==='toward'||m.dir==='away'){if(!ne)return null;return Math.atan2(ne.y-P.y,ne.x-P.x)+(m.dir==='away'?Math.PI:0);}
  return(({up:0,right:90,down:180,left:270})[m.dir]-90)*Math.PI/180;}
 /* دنبال‌کردن با تعهد: تا وقتی مقصد عوض نشده و ربات گیر نکرده همان مسیر را می‌رود */
 function follow(P,tx,ty,spd){
  const c=clampPt(tx,ty),sp=PSPD*(spd||1),dx=c.x-P.x,dy=c.y-P.y,d=Math.hypot(dx,dy);
  if(d<10)return null;
  if(!wallInPath(P.x,P.y,c.x,c.y,P.r+3)){st.route=null;return{x:dx/d*sp,y:dy/d*sp};}
  let R=st.route;
  if(!R||Math.hypot(R.tx-c.x,R.ty-c.y)>90||B.tick-st.moveTick>40||B.tick-R.t>900){
   let pts=[];try{pts=findPath(P.x,P.y,c.x,c.y)||[];}catch(e){}R=st.route={tx:c.x,ty:c.y,pts,i:0,t:B.tick};}
  if(!R.pts.length)return{x:dx/d*sp,y:dy/d*sp};
  while(R.i<R.pts.length-1&&(Math.hypot(R.pts[R.i].x-P.x,R.pts[R.i].y-P.y)<26||!wallInPath(P.x,P.y,R.pts[R.i+1].x,R.pts[R.i+1].y,P.r+3)))R.i++;
  const w=R.pts[R.i],wx=w.x-P.x,wy=w.y-P.y,wd=Math.hypot(wx,wy)||1;
  return{x:wx/wd*sp,y:wy/wd*sp};}
 function goSlide(P,a,spd){
  const sp=PSPD*(spd||1),look=70,ok=t=>!wallInPath(P.x,P.y,P.x+Math.cos(t)*look,P.y+Math.sin(t)*look,P.r+3);
  let ang=a;
  if(!ok(a)){const side=st.slide||1;let found=null;
   for(const d of[25,50,75,100,125,150]){for(const s of[side,-side]){const t=a+s*d*Math.PI/180;if(ok(t)){found=t;st.slide=s;break;}}if(found!==null)break;}
   if(found===null)return null;ang=found;}
  return{x:Math.cos(ang)*sp,y:Math.sin(ang)*sp};}

 /* ---------- حرکت‌های قدیمی (legacy) ---------- */
 function coverSpot(P,Z){const c0=P._cv;if(c0&&B.tick-c0.t<25&&(c0.none||hyp(P,c0)>14))return c0.none?null:c0;
  const E=Z.filter(z=>hyp(P,z)<900).sort((a,b)=>hyp(P,a)-hyp(P,b)).slice(0,3);if(!E.length)return null;
  if(!E.some(z=>hasLOS(P,z))){P._cv={x:P.x,y:P.y,t:B.tick};return P._cv;}
  let best=null,bs=1e9;
  for(let r=70;r<=340;r+=90)for(let k=0;k<16;k++){const a=k*Math.PI/8,x=P.x+Math.cos(a)*r,y=P.y+Math.sin(a)*r;
   if(x<60||y<60||x>B.w-60||y>B.h-60||hitWall(x,y,P.r+6))continue;
   const q={x,y};if(E.some(z=>hasLOS(q,z)))continue;
   let s=r;for(const z of E)s+=Math.max(0,260-hyp(q,z))*1.5;if(wallInPath(P.x,P.y,x,y,P.r+3))s+=120;
   if(s<bs){bs=s;best=q;}}
  P._cv=best?{x:best.x,y:best.y,t:B.tick}:{x:0,y:0,t:B.tick,none:1};return best?P._cv:null;}
 function openDir(P,Z){const E=Z.filter(z=>hyp(P,z)<650);let best=null,bs=-1e9;
  for(let k=0;k<24;k++){const a=k*Math.PI/12,dx=Math.cos(a),dy=Math.sin(a);let s=0;
   for(const z of E){const d=Math.max(hyp(P,z),40),c=(dx*(z.x-P.x)+dy*(z.y-P.y))/d;if(c>0)s-=c*c*(900/d);else s+=(-c)*.15*(300/d);}
   if(wallInPath(P.x,P.y,P.x+dx*90,P.y+dy*90,P.r+3))s-=6;else if(wallInPath(P.x,P.y,P.x+dx*220,P.y+dy*220,P.r+3))s-=1.5;
   if(s>bs){bs=s;best={dx,dy};}}
  return best;}
 function smartMove(P,Z,kind){
  if(kind==='cover'){const c=coverSpot(P,Z);if(c)return hyp(P,c)>14?simplePathStep(P,c.x,c.y,PSPD*1.1):null;}
  const o=openDir(P,Z);if(!o)return null;
  return simplePathStep(P,clamp(P.x+o.dx*260,80,B.w-80),clamp(P.y+o.dy*260,80,B.h-80),PSPD*1.15);}
 function smartMove2(P,Z,kind){
  const go=(dx,dy,m)=>simplePathStep(P,clamp(P.x+dx*260,80,B.w-80),clamp(P.y+dy*260,80,B.h-80),PSPD*(m||1.1));
  const E=Z.filter(z=>hyp(P,z)<900);
  if(kind==='go_empty_side'){let best=null,bs=-1e9;
   for(let k=0;k<12;k++){const a=k*Math.PI/6,dx=Math.cos(a),dy=Math.sin(a);let c=0;
    for(const z of E){const d=hyp(P,z);if(d>650)continue;if((dx*(z.x-P.x)+dy*(z.y-P.y))/d>.5)c++;}
    let s=-c*100;{let dn=400;const q={x:P.x+dx*200,y:P.y+dy*200};for(const z of E)dn=Math.min(dn,hyp(q,z));s+=dn*.2;}
    if(wallInPath(P.x,P.y,P.x+dx*90,P.y+dy*90,P.r+3))s-=150;else if(wallInPath(P.x,P.y,P.x+dx*220,P.y+dy*220,P.r+3))s-=40;
    if(s>bs){bs=s;best={dx,dy};}}
   return best?go(best.dx,best.dy,1.15):null;}
  const c0=P._gs;if(c0&&B.tick-c0.t<20&&hyp(P,c0)>14)return simplePathStep(P,c0.x,c0.y,PSPD*1.1);
  let best=null,bs=-1e9;
  for(let r=120;r<=360;r+=120)for(let k=0;k<16;k++){const a=k*Math.PI/8,x=P.x+Math.cos(a)*r,y=P.y+Math.sin(a)*r;
   if(x<80||y<80||x>B.w-80||y>B.h-80||hitWall(x,y,P.r+6))continue;
   let d=700;for(const z of E)d=Math.min(d,hyp({x,y},z));
   const s=d-r*.3-(wallInPath(P.x,P.y,x,y,P.r+3)?120:0);if(s>bs){bs=s;best={x,y,t:B.tick};}}
  P._gs=best;return best&&hyp(P,best)>14?simplePathStep(P,best.x,best.y,PSPD*1.1):null;}

 /* ---------- یک تیک تصمیم ---------- */
 function tick(P,Z){
  if(!st)st={run:Behavior.runner(prog),x0:P.x,y0:P.y,lx:P.x,ly:P.y,moveTick:B.tick,hitTick:-999,lastHp:P.hp,tgt:null};
  if(P.hp<st.lastHp-.01)st.hitTick=B.tick;st.lastHp=P.hp;
  if(Math.hypot(P.x-st.lx,P.y-st.ly)>1.2){st.moveTick=B.tick;st.lx=P.x;st.ly=P.y;}
  const sen=sensors(P,Z);
  const out=st.run.step({tick:B.tick,sensor:sen,reached:spec=>{const p=resolvePt(spec,P,Z);return p&&Math.hypot(p.x-P.x,p.y-P.y)<45;}});
  let mv=null;const m=out.move,all0=Z.filter(z=>z.alive!==false),rl=all0.filter(z=>!z.chest),live=rl.length?rl:all0;
  let ne=null,nd=1e9,far=null,fd=-1;for(const z of live){const d=Math.hypot(z.x-P.x,z.y-P.y);if(d<nd){nd=d;ne=z;}if(d>fd){fd=d;far=z;}}
  const step=(p,spd)=>follow(P,p.x,p.y,spd);
  if(m){switch(m.kind){
   case 'go':{const a=goAngle(m,P,ne);if(a===null)break;
    mv=goSlide(P,a,m.spd)||step({x:P.x+Math.cos(a)*150,y:P.y+Math.sin(a)*150},m.spd);break;}
   case 'goto':{const p=resolvePt(m,P,Z);if(p&&Math.hypot(p.x-P.x,p.y-P.y)>30)mv=step(p,m.spd);break;}
   case 'orbit':{const c=resolvePt({to:m.around},P,Z);if(!c)break;const dx=P.x-c.x,dy=P.y-c.y,d=Math.hypot(dx,dy)||1,ux=dx/d,uy=dy/d,s=m.cw?1:-1,k=Math.max(-1,Math.min(1,(d-m.r)/120));
    const vx=-uy*s-ux*k,vy=ux*s-uy*k;mv=step({x:P.x+vx*140,y:P.y+vy*140},m.spd);break;}
   case 'ellipse':{const c=resolvePt({to:m.around},P,Z);if(!c)break;const ent=m.around==='nearest'?ne:m.around==='farthest'?far:null;
    const dx0=P.x-c.x,dy0=P.y-c.y,d0=Math.hypot(dx0,dy0)||1;let E=st.ell;
    if(!E||B.tick-E.t>20||E.ent!==ent||E.around!==m.around)E=st.ell={ent,around:m.around,ux:dx0/d0,uy:dy0/d0,t:B.tick};
    E.t=B.tick;const ux=E.ux,uy=E.uy,px=-uy,py=ux,rx=P.x-c.x,ry=P.y-c.y;
    const th=Math.atan2((rx*ux+ry*uy)/m.b,(rx*px+ry*py)/m.a),nt=th+(m.cw?1:-1)*.45;
    mv=step({x:c.x+px*m.a*Math.cos(nt)+ux*m.b*Math.sin(nt),y:c.y+py*m.a*Math.cos(nt)+uy*m.b*Math.sin(nt)},m.spd);break;}
   case 'keep':{if(!ne)break;const dx=(ne.x-P.x)/nd,dy=(ne.y-P.y)/nd;
    if(nd<m.dist-25){let ax=-dx,ay=-dy;if(wallInPath(P.x,P.y,P.x+ax*50,P.y+ay*50,P.r+3)){ax=-dy;ay=dx;}mv={x:ax*PSPD,y:ay*PSPD};}
    else if(nd>m.dist+45)mv=step(ne,1);else{const s=Math.sin(B.tick/70)>0?1:-1;mv={x:-dy*s*1.3,y:dx*s*1.3};}break;}
   case 'flee':{let fx=0,fy=0;for(const z of live){const d=Math.hypot(z.x-P.x,z.y-P.y);if(d<420&&d>0){fx+=(P.x-z.x)/(d*d);fy+=(P.y-z.y)/(d*d);}}
    const mm=Math.hypot(fx,fy);if(mm>0)mv=step({x:P.x+fx/mm*320,y:P.y+fy/mm*320},1.1);break;}
   case 'legacy':{if(m.a==='cover'||m.a==='breakout')mv=smartMove(P,Z,m.a);else mv=smartMove2(P,Z,m.a);break;}}}
  if(mv)requestMotion(P,mv.x,mv.y);
  /* هدف و شلیک */
  let who=out.target&&out.target.kind==='pick'?out.target.who:'nearest';
  /* دفاع از خود: اگر رباتی نزدیک و دیدنی است یا تازه به من شلیک شده، هدف از صندوق به همان ربات برمی‌گردد */
  if(who==='chest'&&live.some(z=>!z.chest&&((Math.hypot(z.x-P.x,z.y-P.y)<520&&hasLOS(z,P))||(B.tick-st.hitTick<90&&Math.hypot(z.x-P.x,z.y-P.y)<900))))who='nearest';
  if(!st.tgt||!st.tgt.alive||B.tick%20===0)st.tgt=pickTarget(P,Z,who);else if(st.who!==who)st.tgt=pickTarget(P,Z,who);st.who=who;
  const tg=st.tgt,fire=out.fire&&out.fire.kind==='fire'?out.fire:{on:true,range:680};
  if(tg){const dx=tg.x-P.x,dy=tg.y-P.y,d=Math.hypot(dx,dy),want=Math.atan2(dy,dx);
   P.angle+=clamp(normAng(want-P.angle),-.22,.22);
   if(fire.on&&P.cool<=0&&hasLOS(P,tg)&&d<fire.range&&Math.abs(normAng(want-P.angle))<.14){const sp=.015+d*.00011;fireBulletFrom(P,P.angle+rnd(-sp,sp));P.cool=PLAYER_CD;}}
  else if(mv){const a=Math.atan2(mv.y,mv.x);P.angle+=clamp(normAng(a-P.angle),-.18,.18);}
 }
 return{tick};
}
module.exports={createBrain};
