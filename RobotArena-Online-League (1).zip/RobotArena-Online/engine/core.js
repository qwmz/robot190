'use strict';
/* هستهٔ فیزیک بدون DOM: حرکت، برخورد، دید، مسیریابی، گلوله و آسیب.
   پورت مستقیم توابع public/index.html (applyMotion، resolveRobotCollisions، hasLOS، findPath، stepBullet، …).
   جلوه‌ها (ذره، صدا، متن شناور) اینجا نیست؛ فقط رخداد در B.ev ثبت می‌شود و کاربر خودش می‌سازدشان. */
const BASE_SPEED=3.2,BULLET_SPEED=14,BULLET_DMG=10,PLAYER_CD=16,KILL_HEAL=20;
const PHYS={MAX_STEP:BASE_SPEED,SUBSTEP:1.5,WALL_ITER:6,SEP_ITER:4,SEP_CAP:1.2,SKIN:.02,SEP_SKIN:1,PUSH_BACK:.5};
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const normAng=a=>{while(a>Math.PI)a-=Math.PI*2;while(a<-Math.PI)a+=Math.PI*2;return a;};
const r1=v=>Math.round(v*10)/10;

function circleVsAABB(cx,cy,r,b){
 const px=cx<b.x?b.x:(cx>b.x+b.w?b.x+b.w:cx),py=cy<b.y?b.y:(cy>b.y+b.h?b.y+b.h:cy);
 const dx=cx-px,dy=cy-py,d2=dx*dx+dy*dy;
 if(d2>r*r)return null;
 if(d2>1e-10){const d=Math.sqrt(d2);return{nx:dx/d,ny:dy/d,depth:r-d};}
 const dl=cx-b.x,dr=(b.x+b.w)-cx,dt=cy-b.y,db=(b.y+b.h)-cy,mh=dl<dr?dl:dr,mv=dt<db?dt:db;
 if(mh<mv)return{nx:dl<dr?-1:1,ny:0,depth:r+mh};
 return{nx:0,ny:dt<db?-1:1,depth:r+mv};
}

/* B: وضعیت مسابقه {w,h,obstacles,bullets,ents,tick,nav,ev,rng,nextBid}. ents = همهٔ ربات‌ها و صندوق‌ها به ترتیب ثابت. */
function createCore(B){
 const rnd=(a,b)=>a+B.rng()*(b-a);
 const emit=(...a)=>{B.ev.push(a);};
 function pointInWall(x,y){const obs=B.obstacles;for(let i=0;i<obs.length;i++){const o=obs[i];if(x>=o.x&&x<=o.x+o.w&&y>=o.y&&y<=o.y+o.h)return true;}return false;}
 function wallAt(x,y){const obs=B.obstacles;for(let i=0;i<obs.length;i++){const o=obs[i];if(x>=o.x&&x<=o.x+o.w&&y>=o.y&&y<=o.y+o.h)return o;}return null;}
 function hitWall(x,y,r){const r2=r*r,obs=B.obstacles;
  for(let i=0;i<obs.length;i++){const o=obs[i],px=x<o.x?o.x:(x>o.x+o.w?o.x+o.w:x),py=y<o.y?o.y:(y>o.y+o.h?o.y+o.h:y),dx=x-px,dy=y-py;if(dx*dx+dy*dy<r2)return true;}
  return false;}
 function resolveWallContacts(ent){let any=false;
  for(let it=0;it<PHYS.WALL_ITER;it++){let moved=false;const obs=B.obstacles;
   for(let k=0;k<obs.length;k++){const c=circleVsAABB(ent.x,ent.y,ent.r,obs[k]);if(c){ent.x+=c.nx*(c.depth+PHYS.SKIN);ent.y+=c.ny*(c.depth+PHYS.SKIN);moved=true;any=true;}}
   if(!moved)break;}
  return any;}
 function clampInArena(ent){const m=ent.r+26;
  if(ent.x<m)ent.x=m;else if(ent.x>B.w-m)ent.x=B.w-m;
  if(ent.y<m)ent.y=m;else if(ent.y>B.h-m)ent.y=B.h-m;}
 function requestMotion(ent,dx,dy){if(!ent||!isFinite(dx)||!isFinite(dy))return;ent._pdx=(ent._pdx||0)+dx;ent._pdy=(ent._pdy||0)+dy;}
 function applyMotion(ent){
  let dx=ent._pdx||0,dy=ent._pdy||0;ent._pdx=0;ent._pdy=0;
  if(!ent.alive)return;
  let len=Math.hypot(dx,dy);
  if(len>PHYS.MAX_STEP){const k=PHYS.MAX_STEP/len;dx*=k;dy*=k;len=PHYS.MAX_STEP;}
  if(len<1e-9){if(hitWall(ent.x,ent.y,ent.r))resolveWallContacts(ent);clampInArena(ent);return;}
  const steps=Math.max(1,Math.ceil(len/PHYS.SUBSTEP)),sdx=dx/steps,sdy=dy/steps;
  for(let i=0;i<steps;i++){ent.x+=sdx;ent.y+=sdy;if(hitWall(ent.x,ent.y,ent.r))resolveWallContacts(ent);}
  clampInArena(ent);
  if(hitWall(ent.x,ent.y,ent.r)){resolveWallContacts(ent);clampInArena(ent);}
 }
 function resolveRobotCollisions(){
  const robots=B.ents.filter(e=>e.alive),n=robots.length;
  if(n<2)return;
  for(let iter=0;iter<PHYS.SEP_ITER;iter++){let moved=false;
   for(let i=0;i<n;i++){const a=robots[i];
    for(let j=i+1;j<n;j++){const b=robots[j],dx=b.x-a.x,dy=b.y-a.y,minD=a.r+b.r+PHYS.SEP_SKIN,d2=dx*dx+dy*dy;
     if(d2>=minD*minD)continue;
     let ux,uy,d;
     if(d2<1e-8){const ang=(i*3+j*7+iter)*0.7853981633974483;ux=Math.cos(ang);uy=Math.sin(ang);d=0;}
     else{d=Math.sqrt(d2);ux=dx/d;uy=dy/d;}
     let push=(minD-d)*PHYS.PUSH_BACK;if(push>PHYS.SEP_CAP)push=PHYS.SEP_CAP;if(push<0)push=0;
     const aX=a.x-ux*push,aY=a.y-uy*push,bX=b.x+ux*push,bY=b.y+uy*push;
     if(!hitWall(aX,aY,a.r)){a.x=aX;a.y=aY;moved=true;}
     if(!hitWall(bX,bY,b.r)){b.x=bX;b.y=bY;moved=true;}}}
   if(!moved)break;}
  for(let i=0;i<n;i++){const r=robots[i];if(hitWall(r.x,r.y,r.r))resolveWallContacts(r);clampInArena(r);}
 }
 function hasLOS(a,b){const dx=b.x-a.x,dy=b.y-a.y,steps=Math.ceil(Math.hypot(dx,dy)/24),inv=1/steps;
  for(let i=1;i<steps;i++){const t=i*inv;if(pointInWall(a.x+dx*t,a.y+dy*t))return false;}
  return true;}
 function wallInPath(x1,y1,x2,y2,r){const dx=x2-x1,dy=y2-y1,steps=Math.ceil(Math.hypot(dx,dy)/20),inv=1/steps;
  for(let i=1;i<steps;i++){const t=i*inv;if(hitWall(x1+dx*t,y1+dy*t,r))return true;}
  return false;}
 function navGrid(){
  if(B.nav)return B.nav;
  const cs=40,w=Math.ceil(B.w/cs),h=Math.ceil(B.h/cs),blk=new Uint8Array(w*h);
  for(let j=0;j<h;j++)for(let i=0;i<w;i++)blk[j*w+i]=hitWall((i+.5)*cs,(j+.5)*cs,25)?1:0;
  return B.nav={cs,w,h,blk};
 }
 function findPath(sx,sy,tx,ty){
  const{cs,w,h,blk}=navGrid();
  const cell=(x,y)=>clamp(Math.floor(y/cs),0,h-1)*w+clamp(Math.floor(x/cs),0,w-1);
  const free=id=>{if(!blk[id])return id;const ci=id%w,cj=(id/w)|0;
   for(let r=1;r<7;r++)for(let dj=-r;dj<=r;dj++)for(let di=-r;di<=r;di++){const i=ci+di,j=cj+dj;if(i<0||j<0||i>=w||j>=h)continue;if(!blk[j*w+i])return j*w+i;}return id;};
  const s0=free(cell(sx,sy)),g=free(cell(tx,ty));
  const gs=new Float32Array(w*h).fill(1e9),from=new Int32Array(w*h).fill(-1),closed=new Uint8Array(w*h);
  const hp=[];
  const push=(f,id)=>{hp.push([f,id]);let i=hp.length-1;while(i>0){const p=(i-1)>>1;if(hp[p][0]<=hp[i][0])break;[hp[p],hp[i]]=[hp[i],hp[p]];i=p;}};
  const pop=()=>{const t=hp[0],l=hp.pop();if(hp.length){hp[0]=l;let i=0;for(;;){const a=2*i+1,b=a+1;let m=i;if(a<hp.length&&hp[a][0]<hp[m][0])m=a;if(b<hp.length&&hp[b][0]<hp[m][0])m=b;if(m===i)break;[hp[m],hp[i]]=[hp[i],hp[m]];i=m;}}return t;};
  const H=id=>{const dx=Math.abs(id%w-g%w),dy=Math.abs(((id/w)|0)-((g/w)|0));return dx+dy-0.586*Math.min(dx,dy);};
  gs[s0]=0;push(H(s0),s0);let best=s0,bh=H(s0);
  while(hp.length){
   const c=pop()[1];if(closed[c])continue;closed[c]=1;
   if(c===g){best=g;break;}
   const hc=H(c);if(hc<bh){bh=hc;best=c;}
   const ci=c%w,cj=(c/w)|0;
   for(let dj=-1;dj<=1;dj++)for(let di=-1;di<=1;di++){
    if(!di&&!dj)continue;const i=ci+di,j=cj+dj;if(i<0||j<0||i>=w||j>=h)continue;
    const n=j*w+i;if(blk[n]||closed[n])continue;
    if(di&&dj&&(blk[cj*w+i]||blk[j*w+ci]))continue;
    const ng=gs[c]+(di&&dj?1.414:1);
    if(ng<gs[n]){gs[n]=ng;from[n]=c;push(ng+H(n),n);}}
  }
  const pts=[];for(let c=best;c!==-1&&c!==s0;c=from[c])pts.push({x:(c%w+.5)*cs,y:(((c/w)|0)+.5)*cs});
  pts.reverse();if(best===g&&!blk[g])pts.push({x:tx,y:ty});
  return pts;
 }
 function simplePathStep(ent,tx,ty,spd){
  const dx=tx-ent.x,dy=ty-ent.y,d=Math.hypot(dx,dy);
  if(d<10)return null;
  if(!wallInPath(ent.x,ent.y,tx,ty,ent.r+3)){ent._path=null;return{x:dx/d*spd,y:dy/d*spd};}
  let pp=ent._path;ent._pt=(ent._pt||0)-1;
  if(!pp||ent._pt<=0||Math.hypot(pp.tx-tx,pp.ty-ty)>90){pp=ent._path={tx,ty,pts:findPath(ent.x,ent.y,tx,ty),i:0};ent._pt=30;}
  if(!pp.pts.length)return{x:dx/d*spd,y:dy/d*spd};
  while(pp.i<pp.pts.length-1&&(Math.hypot(pp.pts[pp.i].x-ent.x,pp.pts[pp.i].y-ent.y)<20||!wallInPath(ent.x,ent.y,pp.pts[pp.i+1].x,pp.pts[pp.i+1].y,ent.r+3)))pp.i++;
  const w=pp.pts[pp.i],wx=w.x-ent.x,wy=w.y-ent.y,wd=Math.hypot(wx,wy)||1;
  return{x:wx/wd*spd,y:wy/wd*spd};
 }
 /* ---------- گلوله و آسیب ---------- */
 function fireBulletFrom(owner,angle){
  owner._lf=B.tick;
  const bu={id:B.nextBid++,x:owner.x+Math.cos(angle)*(owner.r+7),y:owner.y+Math.sin(angle)*(owner.r+7),vx:Math.cos(angle)*BULLET_SPEED,vy:Math.sin(angle)*BULLET_SPEED,owner,life:110};
  B.bullets.push(bu);
  emit('shot',B.tick,bu.id,owner.id,r1(bu.x),r1(bu.y),r1(bu.vx),r1(bu.vy));
 }
 /* آسیب: هر انرژیِ صاحبِ گلوله ۱۰٪ آسیب بیشتر (بتل رویال) */
 function damage(target,dmg,owner){
  if(!target.alive)return;
  if(target.shieldT>0)dmg*=.1;
  if(owner&&owner.cubes)dmg*=1+.1*owner.cubes;
  target.hp-=dmg;
  emit('hit',B.tick,target.id,Math.round(dmg),owner?owner.id:-1);
  if(target.hp<=0){target.hp=0;target.alive=false;emit('die',B.tick,target.id,owner?owner.id:-1,r1(target.x),r1(target.y));}
 }
 function hitObstacle(o,bu){
  emit('spark',B.tick,r1(bu.x),r1(bu.y),o.type==='crate'?1:0);
  if(o.type!=='crate')return;
  o.hp-=BULLET_DMG;
  if(o.hp>0)return;
  const i=B.obstacles.indexOf(o);if(i>=0)B.obstacles.splice(i,1);
  B.nav=null;emit('obs_del',B.tick,o.id);
 }
 /* برمی‌گرداند false اگر گلوله تمام شد. why: 'oob' | 'wall' | 'hit' */
 function stepBullet(bu){
  if(bu.x<0||bu.x>B.w||bu.y<0||bu.y>B.h){bu.why='oob';return false;}
  const wo=wallAt(bu.x,bu.y);if(wo){hitObstacle(wo,bu);bu.why='wall';return false;}
  for(const t of B.ents){
   if(!t.alive||t===bu.owner)continue;
   if(Math.hypot(bu.x-t.x,bu.y-t.y)<t.r+5){
    damage(t,BULLET_DMG,bu.owner);bu.why='hit';
    if(!t.alive&&bu.owner){
     bu.owner.score++;
     /* شارژ جان بعد از کشتن فقط برای ربات‌های برنامه‌دار (مثل بازیکن در زمین تمرینی) */
     if(bu.owner.human&&bu.owner.alive&&bu.owner.hp<bu.owner.maxHp){const h=Math.min(KILL_HEAL,bu.owner.maxHp-bu.owner.hp);bu.owner.hp+=h;emit('heal',B.tick,bu.owner.id,Math.round(h));}}
    return false;}
  }
  return true;
 }
 function updateBullets(){
  const out=[];
  for(const bu of B.bullets){
   let alive=true;const sub=4;
   for(let s=0;s<sub&&alive;s++){bu.x+=bu.vx/sub;bu.y+=bu.vy/sub;alive=stepBullet(bu);}
   bu.life--;
   if(alive&&bu.life>0)out.push(bu);
   else emit('bdie',B.tick,bu.id,r1(bu.x),r1(bu.y),alive?'life':bu.why);
  }
  B.bullets=out;
 }
 return{rnd,emit,pointInWall,wallAt,hitWall,resolveWallContacts,clampInArena,requestMotion,applyMotion,resolveRobotCollisions,hasLOS,wallInPath,findPath,simplePathStep,fireBulletFrom,damage,updateBullets};
}
module.exports={createCore,BASE_SPEED,BULLET_SPEED,BULLET_DMG,PLAYER_CD,KILL_HEAL,clamp,normAng,r1};
