'use strict';
module.exports={...require('./royale'),seedRand:require('./rng').seedRand,layout:require('./layout')};
