'use strict';
/* ساخت زمین بتل رویال از سلول‌ها (همان منطق mergeCells و trainPad در public/home.js، بدون DOM). */
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const CELL=50,WALL=25;

function mergeCells(cells,cw,ch){const out=[];
 for(const t of new Set(Object.values(cells))){let act={};
  for(let j=0;j<=ch;j++){const runs=[];let i=0;
   while(j<ch&&i<cw){if(cells[i+','+j]===t){let k=i;while(k+1<cw&&cells[(k+1)+','+j]===t)k++;runs.push([i,k]);i=k+1;}else i++;}
   const nx={};for(const[a,b]of runs){const key=a+'-'+b;if(act[key]){act[key].h+=CELL;nx[key]=act[key];}else{const r={x:a*CELL,y:j*CELL,w:(b-a+1)*CELL,h:CELL,type:t};out.push(r);nx[key]=r;}}
   act=nx;}}
 return out;}

/* نقشهٔ پیش‌فرض: همان public/royale-map.js (تنها منبع حقیقت) */
function defaultRoyale(){
 const src=fs.readFileSync(path.join(__dirname,'..','public','royale-map.js'),'utf8'),win={};
 vm.runInNewContext(src,{window:win});
 const M=win.ROYALE_MAP,c=([i,j])=>[i*CELL+CELL/2,j*CELL+CELL/2],cells={};
 M.rows.forEach((r,j)=>{for(let i=0;i<r.length;i++)if(r[i]==='#')cells[i+','+j]='building';});
 return{cw:M.cw,ch:M.ch,cells,spawns:M.spawns.map(c),chests:[]};/* پیکسلی */
}

/* خروجی: {w,h,obstacles,spawns,chests} آمادهٔ موتور. ورودی: چیدمان ویرایشگر (cw,ch,cells,spawns,chests) */
function build(L){
 L=L||defaultRoyale();
 const W=L.cw*CELL,H=L.ch*CELL,cl={};
 for(const k of Object.keys(L.cells||{})){const[i,j]=k.split(',').map(Number);if(i>=1&&j>=1&&i<L.cw-1&&j<L.ch-1)cl[k]=L.cells[k];}
 const obstacles=[{x:0,y:0,w:W,h:WALL,type:'wall'},{x:0,y:H-WALL,w:W,h:WALL,type:'wall'},{x:0,y:0,w:WALL,h:H,type:'wall'},{x:W-WALL,y:0,w:WALL,h:H,type:'wall'}];
 for(const r of mergeCells(cl,L.cw,L.ch)){
  if(r.type==='crate'){for(let i=0;i<Math.max(1,Math.round(r.w/CELL));i++)for(let j=0;j<Math.max(1,Math.round(r.h/CELL));j++)obstacles.push({x:r.x+i*CELL,y:r.y+j*CELL,w:CELL,h:CELL,type:'crate',hp:40,maxHp:40});continue;}
  obstacles.push(r);}
 obstacles.forEach((o,i)=>{o.id=i;});
 const px=([i,j])=>[i*CELL+CELL/2,j*CELL+CELL/2];
 /* ذخیرهٔ ویرایشگر هم سلولی (spawns_cell) دارد هم پیکسلی (spawns)؛ سلولی مرجع است. بدون آن، spawns پیکسلی فرض می‌شود. */
 const spawns=L.spawns_cell?L.spawns_cell.map(px):(L.spawns||[]).map(p=>p.slice());
 const chests=L.chests_cell?L.chests_cell.map(px):(L.chests||[]).map(p=>p.slice());
 return{w:W,h:H,obstacles,spawns,chests};
}

module.exports={CELL,WALL,mergeCells,defaultRoyale,build};
