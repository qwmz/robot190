'use strict';
/* مسابقهٔ بتل رویال بدون DOM — پورت startRoyale/royaleTick/royaleAI/growZone (public/home.js) و botAI/tick (public/index.html).
   استفاده:  const m=createMatch({seed, layout, players:[{name,color,prog}]});  هر ۱/۶۰ ثانیه m.step();
   هر ۴ تیک m.snapshot() و m.drainEvents() را برای کاربر بفرست. */
const{seedRand}=require('./rng');
const layoutLib=require('./layout');
const{createCore,BASE_SPEED,BULLET_SPEED,clamp,normAng,r1}=require('./core');
const{createBrain}=require('./brain');
const TPS=60,ZONE_T=7*TPS,ROYALE_EVERY=6,N_ROBOTS=10;/* royaleTick در بازی اصلی هر ۱۰۰ms اجرا می‌شود = هر ۶ تیک */
const GREY='#9ca3af';
const dropN=n=>Math.max(1,Math.floor(((n||0)+1)/2));
/* جام: هر چه سطح بالاتر، همان رتبه جام کمتری می‌دهد. رتبه‌های آخر منفی */
const ROY_BASE=[10,8,6,5,4,3,1,0,-1,-2];
const rewardOf=(rank,lv)=>{const d=Math.round(ROY_BASE[rank-1]-1.5*(lv-1));return rank===1?Math.max(d,3):d;};

/* مستطیل‌های حلقهٔ k ام زون (دیوار می‌شوند) */
function zoneRects(k,W,H){const a=k===1?0:50*k,b=50*(k+1),T=b-a;
 return[{x:a,y:a,w:W-2*a,h:T},{x:a,y:H-b,w:W-2*a,h:T},{x:a,y:b,w:T,h:H-2*b},{x:W-b,y:b,w:T,h:H-2*b}];}

function createMatch(opts){
 const seed=opts.seed|0,rng=seedRand(seed),L=layoutLib.build(opts.layout);
 const B={w:L.w,h:L.h,obstacles:L.obstacles,bullets:[],cubes:[],ents:[],robots:[],chests:[],tick:0,nav:null,ev:[],rng,nextBid:1,nextQid:1,k:0,kMax:Math.floor(Math.min(L.w,L.h)/100)-4,over:false,ranks:{}};
 const core=createCore(B),{rnd,emit,hitWall,applyMotion,resolveRobotCollisions,simplePathStep,requestMotion,fireBulletFrom,hasLOS,updateBullets,resolveWallContacts}=core;
 let nextObs=B.obstacles.length;
 const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=(rng()*(i+1))|0;[a[i],a[j]]=[a[j],a[i]];}return a;};
 const blocked=(x,y,m)=>B.obstacles.some(o=>x>o.x-m&&x<o.x+o.w+m&&y>o.y-m&&y<o.y+o.h+m);
 function spawnPoints(){const pts=shuffle(L.spawns.map(p=>p.slice()));
  for(let t=0;pts.length<N_ROBOTS&&t<800;t++){const x=90+rng()*(B.w-180),y=90+rng()*(B.h-180);if(!blocked(x,y,30)&&pts.every(p=>Math.hypot(p[0]-x,p[1]-y)>160))pts.push([x,y]);}
  while(pts.length<N_ROBOTS)pts.push([B.w/2+pts.length*30,B.h/2]);
  return pts.slice(0,N_ROBOTS);}

 /* ---------- ساخت ربات‌ها ---------- */
 const cx=B.w/2,cy=B.h/2,pts=spawnPoints(),players=(opts.players||[]).slice(0,N_ROBOTS);
 for(let i=0;i<N_ROBOTS;i++){
  const[x,y]=pts[i],p=players[i],human=!!(p&&p.prog);
  const r={id:i,kind:'bot',x,y,angle:Math.atan2(cy-y,cx-x),hp:100,maxHp:100,r:17,cool:human?0:30+((rng()*60)|0),alive:true,
   color:p&&p.color||GREY,name:p&&p.name||'ربات',score:0,cubes:0,human,royale:true,dropped:0,_pdx:0,_pdy:0,spd:0,bodyAng:0,_lx:undefined,_ly:undefined};
  r.bodyAng=r.angle;resolveWallContacts(r);
  if(human)r.brain=createBrain(B,core,p.prog);
  B.robots.push(r);B.ents.push(r);}
 for(const[x,y]of L.chests){
  const z={id:N_ROBOTS+B.chests.length,kind:'chest',chest:true,x,y,angle:Math.PI/2,hp:120,maxHp:120,r:24,cool:1e9,alive:true,color:'#f5b43a',name:'صندوق',score:0,dropped:0,still:[x,y],_pdx:0,_pdy:0,spd:0};
  resolveWallContacts(z);z.still=[z.x,z.y];B.chests.push(z);B.ents.push(z);}

 /* ---------- هوش ربات خاکستری (botAI) و انتخاب هدف (royaleAI) ---------- */
 function botAI(z,P){
  if(!P.alive)return;
  const dx=P.x-z.x,dy=P.y-z.y,d=Math.hypot(dx,dy)||1,sp=BASE_SPEED*.92;
  const pv=z.pv||(z.pv={x:P.x,y:P.y,vx:0,vy:0});
  pv.vx+=((P.x-pv.x)-pv.vx)*.25;pv.vy+=((P.y-pv.y)-pv.vy)*.25;pv.x=P.x;pv.y=P.y;
  const lead=Math.min(45,d/BULLET_SPEED)*.55,want=Math.atan2(P.y+pv.vy*lead-z.y,P.x+pv.vx*lead-z.x);
  z.angle+=clamp(normAng(want-z.angle),-.2,.2);
  const los=hasLOS(z,P),hpf=z.hp/z.maxHp;
  const wallIn=(m)=>core.wallInPath(z.x,z.y,z.x+m.x*18,z.y+m.y*18,z.r+3);
  const away=()=>{let m={x:-dx/d*sp,y:-dy/d*sp};if(wallIn(m))m={x:-dy/d*sp,y:dx/d*sp};return m;};
  const strafe=()=>{if(!(z.sT>0)){z.sT=rnd(35,100)|0;z.sD=rng()<.5?1:-1;}z.sT--;
   let m={x:-dy/d*z.sD*sp,y:dx/d*z.sD*sp};if(wallIn(m)){z.sD=-z.sD;m={x:-m.x,y:-m.y};}return m;};
  let mv=null;
  if(hpf<.3&&d<380)mv=away();
  else if(!los||d>420)mv=simplePathStep(z,P.x,P.y,sp);
  else if(d<190)mv=away();
  else if(d>330)mv=simplePathStep(z,P.x,P.y,sp*.9);
  else mv=strafe();
  if(mv)requestMotion(z,mv.x,mv.y);
  const sprd=.03+d*.00011;
  if(z.cool<=0&&los&&d<700&&Math.abs(normAng(want-z.angle))<.14){fireBulletFrom(z,z.angle+rnd(-sprd,sprd));z.cool=hpf<.5?22:26;}
  if(z.cool>0)z.cool--;
 }
 /* نزدیک‌ترین ربات (حتی ربات‌های دیگر)، وگرنه انرژی، وگرنه صندوق */
 function royaleAI(z){
  let best=null,bd=1e9;
  for(const e of B.robots)if(e!==z&&e.alive){const d=Math.hypot(e.x-z.x,e.y-z.y);if(d<bd){bd=d;best=e;}}
  let cq=null,cd=1e9;for(const q of B.cubes){const d=Math.hypot(q.x-z.x,q.y-z.y);if(d<cd){cd=d;cq=q;}}
  if(cq&&cd<800&&(!best||bd>380)){const s=simplePathStep(z,cq.x,cq.y,BASE_SPEED*.92);if(s)requestMotion(z,s.x,s.y);
   z.angle+=clamp(normAng(Math.atan2(cq.y-z.y,cq.x-z.x)-z.angle),-.2,.2);if(z.cool>0)z.cool--;return;}
  let tg=best;
  if(!best||bd>650){let ch=null,hd=1e9;for(const c of B.chests)if(c.alive){const d=Math.hypot(c.x-z.x,c.y-z.y);if(d<hd){hd=d;ch=c;}}if(ch&&hd<900)tg=ch;}
  if(!tg){if(z.cool>0)z.cool--;return;}
  if(z._tg!==tg){z._tg=tg;z.pv=null;}
  botAI(z,tg);
 }

 /* ---------- انرژی، زون، ترمیم، رتبه (royaleTick) ---------- */
 function dropCubes(x,y,n){for(let i=0;i<n;i++){const a=rng()*6.283,d=i?26+rng()*26:0;let qx=x+Math.cos(a)*d,qy=y+Math.sin(a)*d;
  if(qx<60||qx>B.w-60||qy<60||qy>B.h-60||blocked(qx,qy,14)){qx=x;qy=y;}
  const q={id:B.nextQid++,x:qx,y:qy};B.cubes.push(q);emit('cube',B.tick,q.id,r1(qx),r1(qy));}}
 function growZone(k){const W=B.w,Hh=B.h,b=50*(k+1);
  for(const r of zoneRects(k,W,Hh))B.obstacles.push({...r,type:'wall',id:nextObs++,zone:k});
  B.nav=null;
  const cl=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
  for(const r of B.robots)if(r.alive){const m=b+r.r+2;r.x=cl(r.x,m,W-m);r.y=cl(r.y,m,Hh-m);}
  for(const q of B.cubes){q.x=cl(q.x,b+20,W-b-20);q.y=cl(q.y,b+20,Hh-b-20);}
  for(const z of B.chests)if(z.alive&&(z.x<b+z.r||z.x>W-b-z.r||z.y<b+z.r||z.y>Hh-b-z.r)){z.alive=false;z.dropped=1;}
  emit('zone',B.tick,k);}
 function royaleTick(){
  for(const z of B.chests){if(z.alive){z.x=z.still[0];z.y=z.still[1];}else if(!z.dropped){z.dropped=1;dropCubes(z.x,z.y,1);}}
  for(const r of B.robots)if(!r.alive&&!r.dropped){r.dropped=1;dropCubes(r.x,r.y,dropN(r.cubes));}
  const rob=B.robots.filter(r=>r.alive);
  B.cubes=B.cubes.filter(q=>{for(const r of rob)if(Math.hypot(r.x-q.x,r.y-q.y)<r.r+30){r.cubes++;r.maxHp+=10;r.hp=Math.min(r.maxHp,r.hp+10);emit('pick',B.tick,r.id,q.id,r.cubes);return false;}return true;});
  /* ترمیم: ۲ ثانیه بعد از آخرین شلیک، هر ۱ ثانیه ۱۰٪ جان */
  for(const r of rob)if(r.hp<r.maxHp&&B.tick-(r._lf||0)>=120&&B.tick-(r._lh||0)>=60){r._lh=B.tick;const h=Math.min(r.maxHp-r.hp,r.maxHp*.1);r.hp+=h;emit('heal',B.tick,r.id,Math.round(h));}
  const nk=Math.min(B.kMax,Math.floor(B.tick/ZONE_T));while(B.k<nk)growZone(++B.k);
  rankDeaths();
 }
 /* رتبه: هر که در این لحظه مرده، رتبه‌اش = تعداد زنده‌ها + تعداد مرده‌های هم‌زمان که پشت سرش رتبه می‌گیرند */
 function rankDeaths(){
  const alive=B.robots.filter(r=>r.alive).length,dead=B.robots.filter(r=>!r.alive&&B.ranks[r.id]===undefined);
  const humansInThisWave=B.robots.filter(r=>r.human&&B.ranks[r.id]===undefined&&(r.alive||dead.includes(r))).length;let humanDeadIndex=0;
  dead.forEach((r,i)=>{B.ranks[r.id]=alive+dead.length-i;const humanRank=r.human?humansInThisWave-humanDeadIndex++:null;emit('rank',B.tick,r.id,B.ranks[r.id],humanRank);});
  if(alive<=1&&!B.over)finish();}
 const MAX_TICKS=ZONE_T*(B.kMax+1)+TPS*120;
 function finish(){
  B.over=true;
  const left=B.robots.filter(r=>r.alive).sort((a,b)=>b.hp-a.hp);/* پایان با سقف زمان: بیشترین جان بالاتر */
  let humanRank=0;left.forEach((r,i)=>{B.ranks[r.id]=i+1;if(r.human)humanRank++;emit('rank',B.tick,r.id,i+1,r.human?humanRank:null);});
  emit('end',B.tick,B.ranks);}

 /* ---------- یک تیک ---------- */
 function step(){
  if(B.over)return;
  B.tick++;
  const alive=B.ents.filter(e=>e.alive);
  for(const r of B.robots){if(!r.alive)continue;
   if(r.brain)r.brain.tick(r,alive.filter(e=>e!==r&&e.alive));else royaleAI(r);}
  for(const e of alive)applyMotion(e);
  resolveRobotCollisions();
  for(const r of B.robots){if(!r.alive)continue;
   const mx=r.x-(r._lx===undefined?r.x:r._lx),my=r.y-(r._ly===undefined?r.y:r._ly);r._lx=r.x;r._ly=r.y;r.spd=Math.hypot(mx,my);
   if(r.spd>.4)r.bodyAng+=clamp(normAng(Math.atan2(my,mx)-r.bodyAng),-.2,.2);
   if(r.human&&r.cool>0)r.cool--;}
  updateBullets();
  if(B.tick%ROYALE_EVERY===0)royaleTick();
  if(!B.over&&B.tick>=MAX_TICKS)finish();
 }

 /* ---------- خروجی برای کاربر ---------- */
 const q10=v=>Math.round(v*10)/10;
 function snapshot(){
  return{t:B.tick,k:B.k,
   r:B.robots.map(r=>[r.id,q10(r.x),q10(r.y),Math.round(r.angle*100),Math.round(r.bodyAng*100),Math.round(r.hp),r.maxHp,r.cubes,r.alive?1:0]),
   c:B.chests.map(z=>[z.id,z.alive?1:0,Math.round(z.hp)]),
   left:B.robots.filter(r=>r.alive).length};}
 /* وضعیت کامل برای شروع یا اتصال مجدد */
 function init(){
  return{seed,tickRate:TPS,w:B.w,h:B.h,kMax:B.kMax,zoneTicks:ZONE_T,
   obstacles:B.obstacles.map(o=>({id:o.id,x:o.x,y:o.y,w:o.w,h:o.h,type:o.type,hp:o.hp,zone:o.zone})),
   robots:B.robots.map(r=>({id:r.id,name:r.name,color:r.color,r:r.r,human:r.human})),
   chests:B.chests.map(z=>({id:z.id,x:z.x,y:z.y,r:z.r})),
   cubes:B.cubes.map(q=>({id:q.id,x:q.x,y:q.y})),
   bullets:B.bullets.map(b=>({id:b.id,owner:b.owner.id,x:q10(b.x),y:q10(b.y),vx:q10(b.vx),vy:q10(b.vy),life:b.life})),
   snapshot:snapshot()};}
 function drainEvents(){const e=B.ev;B.ev=[];return e;}
 function forfeit(robotId){
  const r=B.robots[robotId];
  if(!r||!r.human||!r.alive||B.ranks[robotId]!==undefined)return false;
  const humanRank=B.robots.filter(x=>x.human&&B.ranks[x.id]===undefined).length;
  const totalRank=B.robots.length-Object.keys(B.ranks).length;
  r.alive=false;B.ranks[robotId]=totalRank;emit('rank',B.tick,robotId,totalRank,humanRank);
  return true;
 }
 return{B,step,snapshot,init,drainEvents,forfeit,get over(){return B.over;},get tick(){return B.tick;},ranks:()=>({...B.ranks})};
}
module.exports={createMatch,rewardOf,zoneRects,ZONE_T,TPS,N_ROBOTS};
