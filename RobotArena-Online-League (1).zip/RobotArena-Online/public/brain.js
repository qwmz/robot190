'use strict';
/* مغز ربات (برنامه‌ی رفتار آزاد): جمله ← هوش مصنوعی ← برنامه‌ی JSON ← Behavior.runner.
   اینجا فقط «چسب» است: حسگرها را از موتور بازی می‌خواند و خروجی برنامه را به حرکت، هدف و شلیک تبدیل می‌کند.
   اگر برنامه‌ای نباشد، همان playerAI قدیمی کار می‌کند. */
(function(){
const LS='ra_prog_v1',$=s=>document.querySelector(s);
const B0=window.Behavior;
let cur=null;// {prog}: برنامه‌ی ترکیبی حرکت + (هدف و شلیک)
let st={battle:null},parts={move:null,shoot:null};// هر تب برنامه‌ی خودش را دارد: {text,prog}
const TABS={
 move:{n:'حرکت',i:'🏃',c:'#1cb0f6',d:'ربات کِی و چطور جابه‌جا شود؟',ph:''},
 shoot:{n:'تیراندازی',i:'🎯',c:'#ff9600',d:'ربات کِی به کدام دشمن و چطور شلیک کند؟',ph:''}};
function rebuild(){const m=parts.move&&parts.move.prog,h=parts.shoot&&parts.shoot.prog;
 const c=B0.compile({move:m&&m.move,target:h&&h.target,fire:h&&h.fire});cur=c.prog?{prog:c.prog}:null;st={battle:null};}
function load(){try{const j=JSON.parse(localStorage.getItem(LS));if(!j)return;
 if(j.parts){for(const k of ['move','shoot'])if(j.parts[k]&&j.parts[k].prog)parts[k]={text:String(j.parts[k].text||''),prog:j.parts[k].prog};}
 else if(j.prog){const t=String(j.text||'');parts.move={text:t,prog:{move:j.prog.move}};parts.shoot={text:t,prog:{target:j.prog.target,fire:j.prog.fire}};}
 rebuild();}catch(e){}}
function save(){try{if(parts.move||parts.shoot)localStorage.setItem(LS,JSON.stringify({parts}));else localStorage.removeItem(LS);}catch(e){}}
load();
const feat=()=>cur?B0.features(cur.prog):null;

/* ---------- حسگرها از موتور ---------- */
const rectDist=(x,y,o)=>{const dx=Math.max(o.x-x,0,x-(o.x+o.w)),dy=Math.max(o.y-y,0,y-(o.y+o.h));return Math.hypot(dx,dy);};
/* انرژیی که هیچ ربات دیگری (در شعاع ۳۵۰) نزدیکش نیست */
const cubesSafe=(B,robots)=>(B.cubes||[]).filter(q=>!robots.some(z=>Math.hypot(z.x-q.x,z.y-q.y)<350));
function sensors(P,Z,B){
 /* صندوق «دشمن» حساب نمی‌شود، مگر وقتی هیچ ربات دیگری نمانده (مرحلهٔ صندوق) */
 const all=Z.filter(z=>z.alive!==false),real=all.filter(z=>!z.chest),live=real.length?real:all,dist=z=>Math.hypot(z.x-P.x,z.y-P.y);
 let nearest=null,nd=1e9;for(const z of live){const d=dist(z);if(d<nd){nd=d;nearest=z;}}
 const safeCubes=()=>cubesSafe(B,real);
 return function(name,r){
  switch(name){
   case 'hp':return P.hp/P.maxHp*100;
   case 'dist_nearest':return nearest?nd:9999;
   case 'enemies':return live.filter(z=>dist(z)<900).length;
   case 'enemies_within':return live.filter(z=>dist(z)<(r||450)).length;
   case 'enemy_hp':return nearest?nearest.hp/nearest.maxHp*100:100;
   case 'x_pct':return P.x/ARENA.w*100;
   case 'y_pct':return P.y/ARENA.h*100;
   case 'wall_dist':{let m=1e9;for(const o of B.obstacles)m=Math.min(m,rectDist(P.x,P.y,o)-P.r);return Math.max(0,Math.min(m,2000));}
   case 'time':return B.tick/60;
   case 'still_time':return (B.tick-st.moveTick)/60;
   case 'hit':return B.tick-st.hitTick<60;
   case 'bullet':return B.bullets.some(b=>!b.ownerIsPlayer&&Math.hypot(b.x-P.x,b.y-P.y)<280&&(b.vx*(P.x-b.x)+b.vy*(P.y-b.y))>0);
   case 'exposed':return live.some(z=>dist(z)<700&&hasLOS(z,P));
   case 'runner':return live.some(z=>z.kind==='runner'&&dist(z)<900);
   case 'spitter':return live.some(z=>z.kind==='spitter'&&dist(z)<900);
   case 'brute':return live.some(z=>z.kind==='brute'&&dist(z)<900);
   case 'cubes':return B.cubes?B.cubes.length:0;
   case 'dist_cube':{let m=9999;if(B.cubes)for(const q of B.cubes)m=Math.min(m,Math.hypot(q.x-P.x,q.y-P.y));return m;}
   case 'chest':return all.some(z=>z.chest);
   case 'dist_chest':{let m=9999;for(const z of all)if(z.chest)m=Math.min(m,dist(z));return m;}
   case 'safe_cube':return safeCubes().length>0;
   case 'dist_safe_cube':{let m=9999;for(const q of safeCubes())m=Math.min(m,Math.hypot(q.x-P.x,q.y-P.y));return m;}
   case 'power':return (P.cubes||0)+1;
   case 'enemy_power':return nearest?(nearest.cubes||0)+1:1;
   case 'robots_left':return real.length+1;}
  return 0;};
}
function resolvePt(spec,P,Z){
 const all=Z.filter(z=>z.alive!==false),real=all.filter(z=>!z.chest),live=real.length?real:all;
 const by=(f)=>{let b=null,v=-1e9;for(const z of live){const s=f(z);if(s>v){v=s;b=z;}}return b;};
 if(spec.to==='center')return{x:ARENA.w/2,y:ARENA.h/2};
 if(spec.to==='start')return{x:st.x0,y:st.y0};
 if(spec.to==='nearest'){const z=by(z=>-Math.hypot(z.x-P.x,z.y-P.y));return z?{x:z.x,y:z.y}:null;}
 if(spec.to==='farthest'){const z=by(z=>Math.hypot(z.x-P.x,z.y-P.y));return z?{x:z.x,y:z.y}:null;}
 if(spec.to==='chest'){const z=all.find(z=>z.chest);return z?{x:z.x,y:z.y}:null;}
 if(spec.to==='safe_cube'){let b=null,d=1e9;for(const q of cubesSafe(battle,real)){const k=Math.hypot(q.x-P.x,q.y-P.y);if(k<d){d=k;b=q;}}return b?{x:b.x,y:b.y}:null;}
 if(spec.to==='cube'){let b=null,d=1e9;for(const q of battle.cubes||[]){const k=Math.hypot(q.x-P.x,q.y-P.y);if(k<d){d=k;b=q;}}return b?{x:b.x,y:b.y}:null;}
 if(spec.to==='gem'&&battle.cubes){let b=null,d=1e9;for(const q of battle.cubes){const k=Math.hypot(q.x-P.x,q.y-P.y);if(k<d){d=k;b=q;}}return b?{x:b.x,y:b.y}:null;}
 if(spec.to==='gem'){const g=battle.gem;return g&&!g.got?{x:g.x,y:g.y}:null;}
 if(spec.to==='top')return{x:ARENA.w/2,y:ARENA.h*.1};
 if(spec.to==='bottom')return{x:ARENA.w/2,y:ARENA.h*.9};
 if(spec.to==='left')return{x:ARENA.w*.1,y:ARENA.h/2};
 if(spec.to==='right')return{x:ARENA.w*.9,y:ARENA.h/2};
 if(spec.px!==undefined)return{x:ARENA.w*spec.px,y:ARENA.h*spec.py};
 return null;}
const clampPt=(x,y)=>({x:Math.max(70,Math.min(ARENA.w-70,x)),y:Math.max(70,Math.min(ARENA.h-70,y))});

function pickTarget(P,Z,who){
 let vis=Z.filter(z=>z.alive!==false&&Math.hypot(z.x-P.x,z.y-P.y)<900);if(who!=='chest'&&vis.some(z=>!z.chest))vis=vis.filter(z=>!z.chest);let best=null,bs=-1e9;
 for(const z of vis){const d=Math.hypot(z.x-P.x,z.y-P.y);
  const s=who==='farthest'?d:who==='weakest'?-z.hp*1000-d:who==='strongest'?z.hp*1000-d:who==='chest'?(z.chest?1e4:0)-d:who==='runner'||who==='spitter'||who==='brute'?(z.kind===who?1e4:0)-d:-d;
  if(s>bs){bs=s;best=z;}}
 return best;}

/* ---------- برنامه‌ی دیدنی: مسیر و هدفی که ربات الان دارد (برای افکت نمایش) ---------- */
function goAngle(m,P,ne){
 if(typeof m.dir==='number')return(m.dir-90)*Math.PI/180;
 if(m.dir==='toward'||m.dir==='away'){if(!ne)return null;return Math.atan2(ne.y-P.y,ne.x-P.x)+(m.dir==='away'?Math.PI:0);}
 return(({up:0,right:90,down:180,left:270})[m.dir]-90)*Math.PI/180;}
function routeTo(P,tx,ty){const c=clampPt(tx,ty),R=st.route;
 if(R&&Math.hypot(R.tx-c.x,R.ty-c.y)<=90)return[{x:P.x,y:P.y},...R.pts.slice(R.i),c];
 if(!wallInPath(P.x,P.y,c.x,c.y,P.r+3))return[{x:P.x,y:P.y},c];
 let pts=[];try{pts=findPath(P.x,P.y,c.x,c.y)||[];}catch(e){}return[{x:P.x,y:P.y},...pts,c];}
/* دنبال‌کردن با تعهد: تا وقتی مقصد عوض نشده و ربات گیر نکرده، همان مسیر را می‌رود.
   (بدون این، هر چند ثانیه مسیر دوباره ساخته می‌شد و بین دو راه دورِ تقریباً هم‌ارزش رفت‌وبرگشت می‌کرد.) */
function follow(P,tx,ty,spd,B){
 const c=clampPt(tx,ty),sp=PSPD*(spd||1),dx=c.x-P.x,dy=c.y-P.y,d=Math.hypot(dx,dy);
 if(d<10)return null;
 if(!wallInPath(P.x,P.y,c.x,c.y,P.r+3)){st.route=null;return{x:dx/d*sp,y:dy/d*sp};}
 let R=st.route;
 if(!R||Math.hypot(R.tx-c.x,R.ty-c.y)>90||B.tick-st.moveTick>40||B.tick-R.t>900){
  let pts=[];try{pts=findPath(P.x,P.y,c.x,c.y)||[];}catch(e){}R=st.route={tx:c.x,ty:c.y,pts,i:0,t:B.tick};}
 if(!R.pts.length)return{x:dx/d*sp,y:dy/d*sp};
 while(R.i<R.pts.length-1&&(Math.hypot(R.pts[R.i].x-P.x,R.pts[R.i].y-P.y)<26||!wallInPath(P.x,P.y,R.pts[R.i+1].x,R.pts[R.i+1].y,P.r+3)))R.i++;
 const w=R.pts[R.i],wx=w.x-P.x,wy=w.y-P.y,wd=Math.hypot(wx,wy)||1;
 return{x:wx/wd*sp,y:wy/wd*sp};}
function planOf(m,P,Z,ne){
 if(!m)return null;
 switch(m.kind){
  case 'goto':{const p=resolvePt(m,P,Z);return p?{k:'route',pts:routeTo(P,p.x,p.y)}:null;}
  case 'go':{const a=goAngle(m,P,ne);return a===null?null:{k:'route',pts:routeTo(P,P.x+Math.cos(a)*340,P.y+Math.sin(a)*340)};}
  case 'orbit':{const c=resolvePt({to:m.around},P,Z);return c?{k:'orbit',x:c.x,y:c.y,r:m.r,cw:m.cw}:null;}
  case 'keep':return ne?{k:'ring',x:ne.x,y:ne.y,r:m.dist}:null;
  case 'flee':{let fx=0,fy=0;for(const z of Z){if(z.alive===false)continue;const d=Math.hypot(z.x-P.x,z.y-P.y);if(d<420&&d>0){fx+=(P.x-z.x)/(d*d);fy+=(P.y-z.y)/(d*d);}}
   const mm=Math.hypot(fx,fy);return mm>0?{k:'route',pts:routeTo(P,P.x+fx/mm*320,P.y+fy/mm*320),warn:true}:null;}
  case 'stop':return{k:'stop'};}
 return null;}

/* «برو بالا» و مانند آن: اگر مانعی جلوی راه بود، ربات کنار مانع می‌لغزد و بعد دوباره در همان جهت می‌رود
   (قبلاً مستقیم به دیوار می‌چسبید و گیر می‌کرد). طرفی که یک‌بار انتخاب شد حفظ می‌شود تا ربات دو طرف را رفت‌وبرگشت نکند. */
function goSlide(P,a,spd){
 const sp=PSPD*(spd||1),look=70,ok=t=>!wallInPath(P.x,P.y,P.x+Math.cos(t)*look,P.y+Math.sin(t)*look,P.r+3);
 let ang=a;
 if(!ok(a)){const side=st.slide||1;let found=null;
  for(const d of [25,50,75,100,125,150]){for(const s of [side,-side]){const t=a+s*d*Math.PI/180;if(ok(t)){found=t;st.slide=s;break;}}if(found!==null)break;}
  if(found===null)return null;ang=found;}
 return{x:Math.cos(ang)*sp,y:Math.sin(ang)*sp};}

/* ---------- یک تیک تصمیم برای ربات بازیکن ---------- */
function brainTick(P,Z){
 const B=battle;
 if(st.battle!==B){st={battle:B,run:B0.runner(cur.prog),x0:P.x,y0:P.y,lx:P.x,ly:P.y,moveTick:B.tick,hitTick:-999,lastHp:P.hp,tgt:null};}
 if(P.hp<st.lastHp-.01)st.hitTick=B.tick;st.lastHp=P.hp;
 if(Math.hypot(P.x-st.lx,P.y-st.ly)>1.2){st.moveTick=B.tick;st.lx=P.x;st.ly=P.y;}
 const sen=sensors(P,Z,B);
 const out=st.run.step({tick:B.tick,sensor:sen,reached:spec=>{const p=resolvePt(spec,P,Z);return p&&Math.hypot(p.x-P.x,p.y-P.y)<45;}});
 /* حرکت */
 /* صندوق «دشمن» حساب نمی‌شود (وگرنه ربات وسط درگیری سراغ صندوق می‌رفت)، مگر وقتی ربات دیگری نمانده */
 let mv=null;const m=out.move,all0=Z.filter(z=>z.alive!==false),rl=all0.filter(z=>!z.chest),live=rl.length?rl:all0;
 let ne=null,nd=1e9,far=null,fd=-1;for(const z of live){const d=Math.hypot(z.x-P.x,z.y-P.y);if(d<nd){nd=d;ne=z;}if(d>fd){fd=d;far=z;}}
 const step=(p,spd)=>follow(P,p.x,p.y,spd,B);
 if(m){switch(m.kind){
  case 'go':{const a=goAngle(m,P,ne);if(a===null)break;
   mv=goSlide(P,a,m.spd)||step({x:P.x+Math.cos(a)*150,y:P.y+Math.sin(a)*150},m.spd);break;}
  case 'goto':{const p=resolvePt(m,P,Z);if(p&&Math.hypot(p.x-P.x,p.y-P.y)>30)mv=step(p,m.spd);break;}
  case 'orbit':{const c=resolvePt({to:m.around},P,Z);if(!c)break;const dx=P.x-c.x,dy=P.y-c.y,d=Math.hypot(dx,dy)||1,ux=dx/d,uy=dy/d,s=m.cw?1:-1,k=Math.max(-1,Math.min(1,(d-m.r)/120));
   const vx=-uy*s-ux*k,vy=ux*s-uy*k;mv=step({x:P.x+vx*140,y:P.y+vy*140},m.spd);break;}
  /* بیضی: مرکزش دشمن (یا نقطهٔ انتخابی)، قطر کانونی (قطر بزرگ) عمود بر خطی که من و مرکز را در لحظهٔ شروع درگیری به هم وصل می‌کند.
     جهت محور وقتی قفل می‌شود که درگیری شروع شود؛ تا درگیری ادامه دارد همان می‌ماند. */
  case 'ellipse':{const c=resolvePt({to:m.around},P,Z);if(!c)break;const ent=m.around==='nearest'?ne:m.around==='farthest'?far:null;
   const dx0=P.x-c.x,dy0=P.y-c.y,d0=Math.hypot(dx0,dy0)||1;let E=st.ell;
   if(!E||B.tick-E.t>20||E.ent!==ent||E.around!==m.around)E=st.ell={ent,around:m.around,ux:dx0/d0,uy:dy0/d0,t:B.tick};
   E.t=B.tick;const ux=E.ux,uy=E.uy,px=-uy,py=ux,rx=P.x-c.x,ry=P.y-c.y;
   const th=Math.atan2((rx*ux+ry*uy)/m.b,(rx*px+ry*py)/m.a),nt=th+(m.cw?1:-1)*.45;
   mv=step({x:c.x+px*m.a*Math.cos(nt)+ux*m.b*Math.sin(nt),y:c.y+py*m.a*Math.cos(nt)+uy*m.b*Math.sin(nt)},m.spd);break;}
  case 'keep':{if(!ne)break;const dx=(ne.x-P.x)/nd,dy=(ne.y-P.y)/nd;
   if(nd<m.dist-25){let ax=-dx,ay=-dy;if(wallInPath(P.x,P.y,P.x+ax*50,P.y+ay*50,P.r+3)){ax=-dy;ay=dx;}mv={x:ax*PSPD,y:ay*PSPD};}
   else if(nd>m.dist+45)mv=step(ne,1);else{const s=Math.sin(B.tick/70)>0?1:-1;mv={x:-dy*s*1.3,y:dx*s*1.3};}break;}
  case 'flee':{let fx=0,fy=0;for(const z of live){const d=Math.hypot(z.x-P.x,z.y-P.y);if(d<420&&d>0){fx+=(P.x-z.x)/(d*d);fy+=(P.y-z.y)/(d*d);}}
   const mm=Math.hypot(fx,fy);if(mm>0)mv=step({x:P.x+fx/mm*320,y:P.y+fy/mm*320},1.1);break;}
  case 'legacy':{if(m.a==='cover'||m.a==='breakout')mv=smartMove(P,Z,m.a);else mv=smartMove2(P,Z,m.a);break;}}}
 if(mv)requestMotion(P,mv.x,mv.y);
 /* هدف و شلیک */
 let who=out.target&&out.target.kind==='pick'?out.target.who:'nearest';
 /* دفاع از خود: هر برنامه‌ای (حتی «برو سمت صندوق») اگر رباتی نزدیک و دیدنی است یا تازه به من شلیک شده، هدف شلیک را از صندوق به همان ربات برمی‌گرداند */
 if(who==='chest'&&live.some(z=>!z.chest&&((Math.hypot(z.x-P.x,z.y-P.y)<520&&hasLOS(z,P))||(B.tick-st.hitTick<90&&Math.hypot(z.x-P.x,z.y-P.y)<900))))who='nearest';
 if(!st.tgt||!st.tgt.alive||B.tick%20===0)st.tgt=pickTarget(P,Z,who);else if(st.who!==who)st.tgt=pickTarget(P,Z,who);st.who=who;
 const tg=st.tgt,fire=out.fire&&out.fire.kind==='fire'?out.fire:{on:true,range:680};
 P.ruleKey='';
 if(tg){const dx=tg.x-P.x,dy=tg.y-P.y,d=Math.hypot(dx,dy),want=Math.atan2(dy,dx);
  P.angle+=clamp(normAng(want-P.angle),-.22,.22);tg.hasLOS=hasLOS(P,tg);
  if(fire.on&&P.cool<=0&&tg.hasLOS&&d<fire.range&&Math.abs(normAng(want-P.angle))<.14){const sp=.015+d*.00011;fireBulletFrom(P,P.angle+rnd(-sp,sp),true);P.cool=P.rapid>0?PLAYER_CD*.5:PLAYER_CD;}}
 else if(mv){const a=Math.atan2(mv.y,mv.x);P.angle+=clamp(normAng(a-P.angle),-.18,.18);}
 if(window.Brain.showPlan&&(!st.plan||B.tick%8===0))st.plan=planOf(m,P,Z,ne);
}
const _pa=window.playerAI;
window.playerAI=function(P,Z){if(cur&&window.Brain.on){return brainTick(P,Z);}return _pa.apply(this,arguments);};

/* ---------- افکت: مسیر برنامه‌ریزی‌شده (نئونی و متحرک) و دایره دور هدف فعلی ---------- */
function pathLen(pts){let L=0;for(let i=1;i<pts.length;i++)L+=Math.hypot(pts[i].x-pts[i-1].x,pts[i].y-pts[i-1].y);return L;}
function along(pts,d){for(let i=1;i<pts.length;i++){const l=Math.hypot(pts[i].x-pts[i-1].x,pts[i].y-pts[i-1].y);if(d<=l||i===pts.length-1){const f=l?Math.min(1,d/l):0;return{x:pts[i-1].x+(pts[i].x-pts[i-1].x)*f,y:pts[i-1].y+(pts[i].y-pts[i-1].y)*f};}d-=l;}return pts[pts.length-1];}
function strokeGlow(c,col,path){c.lineCap='round';c.lineJoin='round';
 for(const[w,a]of[[22,.07],[12,.14],[6,.3]]){c.lineWidth=w;c.strokeStyle='rgba('+col+','+a+')';path();c.stroke();}}
function drawPlan(c,P,t){
 const pl=st.plan;if(!pl)return;const col=pl.warn?'255,160,60':'34,211,238',core=pl.warn?'#ffd9a0':'#a5f3fc';
 c.save();c.globalCompositeOperation='lighter';
 if(pl.k==='route'&&pl.pts.length>1){const pts=pl.pts.slice();pts[0]={x:P.x,y:P.y};
  const path=()=>{c.beginPath();c.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)c.lineTo(pts[i].x,pts[i].y);};
  strokeGlow(c,col,path);
  c.setLineDash([16,14]);c.lineDashOffset=-t*70;c.lineWidth=3;c.strokeStyle=core;path();c.stroke();c.setLineDash([]);
  const L=pathLen(pts)||1;
  for(let k=0;k<5;k++){const q=along(pts,((t*.45+k/5)%1)*L);c.fillStyle='rgba('+col+',.9)';c.shadowColor='rgb('+col+')';c.shadowBlur=14;c.beginPath();c.arc(q.x,q.y,4.5,0,7);c.fill();}
  c.shadowBlur=0;
  const e=pts[pts.length-1],b=pts[pts.length-2],a=Math.atan2(e.y-b.y,e.x-b.x),pr=16+4*Math.sin(t*5);
  c.strokeStyle='rgba('+col+',.85)';c.lineWidth=3;c.beginPath();c.arc(e.x,e.y,pr,0,7);c.stroke();
  c.strokeStyle='rgba('+col+',.3)';c.lineWidth=2;c.beginPath();c.arc(e.x,e.y,pr+9,0,7);c.stroke();
  c.fillStyle=core;c.beginPath();c.moveTo(e.x+Math.cos(a)*10,e.y+Math.sin(a)*10);c.lineTo(e.x+Math.cos(a+2.5)*9,e.y+Math.sin(a+2.5)*9);c.lineTo(e.x+Math.cos(a-2.5)*9,e.y+Math.sin(a-2.5)*9);c.fill();}
 else if(pl.k==='orbit'||pl.k==='ring'){const orb=pl.k==='orbit',cc=orb?'34,211,238':'255,160,60',dir=orb?(pl.cw?1:-1):1;
  const path=()=>{c.beginPath();c.arc(pl.x,pl.y,pl.r,0,7);};
  strokeGlow(c,cc,path);c.setLineDash([18,14]);c.lineDashOffset=-t*70*dir;c.lineWidth=3;c.strokeStyle=orb?'#a5f3fc':'#ffd9a0';path();c.stroke();c.setLineDash([]);
  for(let k=0;k<4;k++){const a=t*.9*dir+k*Math.PI/2;c.fillStyle='rgba('+cc+',.95)';c.shadowColor='rgb('+cc+')';c.shadowBlur=14;c.beginPath();c.arc(pl.x+Math.cos(a)*pl.r,pl.y+Math.sin(a)*pl.r,5,0,7);c.fill();}c.shadowBlur=0;}
 else if(pl.k==='stop'){const r=P.r+14+5*Math.sin(t*4);c.strokeStyle='rgba(34,211,238,.8)';c.lineWidth=3;c.beginPath();c.arc(P.x,P.y,r,0,7);c.stroke();}
 c.restore();}
function drawTarget(c,P,t){
 const z=st.tgt;if(!z||z.alive===false)return;const R=z.r+16+2.5*Math.sin(t*5);
 c.save();c.globalCompositeOperation='lighter';
 c.strokeStyle='rgba(255,70,70,.14)';c.lineWidth=14;c.beginPath();c.arc(z.x,z.y,R,0,7);c.stroke();
 c.shadowColor='#ff4646';c.shadowBlur=14;c.strokeStyle='rgba(255,110,110,.95)';c.lineWidth=3;
 for(let k=0;k<4;k++){const a=t*1.6+k*Math.PI/2;c.beginPath();c.arc(z.x,z.y,R,a,a+Math.PI/3);c.stroke();}
 c.shadowBlur=0;c.strokeStyle='rgba(255,170,170,.55)';c.lineWidth=2;c.beginPath();c.arc(z.x,z.y,R+9,0,7);c.stroke();
 for(let k=0;k<4;k++){const a=k*Math.PI/2+Math.PI/4,x1=z.x+Math.cos(a)*(R+3),y1=z.y+Math.sin(a)*(R+3),x2=z.x+Math.cos(a)*(R+16),y2=z.y+Math.sin(a)*(R+16);c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();}
 if(z.hasLOS!==false){c.setLineDash([5,9]);c.lineDashOffset=-t*50;c.strokeStyle='rgba(255,110,110,.35)';c.lineWidth=2;c.beginPath();c.moveTo(P.x,P.y);c.lineTo(z.x,z.y);c.stroke();}
 c.restore();}
const _dr=window.drawRobot;
window.drawRobot=function(c,r,isPlayer,t){
 if(isPlayer&&cur&&window.Brain.showPlan&&window.Brain.on&&st.battle===battle){const rt=performance.now()/1000;try{drawPlan(c,r,rt);drawTarget(c,r,rt);}catch(e){}}
 return _dr.apply(this,arguments);};
/* دکمه‌ی کنار صفحه */
const css2=document.createElement('style');css2.textContent=`
#nPlan{position:fixed;right:10px;top:50%;transform:translateY(-50%);z-index:9;display:none;flex-direction:column;align-items:center;gap:3px;padding:10px 9px;border-radius:16px;border:2px solid #37464f;background:rgba(14,24,43,.88);color:#cfe1f5;font-family:Vazirmatn,Tahoma,sans-serif;font-weight:800;font-size:12px;cursor:pointer;backdrop-filter:blur(4px)}
#nPlan .ic{font-size:24px;line-height:1}body.nmode #nPlan{display:flex}
#nPlan:hover{border-color:#22d3ee}#nPlan.on{border-color:#22d3ee;color:#a5f3fc;background:rgba(8,60,80,.9);box-shadow:0 0 22px rgba(34,211,238,.55),inset 0 0 14px rgba(34,211,238,.25)}
`;document.head.append(css2);
document.body.insertAdjacentHTML('beforeend','<button id="nPlan" aria-pressed="false" title="نمایش مسیر و هدف ربات"><span class="ic">🧭</span><span>برنامه</span></button>');
$('#nPlan').onclick=()=>{window.Brain.showPlan=!window.Brain.showPlan;$('#nPlan').classList.toggle('on',window.Brain.showPlan);$('#nPlan').setAttribute('aria-pressed',window.Brain.showPlan);st.plan=null;};

/* ---------- صفحه‌ی نوشتن: همان ظاهر صفحه‌ی پرامت قبلی (کلاس‌های pm* از index.html)، بدون دکمه‌ی «بعدی» ---------- */
const css=document.createElement('style');css.textContent=`
#brainOv{--pb:#131f24;--pc:#1f2c34;--pl:#37464f;--pt:#f1f7fb;--pm:#8ea3ad;--g:#58cc02;--gs:#46a302;--am:#ff9600;--c:#1cb0f6;
 position:fixed;top:0;bottom:0;right:0;left:auto;width:var(--bw,440px);max-width:100vw;border-left:2px solid var(--pl);box-shadow:-12px 0 40px rgba(0,0,0,.45);z-index:35;display:none;flex-direction:column;background:var(--pb);color:var(--pt);direction:rtl;font-family:Vazirmatn,Tahoma,sans-serif}
#brainOv.on{display:flex;animation:tvIn .25s ease-out}
#brainOv button{font-family:inherit;color:inherit}
#brainOv h2{font-size:24px;font-weight:800;line-height:1.5;margin:6px 0 0}
body.bpanel .scr{right:var(--bpw,440px)}
body.bpanel #nPlan{right:calc(var(--bpw,440px) + 10px)}
body.bpanel #nCard{left:calc((100% - var(--bpw,440px))/2)}
#brainRz{position:absolute;left:-6px;top:0;bottom:0;width:14px;cursor:ew-resize;z-index:3;touch-action:none}
#brainRz::after{content:'';position:absolute;left:5px;top:50%;height:64px;width:4px;margin-top:-32px;border-radius:4px;background:var(--pl)}#brainRz:hover::after{background:var(--c)}
#brainTx{width:100%;display:block;min-height:150px;resize:vertical;background:var(--pc);color:var(--pt);border:2px solid var(--pl);border-bottom-width:5px;border-radius:18px;padding:14px 16px;font:inherit;font-size:16px;line-height:2.1}
#brainTx:focus{outline:none;border-color:var(--c)}#brainTx::placeholder{color:#5d727d}
#brainOv .pmbuildrow{display:flex;align-items:center;gap:10px;margin:10px 0}#brainOv .pmbuildrow .pmb{flex:0 0 auto;width:auto;padding:10px 22px}
#brainOv .pmb:disabled{opacity:.55}
#brainEx{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}
#brainEx span{font-size:12.5px;font-weight:700;padding:4px 12px;border-radius:99px;border:2px solid var(--pl);color:var(--pm);cursor:pointer}#brainEx span:hover{border-color:var(--c);color:var(--pt)}
#brainRes .pr{white-space:pre-wrap;line-height:1.9}
`;document.head.append(css);
document.body.insertAdjacentHTML('beforeend',`<div id="brainOv" role="dialog" aria-modal="true" aria-label="پرامت: طراحی ربات">
 <div id="brainRz" title="برای کوچک و بزرگ‌کردن بکش"></div>
 <div class="pmtop"><button id="brainClose" class="pmx" aria-label="بستن">✕</button><button id="brainBig" class="pmx" aria-label="بزرگ و کوچک" title="بزرگ / کوچک">⤢</button><div class="pmbar" aria-hidden="true"><i class="f"></i></div></div>
 <div class="pmscroll"><div class="pmcol">
  <div class="pmtabs" id="brainTabs" style="grid-template-columns:repeat(2,1fr)"></div>
  <h2 id="brainH"></h2>
  <p class="pmd" id="brainD"></p>
  <textarea id="brainTx" maxlength="800" spellcheck="false"></textarea>
  <div id="brainEx"></div>
  <div class="pmlabel">ربات این‌طور فهمید</div>
  <div id="brainRes"></div>
 </div></div>
 <div class="pmfoot"><div class="pmfin"><button id="brainTest" class="pmb">▶ بساز و امتحان کن</button></div></div></div>`);
let onClose=null,busy=false,examples=[],draft='';
const ONE={n:'پرامت ربات',d:'ربات چطور حرکت کند و به کدام دشمن شلیک کند؟ همه را در یک متن بنویس.',ph:''};
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const res=(html,bad)=>{$('#brainRes').innerHTML='<div class="pr'+(bad?' bad':'')+'"><div class="prb">'+html+'</div></div>';};
const bad=m=>res('<div class="prm">'+esc(m)+'</div>',true);
function showProg(extra){
 const p=parts.move||parts.shoot;if(!p||!cur){$('#brainRes').innerHTML='<div class="pmempty">هنوز چیزی ننوشته‌ای.</div>';return;}
 res('<div class="prt">«'+esc(p.text)+'»</div>'+esc(B0.describe(cur.prog).join('\n'))+(extra?'<div class="prm">'+esc(extra)+'</div>':''));}
function drawTabs(){
 $('#brainTabs').style.display='none';$('#brainH').textContent=ONE.n;$('#brainD').textContent=ONE.d;$('#brainTx').placeholder=ONE.ph;
 const ex=$('#brainEx');ex.innerHTML='';for(const e of examples){const sp=document.createElement('span');sp.textContent=e;sp.onclick=()=>{$('#brainTx').value=e;};ex.append(sp);}}
async function build(){
 if(busy)return false;const t=$('#brainTx').value.trim();if(!t){bad('اول بنویس ربات چه کار کند.');return false;}
 busy=true;$('#brainTest').disabled=true;$('#brainTest').textContent='در حال ساختن…';
 try{const r=await fetch('/api/program',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({t})});
  if(r.status===503){bad('هوش مصنوعی روی سرور فعال نیست. کلید را با ANTHROPIC_API_KEY بده و سرور را دوباره بالا بیاور.');return false;}
  if(!r.ok){bad(r.status===429?'کمی صبر کن و دوباره امتحان کن.':'ساخته نشد؛ دوباره امتحان کن.');return false;}
  const j=(await r.json()).r;
  if(j.status!=='ok'){bad(j.msg||'نفهمیدم');return false;}
  const c=B0.compile(j.prog);if(!c.prog){bad('برنامه‌ی ساخته‌شده معتبر نبود؛ ساده‌تر بنویس.');return false;}
  parts={move:c.prog.move?{text:t,prog:{move:c.prog.move}}:null,shoot:(c.prog.target||c.prog.fire)?{text:t,prog:{target:c.prog.target,fire:c.prog.fire}}:null};rebuild();save();drawTabs();
  showProg([j.cant?'نشدنی: '+j.cant:'',j.warn||''].filter(Boolean).join('\n'));return true;
 }catch(e){bad('اتصال به سرور برقرار نشد.');return false;}
 finally{busy=false;$('#brainTest').disabled=false;$('#brainTest').textContent='▶ بساز و امتحان کن';}
}
function close(test){$('#brainOv').classList.remove('on');document.body.classList.remove('bpanel');const f=onClose;onClose=null;if(f)f(test);}
/* پنل سمت راست: با کشیدن لبهٔ چپ یا دکمهٔ ⤢ کوچک و بزرگ می‌شود و اندازه یادش می‌ماند */
const BWK='ra_brain_w';let bw=440;try{bw=+localStorage.getItem(BWK)||440;}catch(e){}
const setW=w=>{bw=Math.max(300,Math.min(Math.round(w),Math.round(innerWidth*(innerWidth<700?1:.75))));$('#brainOv').style.setProperty('--bw',bw+'px');document.body.style.setProperty('--bpw',bw+'px');},saveW=()=>{try{localStorage.setItem(BWK,bw);}catch(e){}};
setW(bw);
$('#brainRz').onpointerdown=e=>{e.preventDefault();const el=e.currentTarget;el.setPointerCapture(e.pointerId);
 const mv=ev=>setW(innerWidth-ev.clientX),up=()=>{el.removeEventListener('pointermove',mv);el.removeEventListener('pointerup',up);saveW();};
 el.addEventListener('pointermove',mv);el.addEventListener('pointerup',up);};
$('#brainBig').onclick=()=>{setW(bw>innerWidth*.6?440:innerWidth*.8);saveW();};
$('#brainTest').onclick=async()=>{if(!(await build()))return;/* پنل باز می‌ماند؛ فقط ربات در زمین اجرا می‌شود */if(onClose)onClose(true);};
$('#brainTx').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();if(!e.repeat&&!busy)$('#brainTest').click();}});/* اینتر = بساز و امتحان کن؛ Shift+Enter = خط بعد */
$('#brainClose').onclick=()=>close(false);
function open(cb,ex){onClose=cb||null;examples=Array.isArray(ex)?ex:ex&&typeof ex==='object'?Object.values(ex).flat():[];
 $('#brainOv').classList.add('on');document.body.classList.add('bpanel');drawTabs();$('#brainTx').value=draft||(parts.move||parts.shoot||{text:''}).text;showProg();}
window.Brain={on:true,showPlan:false,open,program:()=>cur?JSON.parse(JSON.stringify(cur.prog)):null,hide(){$('#brainOv').classList.remove('on');document.body.classList.remove('bpanel');onClose=null;},has:()=>!!cur,features:feat,
 reset(){parts={move:null,shoot:null};draft='';cur=null;st={battle:null};save();const tx=$('#brainTx');if(tx){tx.value='';showProg();}},
 set(prog,text){const c=B0.compile(prog);if(!c.prog)return c.errors;const t=String(text||'');
  parts.move=c.prog.move?{text:t,prog:{move:c.prog.move}}:null;parts.shoot=c.prog.target||c.prog.fire?{text:t,prog:{target:c.prog.target,fire:c.prog.fire}}:null;rebuild();save();return [];},
 current:()=>cur};
})();
