'use strict';
/* لابی ساده + آموزش مرحله‌به‌مرحله + کارگاه طراحی.
   همهٔ منطق (موتور، فهم جمله، آنلاین) از کدهای موجود می‌آید؛ اینجا فقط صفحه‌ها و ترتیب آن‌ها است. */
(function(){
const HK='ra_home_v2',PMK='ra_pm_v3';
const H={done:0,tr:0,name:'ربات من',named:0,color:'#22d3ee',av:0,robots:[],sel:0};
try{const j=JSON.parse(localStorage.getItem(HK));if(j&&typeof j==='object'){H.done=Math.max(0,j.done|0);H.tr=Math.max(0,j.tr|0);if(j.named&&typeof j.name==='string'&&j.name.trim()){H.name=j.name.trim().slice(0,16);H.named=1;}if(typeof j.color==='string'&&/^#[0-9a-f]{6}$/i.test(j.color))H.color=j.color;H.av=Math.max(0,j.av|0);if(Array.isArray(j.robots))H.robots=j.robots.filter(r=>r&&typeof r.n==='string'&&/^#[0-9a-f]{6}$/i.test(r.c)).slice(0,8).map(r=>({n:r.n.slice(0,16),c:r.c}));H.sel=Math.max(0,j.sel|0);}}catch(e){}
if(!H.robots.length)H.robots=[{n:'ربات من',c:H.color}];if(H.sel>=H.robots.length)H.sel=0;H.color=H.robots[H.sel].c;
const save=()=>{try{localStorage.setItem(HK,JSON.stringify({done:H.done,tr:H.tr,name:H.name,named:H.named,color:H.color,av:H.av,robots:H.robots,sel:H.sel}));}catch(e){}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const MOVE=['retreat','keep','approach','strafe','center','cover','breakout','hold','move_rel','go_empty_side','go_safest'];
const SHOOT=['t_near','t_weak','t_danger','t_far','t_runner','t_spitter','fire_range','cease_fire','rapid'];
const TARGET=['t_near','t_weak','t_danger','t_far','t_runner','t_spitter'];

/* ---------- آماده‌سازی: همان معماری پرامت موجود، فقط بدون توانایی ---------- */
devU=true;devMode=true;masterMode=false;masterU=false;
if(!Array.isArray(rules)||H.done===0){rules=[];try{localStorage.removeItem(PMK);}catch(e){}saveRobot();if(window.Brain)window.Brain.reset();}
try{applyDev();}catch(e){}
const BF=()=>window.Brain&&window.Brain.features(),hasM=()=>{const f=BF();return !!f&&f.move;},hasS=()=>{const f=BF();return !!f&&(f.fire||f.target);};

/* ---------- مرحله‌ها: اولین ورود: ۲ انرژی، ۳ سه دشمن، ۴ صندوق گنج (از صندوق انرژی بیرون می‌آید). مرحلهٔ ۱ صفحهٔ نام است ---------- */
const MIS=[
 {t:'انرژی',pad:'run',sec:'move',cubes:1,q:'به رباتت بگو *انرژی*‌ها را بگیرد.',ex:['همهٔ انرژی‌ها را بردار','از موانع رد شو و برو بالا','به نزدیک‌ترین انرژی برو'],
  setup(){},ok:r=>hasM()&&r.cubes,good:'ربات همهٔ انرژی‌ها را برداشت!',bad:'ربات همهٔ *انرژی*‌ها را نگرفت. بنویس از موانع رد شود و آن‌ها را بردارد.'},
 {t:'سه دشمن',pad:'shoot',sec:'shoot',q:'سه *دشمن* بالای زمین‌اند. به رباتت بگو *شلیک* کند.',ex:['همیشه، نزدیک‌ترین دشمن را بزن'],lim:1800,
  setup(e,st,pt){pt('walker',ARENA.w/2-200,170);pt('walker',ARENA.w/2,150);pt('walker',ARENA.w/2+200,170);},ok:r=>hasS()&&r.cleared,good:'ربات شلیک کرد و دشمن‌ها را زد.',bad:'ربات هنوز *شلیک* نمی‌کند. بنویس به *دشمن* شلیک کند.'},
 {t:'صندوق گنج',pad:'shoot',sec:'shoot',chest:1,q:'به رباتت بگو به *صندوق گنج* *شلیک* کند تا بشکند و *انرژی* بیرون بیاید.',ex:['همیشه شلیک کن'],lim:1800,
  setup(){},ok:r=>hasS()&&r.gem,good:'صندوق شکست و انرژی بیرون آمد!',bad:'*صندوق گنج* نشکست. بنویس *شلیک* کند.'}
];
/* مرحله‌های قدیمی (حرکت، شلیک، فرار، جان کم، انتخاب هدف، همه با هم) استفاده نمی‌شوند؛ برای بعد نگه داشته شده‌اند */
const MIS_LATER=[
 {t:'حرکت',pad:'run',sec:'move',q:'رباتت پایین زمین است. بهش بگو برود بالا، از موانع رد شود و به دشمن‌ها برسد. دشمن‌ها تکان نمی‌خورند و شلیک نمی‌کنند.',ex:['همیشه، به دشمن نزدیک شو'],lim:4500,goalY:480,
  setup(e,st,pt){pt('walker',ARENA.w/2-170,170);pt('walker',ARENA.w/2+170,170);},ok:r=>hasM()&&r.y<480,good:'ربات از موانع رد شد و به بالا رسید.',bad:'ربات به بالا نرسید. یک جمله برای نزدیک شدن به دشمن بنویس.'},
 {t:'شلیک',pad:'shoot',sec:'shoot',q:'بالا رسیدی. حالا بهش بگو به دشمن‌ها شلیک کند. آن‌ها سر جایشان می‌مانند و شلیک نمی‌کنند.',ex:['همیشه، نزدیک‌ترین دشمن را بزن'],lim:1800,
  setup(e,st,pt){pt('walker',ARENA.w/2-200,170);pt('walker',ARENA.w/2,150);pt('walker',ARENA.w/2+200,170);},ok:r=>hasS()&&r.cleared,good:'ربات شلیک کرد و دشمن‌ها را زد.',bad:'ربات هنوز شلیک نمی‌کند. یک جمله برای شلیک بنویس.'},
 {t:'فرار',sec:'move',q:'دشمن‌ها به‌سمتت می‌آیند و رباتت از جایش تکان نمی‌خورد. بگو وقتی دشمن نزدیک شد چه کار کند.',ex:['وقتی دشمن نزدیک شد، فاصله بگیر'],lim:1500,
  setup(e){e('walker',900,-60);e('walker',1050,70);},ok:r=>hasM()&&r.alive&&r.hp>=.4,good:'ربات فاصله گرفت و زنده ماند.',bad:'ربات هنوز از دشمن دور نمی‌شود یا زیاد آسیب دید. جمله را عوض کن.'},
 {t:'جان کم',sec:'move',q:'رباتت زخمی است و هنوز وسط دشمن‌هاست. بگو وقتی جانش کم شد چه کار کند تا زنده بماند.',ex:['وقتی جانم کم شد، پشت دیوار پناه بگیر','وقتی جانم کم شد، عقب بکش'],lim:1800,
  setup(e){battle.player.hp=30;e('brute',600,-100,false,1.5);e('brute',700,100,false,1.5);e('walker',500,0);e('walker',800,-40);},ok:r=>{const f=BF();return !!f&&f.sensors.has('hp')&&f.move&&r.alive;},good:'ربات به‌موقع عقب کشید و نابود نشد.',bad:'ربات نابود شد یا قانون «جان کم» ندارد. یک جمله با «وقتی جانم کم شد» بنویس.'},
 {t:'انتخاب هدف',sec:'shoot',q:'چند دشمن با هم می‌آیند. بگو اول کدام را بزند.',ex:['همیشه، اول ضعیف‌ترین را بزن','همیشه، اول دونده‌ها را بزن'],lim:1800,
  setup(e){e('walker',800,-120);e('runner',900,0);e('walker',1000,120);},ok:r=>{const f=BF();return !!f&&f.target&&r.alive;},good:'ربات هدفش را درست انتخاب کرد.',bad:'ربات نابود شد یا انتخاب هدف ندارد. بگو اول کدام را بزند.'},
 {t:'همه با هم',sec:'both',q:'حالا همه را با هم بنویس: حرکت و شلیک. بعد امتحان کن.',ex:[],lim:2100,
  setup(e){e('walker',800,-100);e('runner',900,0);e('walker',1000,100);e('brute',1150,0);},ok:r=>hasM()&&hasS()&&r.alive,good:'رباتت آماده است!',bad:'ربات نابود شد. حرکت و شلیک را بهتر بنویس و دوباره امتحان کن.'}
];

/* ---------- صفحه‌ها (HTML و CSS) ---------- */
const css=document.createElement('style');css.textContent=`
#nHome,#nTop,#nBar,#nCard{font-family:Vazirmatn,Tahoma,sans-serif}
#nHome{position:absolute;inset:0;z-index:7;display:none;direction:ltr;pointer-events:none}#nHome.on{display:block}#nHome>*{pointer-events:auto}
.nb{border:1px solid var(--line);border-radius:12px;font-family:inherit;font-weight:700;cursor:pointer;color:var(--txt);background:var(--panel)}.nb:hover{border-color:var(--cy)}
.nb.g,.nb.y{background:var(--am);color:#2a1c00;border-color:var(--am);font-weight:800}.nb.b{background:var(--panel)}
#nTr{position:absolute;left:14px;top:14px;display:flex;gap:10px;align-items:stretch;direction:ltr}
.pnl{background:linear-gradient(#3d4868,#262f49);border:3px solid #0a1230;border-radius:10px;box-shadow:0 4px 0 rgba(0,0,0,.4)}
#nProf{width:104px;padding:6px 6px 5px;display:flex;flex-direction:column;align-items:center;gap:3px}
#nPAv{width:78px;height:78px;border-radius:6px;border:2px solid #0a1230;display:flex;align-items:center;justify-content:center;font-size:48px;line-height:1;cursor:pointer}
#nName{font-size:15px;font-weight:900;color:#fff;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-shadow:0 2px 0 #0a1230,1px 1px 0 #0a1230,-1px 1px 0 #0a1230}
#nTrP{display:flex;align-items:center;gap:12px;padding:8px 16px 8px 10px;min-width:250px;cursor:pointer;transition:filter .15s}#nTrP:hover{filter:brightness(1.12)}
#nBadge{flex:none;width:62px;height:62px;border-radius:50%;background:radial-gradient(circle at 50% 35%,#c084fc,#6d28d9);border:4px solid #e9d5ff;box-shadow:0 0 0 3px #0a1230,0 0 16px rgba(168,85,247,.6);display:flex;align-items:center;justify-content:center}
#nLvN{font-size:26px;font-weight:900;color:#fff;text-shadow:0 2px 0 #3b0764}
#nTrR{flex:1;display:flex;flex-direction:column;gap:7px;direction:ltr}
#nTrTop{display:flex;align-items:center;gap:8px}#nTrTop .ic{font-size:30px;line-height:1;filter:drop-shadow(0 2px 0 #0a1230)}
#nTrN{font-size:30px;font-weight:900;color:#ffd23f;text-shadow:0 3px 0 #0a1230,2px 2px 0 #0a1230,-2px 2px 0 #0a1230;letter-spacing:.5px}
#nTrBar{height:18px;border-radius:5px;background:#0b1424;border:2px solid #0a1230;overflow:hidden}#nTrBar i{display:block;height:100%;width:0;background:linear-gradient(#ffb340,#ff7a00);transition:width .25s}
#nLeague{position:absolute;right:14px;top:14px;width:min(300px,30vw);padding:10px 12px;direction:rtl;background:linear-gradient(#3d4868,#262f49);border:3px solid #0a1230;border-radius:10px;box-shadow:0 4px 0 rgba(0,0,0,.4);color:#fff}
#nLeague .leagueHead{display:flex;align-items:center;justify-content:space-between;font-size:17px;font-weight:900;text-shadow:0 2px 0 #0a1230;padding-bottom:6px;border-bottom:1px solid rgba(255,255,255,.14)}
#nLeagueRefresh{width:28px;height:28px;border-radius:7px;background:#17243d;border:1px solid #607193;font-size:18px;line-height:1}
#nLeagueMeta{font-size:11px;color:#c8d5ee;margin:4px 0 7px}
#nLeagueRows{display:grid;gap:4px}
#nLeagueRows .lr{display:grid;grid-template-columns:27px minmax(0,1fr) auto;align-items:center;gap:7px;min-height:27px;padding:2px 6px;background:rgba(7,14,27,.55);border-radius:6px;font-size:12px;font-weight:800}
#nLeagueRows .lr.me{background:rgba(34,211,238,.16);outline:1px solid rgba(34,211,238,.55)}
#nLeagueRows .lr .rr{color:#ffd23f;text-align:center}.lr .ln{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.lr .lt{color:#ffd23f;white-space:nowrap}
#nLeagueMe{margin-top:7px;padding-top:6px;border-top:1px solid rgba(255,255,255,.14);font-size:12px;font-weight:900;display:flex;justify-content:space-between;color:#dbeafe}
#nQueueInfo{position:absolute;right:28px;bottom:calc(120px + env(safe-area-inset-bottom,0px));width:min(360px,calc(100% - 32px));padding:9px 12px;display:none;align-items:center;gap:8px;direction:rtl;background:linear-gradient(#3d4868,#262f49);border:3px solid #0a1230;border-radius:9px;box-shadow:0 4px 0 rgba(0,0,0,.4);font-size:12px;font-weight:800;color:#fff}
#nQueueInfo.on{display:flex}#nQueueText{flex:1;line-height:1.6}#nQueueInfo .qdot{width:9px;height:9px;border-radius:50%;background:#4ade80;box-shadow:0 0 0 3px rgba(74,222,128,.15);flex:none}
@media(max-width:760px){#nLeague{top:110px;right:10px;width:min(205px,48vw);padding:7px 8px}#nLeague .leagueHead{font-size:14px}#nLeagueRows .lr:nth-child(n+4){display:none}#nQueueInfo{right:12px;bottom:calc(92px + env(safe-area-inset-bottom,0px));width:min(300px,calc(100% - 24px));font-size:11px}}
#nRobBtn{position:absolute;left:14px;top:44%;display:flex;align-items:center;gap:14px;padding:16px 28px 16px 18px;direction:rtl;cursor:pointer;color:#fff;font-family:inherit;font-weight:900;font-size:26px;transform:skewX(-6deg);border-width:4px}
#nRobBtn>*{transform:skewX(6deg)}#nRobBtn:hover{border-color:var(--cy);filter:brightness(1.12)}
#nRobBtn .ri{font-size:52px;line-height:1;filter:drop-shadow(0 2px 0 #0a1230)}
#nRobBtn .rn{position:absolute;top:-14px;right:-14px;min-width:34px;height:34px;border-radius:50%;background:#e11d48;border:3px solid #fff;font-size:18px;line-height:28px;text-align:center;transform:skewX(6deg)}
.nScr{position:fixed;inset:0;z-index:9;display:none;overflow:auto;font-family:Vazirmatn,Tahoma,sans-serif;color:#fff;background:radial-gradient(circle at 25% 10%,#1e4fb8,#0f2a6b 55%,#081a47)}.nScr.on{display:block;animation:nArIn .3s ease-out}
.nScr h1{font-size:30px;font-weight:900;text-align:center;letter-spacing:.5px;text-shadow:0 3px 0 #0a1230;padding-top:16px}.nScr .sub{text-align:center;font-size:15px;color:#cfe0ff;margin-top:2px}
.nX{position:absolute;top:14px;right:16px;width:46px;height:46px;border-radius:8px;border:3px solid #fff;background:#e11d48;color:#fff;font-size:26px;font-weight:900;cursor:pointer;line-height:1;box-shadow:0 4px 0 rgba(0,0,0,.4)}.nX:hover{filter:brightness(1.15)}
#nRoadW{overflow-x:auto;overflow-y:hidden;padding:0 0 90px;direction:ltr;position:absolute;left:0;right:0;top:50%;transform:translateY(-50%)}
#nRoadRow{display:flex;position:relative;width:max-content;padding:70px 0 0 100px}
#nRoadRow::after{content:'';width:100px;flex:none}
.rdI{position:relative;width:190px;flex:none}
.rdC{margin:0 auto;width:150px;height:118px;border-radius:8px;border:3px solid #0a1230;background:linear-gradient(#3b86ff,#1f55d4);box-shadow:0 5px 0 rgba(0,0,0,.35);text-align:center;padding-top:10px;position:relative;direction:rtl}
.rdC .ci{font-size:42px;line-height:1.1;filter:drop-shadow(0 2px 0 rgba(0,0,0,.4))}.rdC b{display:block;font-size:17px;font-weight:900;margin-top:4px;text-shadow:0 2px 0 #0a1230}.rdC i{display:block;font-style:normal;font-size:13px;color:#d3e3ff;margin-top:1px}
.rdC.lock{background:linear-gradient(#34508c,#223765)}.rdC.lock .ci{opacity:.55;filter:grayscale(.6)}
.rdC.done::after{content:'✓';position:absolute;top:-13px;right:-11px;width:30px;height:30px;border-radius:50%;background:#22c55e;border:3px solid #0a1230;font-size:18px;line-height:24px;font-weight:900}
.rdC.next{box-shadow:0 0 0 4px #ffd23f,0 5px 0 rgba(0,0,0,.35)}
.rdNext{position:absolute;top:-30px;left:0;right:0;text-align:center;font-weight:900;font-size:17px;color:#fff3b0;text-shadow:0 2px 0 #0a1230}
.rdTrack{position:relative;height:24px;margin-top:30px;background:#4a0e2c;border-top:3px solid #0a1230;border-bottom:3px solid #0a1230}.rdTrack i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(#ffb340,#ff7a00)}
.rdHex{position:absolute;left:-23px;top:-15px;width:46px;height:52px;background:#f59e0b;clip-path:polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%);display:flex;align-items:center;justify-content:center;font-size:19px;font-weight:900;color:#3b1d00;z-index:2}
.rdHex.lock{background:#475569;color:#cbd5e1}
.rdT{position:absolute;left:-30px;top:44px;width:60px;text-align:center;font-size:15px;font-weight:900;color:#9ec1ff}
.rdMe{position:absolute;top:70px;transform:translateX(-50%);background:linear-gradient(#ffb340,#f59e0b);border:3px solid #0a1230;border-radius:8px;padding:3px 12px;font-weight:900;font-size:18px;color:#fff;text-shadow:0 2px 0 #7a3d00;white-space:nowrap;z-index:3}
#nRobGrid{display:flex;flex-wrap:wrap;gap:22px;justify-content:center;padding:36px 28px 40px;max-width:900px;margin:0 auto;direction:rtl}
.rbC{position:relative;width:210px;height:250px;border:3px solid #0a1230;border-radius:10px;background:linear-gradient(#3b86ff,#1f55d4);box-shadow:0 5px 0 rgba(0,0,0,.35);padding:12px 8px 8px;text-align:center;cursor:pointer;transition:transform .15s;display:flex;flex-direction:column;align-items:center;justify-content:center}.rbC:hover{transform:translateY(-4px)}
.rbC canvas{width:150px;height:150px}.rbC .rn{font-size:20px;font-weight:900;text-shadow:0 2px 0 #0a1230;margin-top:4px}
.rbC.add{background:rgba(255,255,255,.06);border:3px dashed rgba(190,215,255,.45);box-shadow:none;color:rgba(200,222,255,.6);font-size:82px;font-weight:300;line-height:1}.rbC.add:hover{background:rgba(255,255,255,.12)}
.rbC .cur{position:absolute;top:8px;right:10px;background:#22c55e;border:2px solid #0a1230;border-radius:6px;padding:0 8px;font-size:12px;font-weight:900}
#nRobScr.det{background:radial-gradient(circle at 50% 45%,#3c8cff,#1b55d8 55%,#1237a0)}#nRobScr.det>h1,#nRobScr.det>.sub,#nRobScr.det>.nX{display:none}
#nRobDet{position:absolute;inset:0;direction:ltr;overflow:hidden}
#nRobDet .bk{position:absolute;left:0;top:0;width:78px;height:54px;background:#0f2a6b;border:3px solid #0a1230;border-left:0;border-top:0;border-radius:0 0 14px 0;color:#fff;font-size:34px;font-weight:900;cursor:pointer;line-height:1}
#nRobDet .ban{position:absolute;left:4%;top:78px;width:min(310px,40%);padding:10px 22px;background:linear-gradient(#9fe3ff,#4fb3ee);border:3px solid #0a1230;transform:skewX(-8deg);box-shadow:0 5px 0 rgba(0,0,0,.3);direction:rtl;text-align:center}
#nRobDet .ban b{display:block;transform:skewX(8deg);font-size:28px;font-weight:900;color:#fff;text-shadow:0 3px 0 #0a1230,2px 2px 0 #0a1230,-2px 2px 0 #0a1230;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#nRobDet .ban i{display:block;transform:skewX(8deg);font-style:normal;font-size:13px;font-weight:900;color:#0a1230}
#nRobDet .inf{position:absolute;left:4%;top:178px;width:min(300px,40%);direction:rtl}
#nRobDet .trb{display:flex;align-items:center;gap:10px;background:#0f2a6b;border:3px solid #0a1230;border-radius:10px;padding:8px 14px;font-size:24px;font-weight:900;color:#ffd23f}
#nRobDet .inf p{margin-top:14px;font-size:15px;line-height:1.9;font-weight:800;color:#fff;text-shadow:0 2px 0 #0a1230}
#nRobDet .stg{position:absolute;left:50%;top:48%;transform:translate(-50%,-50%);width:min(380px,36vw);aspect-ratio:1}
#nRobDet .stg::before{content:'';position:absolute;inset:8%;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.35),transparent 68%)}
#nRobDet .stg canvas{position:relative;width:100%;height:100%}
#nRobDet .btm{position:absolute;left:4%;bottom:6%;display:flex;flex-direction:column;gap:12px;direction:ltr}
#nRobDet .ib{display:flex;gap:10px}
#nRobDet .ib button{width:60px;height:56px;border-radius:8px;background:#0f2a6b;border:3px solid #0a1230;font-size:26px;cursor:pointer;box-shadow:0 4px 0 rgba(0,0,0,.35);color:#fff}#nRobDet .ib button.on,#nRobDet .ib button:hover{border-color:#ffd23f}
#nRobDet .sel{padding:14px 0;width:min(300px,100%);font-size:28px;font-weight:900;font-family:inherit;color:#fff;background:linear-gradient(#ffd23f,#f0a800);border:3px solid #0a1230;border-radius:8px;box-shadow:0 5px 0 rgba(0,0,0,.4);text-shadow:0 3px 0 #8a5a00,2px 2px 0 #8a5a00,-2px 2px 0 #8a5a00;cursor:pointer}.sel:disabled{filter:grayscale(.55) brightness(.9);cursor:default}
#nRobDet .pop{position:absolute;left:4%;bottom:calc(6% + 150px);width:min(300px,60vw);background:#0f2a6b;border:3px solid #0a1230;border-radius:10px;padding:12px;direction:rtl;display:none}#nRobDet .pop.on{display:block}
#nRobDet .pop input{width:100%;padding:9px;font-size:19px;font-weight:800;text-align:center;font-family:inherit;color:#fff;background:#0b1530;border:2px solid #0a1230;border-radius:8px;outline:none}#nRobDet .pop input:focus{border-color:#ffd23f}
#nRobDet .rp{position:absolute;right:4%;top:90px;width:min(330px,40%);background:linear-gradient(#17358a,#0f2a6b);border:3px solid #0a1230;border-radius:12px;padding:14px;direction:rtl;box-shadow:0 5px 0 rgba(0,0,0,.3)}
#nRobDet .rp h3{display:flex;align-items:center;gap:10px;font-size:26px;font-weight:900;text-shadow:0 3px 0 #0a1230;margin-bottom:12px}
#nRobDet .lvb{width:46px;height:46px;border-radius:50%;background:radial-gradient(circle at 50% 35%,#c084fc,#6d28d9);border:3px solid #e9d5ff;display:flex;align-items:center;justify-content:center;font-size:22px}
#nRobDet .bar{direction:ltr;height:14px;flex:1;background:#0b1424;border:2px solid #0a1230;border-radius:4px;overflow:hidden}#nRobDet .bar i{display:block;height:100%;background:linear-gradient(#ffb340,#ff7a00)}
#nRobDet .row{display:flex;align-items:center;gap:12px;background:#0b1a4a;border:2px solid #0a1230;border-radius:8px;padding:10px 12px;margin-top:8px;font-size:19px;font-weight:900}.row .ri{width:34px;height:34px;border-radius:6px;background:#1f55d4;display:flex;align-items:center;justify-content:center;font-size:20px}.row em{margin-right:auto;font-style:normal;color:#ffd23f;font-size:22px}
@media(max-width:760px){#nRobDet .rp{top:auto;bottom:6%;right:3%;width:44%}#nRobDet .stg{width:46vw;top:38%}#nRobDet .inf p{display:none}#nRobDet .ban{width:46%}}
.stats{display:flex;gap:10px}.stats div{flex:1;background:#0b1530;border-radius:10px;padding:8px;text-align:center;font-size:13px;color:#cfe0ff}.stats b{display:block;font-size:22px;color:#ffd23f;font-weight:900}
.sw{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}.sw i{width:38px;height:38px;border-radius:50%;border:3px solid #0a1230;cursor:pointer}.sw i.on{box-shadow:0 0 0 3px #fff}
.rdBtns{display:flex;gap:10px;width:100%}.rdBtns .nb{flex:1;padding:14px;font-size:19px}.nb.r{background:#e11d48;border-color:#0a1230;color:#fff}.rdBtns .nb:disabled{opacity:.6;cursor:default}
.avG{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}.avG i{font-style:normal;height:70px;border-radius:12px;border:3px solid #0a1230;display:flex;align-items:center;justify-content:center;font-size:42px;cursor:pointer;transition:transform .12s}.avG i:hover{transform:scale(1.07)}.avG i.on{box-shadow:0 0 0 4px #ffd23f}
#nSide{position:absolute;left:33%;top:22%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:12px}
#nDesign{padding:14px 44px;font-size:20px;border-radius:16px}
#nArenaBtn{position:absolute;right:calc(28px + 232px + 12px);bottom:calc(28px + env(safe-area-inset-bottom,0px));display:flex;align-items:center;gap:14px;min-width:290px;height:78px;padding:0 20px 0 14px;direction:rtl;text-align:right;border:3px solid #0a1230;border-radius:6px;background:linear-gradient(#3d4a6e,#283352);box-shadow:0 6px 0 #0a1230,inset 0 2px 0 rgba(255,255,255,.18);transform:skewX(-8deg)}
#nArenaBtn>*{transform:skewX(8deg)}#nArenaBtn:hover{border-color:var(--cy);filter:brightness(1.1)}
#nArenaBtn .ai{flex:none;width:48px;height:48px;border-radius:50%;background:#0b1226;display:flex;align-items:center;justify-content:center;font-size:26px}
#nArenaBtn .at{display:flex;flex-direction:column;line-height:1.5}#nArenaBtn b{font-size:19px;font-weight:900;color:#fff}#nArenaBtn i{font-style:normal;font-size:14px;font-weight:800;color:#7be04a}
@media(max-width:700px){#nArenaBtn{right:auto;left:12px;min-width:0}}
#nPlay{position:absolute;right:28px;bottom:calc(28px + env(safe-area-inset-bottom,0px));width:232px;height:78px;padding:0;font-size:40px;font-weight:900;letter-spacing:1px;line-height:1;color:#fff;border:3px solid #0a1230;border-radius:6px;background:linear-gradient(#ffd84a,#ffc400 55%,#f5a800);transform:skewX(-8deg);
 text-shadow:0 3px 0 #5a3a00,2px 2px 0 #5a3a00,-2px 2px 0 #5a3a00,2px -1px 0 #5a3a00,-2px -1px 0 #5a3a00;box-shadow:0 6px 0 #0a1230,inset 0 3px 0 rgba(255,255,255,.5);transition:transform .08s,filter .12s}
#nPlay:hover{border-color:#0a1230;filter:brightness(1.08)}#nPlay:active{transform:skewX(-8deg) translateY(5px);box-shadow:0 1px 0 #0a1230,inset 0 3px 0 rgba(255,255,255,.5)}
@media(max-width:560px){#nPlay{width:170px;height:64px;font-size:30px}#nArenaBtn{height:64px}}
#arena.nm .hud,#arena.nm #coach,#arena.nm #dim{display:none!important}
#archFab,#archPanel{display:none!important}
body.nmode #ruleNow{bottom:auto;top:64px}
#nTop{position:absolute;z-index:6;top:calc(10px + env(safe-area-inset-top,0px));left:0;right:0;display:none;justify-content:space-between;align-items:center;padding:0 12px;pointer-events:none}
#nTop>*{pointer-events:auto}#nTitle{background:rgba(14,24,43,.85);border:1px solid var(--line);color:var(--txt);border-radius:12px;padding:8px 16px;font-weight:700;font-size:15px}
#nDps{background:var(--panel);border:1px solid var(--line);color:var(--cy);border-radius:10px;padding:6px 12px;font-size:13px;font-weight:700;margin-inline-start:8px}#nDps:empty{display:none}
#nExit{padding:8px 18px;font-size:15px}
#nBar{position:absolute;z-index:6;left:50%;transform:translateX(-50%);bottom:calc(8px + env(safe-area-inset-bottom,0px));width:min(760px,calc(100% - 16px));background:rgba(14,24,43,.94);border:1px solid var(--line);border-radius:16px;padding:12px 14px;display:none;direction:rtl;color:var(--txt);box-shadow:0 8px 30px rgba(0,0,0,.4)}
#nTitle,#nExit{display:none!important}#nTop{justify-content:flex-end}#nTop>span:first-child{margin-inline-start:auto}
#nBar{background:none!important;border:none!important;box-shadow:none!important;padding:0!important;display:none;align-items:flex-end;gap:14px;pointer-events:none}
#nBar[style*="block"]{display:flex!important}
#nBar{top:calc(10px + env(safe-area-inset-top,0px))!important;bottom:auto!important;left:10px!important;transform:none!important;width:min(480px,calc(100% - 200px))!important;align-items:flex-start;flex-direction:row-reverse}
#nAv{pointer-events:auto;flex:none;width:76px;height:76px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#c084fc,#7c3aed);border:4px solid #fff;box-shadow:0 4px 14px rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;font-size:42px;animation:nAvB 2s ease-in-out infinite}
@keyframes nAvB{50%{transform:translateY(-4px)}}
#nBub{position:relative;flex:0 1 auto;width:fit-content;max-width:100%;background:#fff;color:#1a1a2e;border:3px solid #1a1a2e;border-radius:18px;padding:12px 16px;box-shadow:0 5px 0 rgba(0,0,0,.35);pointer-events:auto;align-self:center}
#nBub::after{content:'';position:absolute;left:-13px;top:50%;margin-top:-10px;border:10px solid transparent;border-right:13px solid #1a1a2e;border-left:0}
#nBub::before{content:'';position:absolute;left:-8px;top:50%;margin-top:-8px;border:8px solid transparent;border-right:10px solid #fff;border-left:0;z-index:1}
#nBub .nb{pointer-events:auto}
#nQ{font-size:24px;font-weight:800;line-height:1.5;cursor:pointer}
.tk{font-weight:900}.tk-e{color:#15a34a}.tk-g{color:#c2780a}.tk-d{color:#dc2626}.tk-s{color:#ea580c}.tk-p{color:#7c3aed}.tk-y{color:#2563eb}
#nCard .tk-e{color:#4ade80}#nCard .tk-g{color:#fbbf24}#nCard .tk-d{color:#f87171}#nCard .tk-s{color:#fb923c}#nCard .tk-p{color:#c4b5fd}#nCard .tk-y{color:#67e8f9}
#nBub.pop{animation:nBubIn .4s cubic-bezier(.2,.9,.3,1.3)}
#nBub{transition:opacity 1.6s ease}#nBub.hide{opacity:0}
@keyframes nBubIn{0%{transform:scale(.85);opacity:0}100%{transform:scale(1);opacity:1}}
#nQ.typing::after{content:'';display:inline-block;width:2px;height:1.05em;background:#1a1a2e;margin-inline-start:3px;vertical-align:-3px;animation:nBlink .7s steps(1) infinite}
@keyframes nBlink{50%{opacity:0}}
.nrow{display:flex;gap:8px;margin-top:6px}.nrow:has(#nOpp[style*=none]){display:none}.nrow .nb{padding:11px 22px;font-size:16px}
#nCard{position:absolute;z-index:8;left:50%;top:42%;transform:translate(-50%,-50%);width:min(440px,calc(100% - 24px));background:rgba(10,18,34,.97);border:1px solid var(--line);color:var(--txt);border-radius:22px;padding:22px;text-align:center;display:none;direction:rtl;box-shadow:0 14px 50px rgba(0,0,0,.5)}
#nNameScr{position:fixed;inset:0;z-index:9;display:none;align-items:center;justify-content:center;background:rgba(4,6,13,.9);font-family:Vazirmatn,Tahoma,sans-serif;direction:rtl}
#nNameScr .box{width:min(420px,calc(100% - 32px));background:rgba(10,18,34,.97);border:1px solid var(--line);border-radius:22px;padding:26px;text-align:center;color:var(--txt)}
#nNameScr h2{font-size:24px;margin-bottom:16px}
#nNameScr input{width:100%;padding:14px;font-size:20px;text-align:center;font-family:inherit;color:var(--txt);background:var(--panel);border:1px solid var(--line);border-radius:12px;outline:none;margin-bottom:14px}
#nNameScr input:focus{border-color:var(--cy)}
#nNameScr .nb{width:100%;padding:13px;font-size:18px}
#nCard h2{font-size:22px;margin-bottom:8px}#nCard p{font-size:16px;line-height:1.9;margin-bottom:14px}#nCard .nb{width:100%;padding:13px;font-size:18px;margin-top:6px}
#nArenaScr{position:fixed;inset:0;z-index:9;display:none;overflow:auto;background:radial-gradient(circle at 20% 10%,#12307a,#091a44 60%,#060f2a);font-family:Vazirmatn,Tahoma,sans-serif;direction:rtl;color:#fff}
#nArenaScr.on{display:block;animation:nArIn .3s ease-out}@keyframes nArIn{from{opacity:0}to{opacity:1}}
#nArHead{display:flex;align-items:center;justify-content:space-between;padding:14px 18px}
#nArBack{padding:10px 22px;font-size:24px;line-height:1;border-radius:12px;transform:skewX(-8deg)}
#nArTitle{font-size:24px;font-weight:900;letter-spacing:.5px}
#nArGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;padding:8px 28px 32px;max-width:1100px;margin:0 auto}
.arC{position:relative;transform:skewX(-6deg);border-radius:10px;border:3px solid #0a1230;background:#524e7a;min-height:150px;overflow:hidden;cursor:default;box-shadow:0 6px 0 rgba(0,0,0,.35)}
.arC::before{content:'';display:block;height:26px;background:#05060f}
.arC>div{transform:skewX(6deg);padding:12px 16px 16px;display:flex;gap:12px;align-items:flex-start}
.arC .ic{font-size:34px;flex:none}.arC h3{font-size:19px;font-weight:900;margin-bottom:4px}.arC p{font-size:14px;line-height:1.7;color:#d7dcf5}
.arC.ok{background:linear-gradient(135deg,#2b6cff,#1b3fa8);cursor:pointer;transition:transform .15s}.arC.ok:hover{transform:skewX(-6deg) translateY(-4px)}
.arC.lock{filter:saturate(.7)}
#nArGrid .arC{height:200px;display:flex;flex-direction:column}#nArGrid .arC::before{flex:none}.arCell.open .arC p{display:none}.arCell.open .arC>div{flex:none}.arSel{flex:1;min-height:0}#nArGrid{align-items:start;position:relative!important;height:auto!important;direction:rtl}.arCell{position:relative;transition:opacity .2s,filter .2s}.arSel{display:none;width:calc(100% - 16px);margin:0 8px 8px;padding:0;font-size:26px;font-weight:900;font-family:inherit;color:#fff;background:linear-gradient(#ffd23f,#f0a800);border:3px solid #0a1230;border-radius:8px;box-shadow:0 5px 0 rgba(0,0,0,.4);text-shadow:0 3px 0 #8a5a00,2px 2px 0 #8a5a00,-2px 2px 0 #8a5a00;cursor:pointer}.arCell.open .arSel{display:block;animation:nArIn .2s ease-out}#nArenaScr.arDim::before{content:'';position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:1}.arCell.open{z-index:2}#nArHead{position:relative}
@media(max-width:760px){#nArGrid{grid-template-columns:repeat(2,minmax(0,1fr));padding:8px 14px 24px}}
`;document.head.append(css);
document.body.insertAdjacentHTML('beforeend',`<div id="nHome">
<div id="nTr"><div id="nProf" class="pnl"><div id="nPAv" role="button" aria-label="تغییر تصویر"></div><span id="nName"></span></div><div id="nTrP" class="pnl" role="button" aria-label="جادهٔ جام"><div id="nBadge"><b id="nLvN">1</b></div><div id="nTrR"><div id="nTrTop"><span class="ic">🏆</span><b id="nTrN"></b></div><div id="nTrBar"><i id="nTrBarI"></i></div></div></div></div><button class="pnl" id="nRobBtn" aria-label="انتخاب ربات"><span class="ri">🤖</span><span>ربات‌ها</span><span class="rn" id="nRobN"></span></button>
<div id="nSide"><button class="nb y" id="nDesign" style="display:none">طراحی</button></div><section id="nLeague" class="pnl" aria-label="جدول لیگ"><div class="leagueHead"><span>🏆 جدول لیگ</span><button id="nLeagueRefresh" aria-label="به‌روزرسانی">↻</button></div><div id="nLeagueMeta">در حال دریافت رتبه‌ها…</div><div id="nLeagueRows"></div><div id="nLeagueMe"></div></section><div id="nQueueInfo" class="pnl"><i class="qdot"></i><span id="nQueueText"></span></div><button class="nb" id="nArenaBtn" aria-label="انتخاب زمین"><span class="ai" id="nArIc"></span><span class="at"><b id="nArName"></b><i id="nArSub"></i></span></button><button class="nb g" id="nPlay">بازی</button></div>`);
$('#stageWrap').insertAdjacentHTML('beforeend',`<div id="nTop"><span style="display:flex;gap:8px;align-items:center;direction:ltr"><button class="nb" id="nExit">خروج</button><button class="nb g" id="nPrompt">پرامت</button></span><span style="display:flex;align-items:center"><span id="nTitle"></span><span id="nDps"></span></span></div>
<div id="nBar"><div id="nAv">🤖</div><div id="nBub"><div id="nQ"></div><div class="nrow"><button class="nb" id="nOpp">حریف: ثابت</button></div></div></div>`);
document.body.insertAdjacentHTML('beforeend',`<div id="nNameScr"><div class="box"><h2>نام خود را وارد کنید</h2><input id="nNameIn" maxlength="16" autocomplete="off" placeholder="نام"><button class="nb g" id="nNameGo">ورود</button></div></div>`);
document.body.insertAdjacentHTML('beforeend',`<div id="nCard"><h2 id="nCh"></h2><p id="nCp"></p><button class="nb g" id="nC1"></button><button class="nb b" id="nC2" style="display:none"></button></div>`);
document.body.insertAdjacentHTML('beforeend',`<div id="nArenaScr"><div id="nArHead"><div id="nArTitle">انتخاب زمین</div><button class="nb" id="nArBack" aria-label="بازگشت">←</button></div><div id="nArGrid"></div></div>`);

/* ---------- لابی ---------- */
/* پس‌زمینه و ربات وسط همان لابی قدیمی (drawLobby) است؛ فقط دکمه‌های قدیمی پنهان شده‌اند */
const _ad=window.applyDev;window.applyDev=function(){_ad.apply(this,arguments);document.body.classList.remove('dev','master');};
document.body.classList.remove('dev','master');
/* جام و سطح: هر ۵۰ جام یک سطح. نوار بالای لابی پیشرفت سطح را نشان می‌دهد */
const lvlOf=t=>Math.floor(Math.max(0,t)/50)+1;
function setTr(v){v=Math.max(0,Math.round(v));$('#nTrN').textContent=faNum(v);$('#nLvN').textContent=faNum(lvlOf(v));$('#nTrBarI').style.width=(v%50)/50*100+'%';}
/* ربات خودمان (همان نقاشی داخل بازی) با رنگ دلخواه روی یک بوم */
function drawBot(cv,color,k){const c=cv.getContext('2d');c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,cv.width,cv.height);c.setTransform(k,0,0,k,cv.width/2,cv.height/2);
 drawRobot(c,{x:0,y:0,r:17,color,angle:-.5,bodyAng:-.6,spd:0,tread:0,recoil:0,flash:0,alive:true,nobar:true,hp:1,maxHp:1,name:''},false,0);}
const SKINS=[['#22d3ee','ربات یخی'],['#f43f5e','ربات سرخ'],['#f59e0b','ربات کهربایی'],['#34d399','ربات زمردی'],['#a78bfa','ربات بنفش'],['#f472b6','ربات صورتی'],['#60a5fa','ربات لاجوردی'],['#facc15','ربات طلایی']];
const AVS=[['🦊','#f59e0b'],['🐱','#a78bfa'],['🐼','#64748b'],['🦁','#d97706'],['🐯','#ea580c'],['🐸','#16a34a'],['🐵','#92400e'],['🦄','#ec4899'],['🐲','#059669'],['🦉','#7c3aed'],['🐧','#0ea5e9'],['🐻','#b45309']];
function paintAv(el,i){const a=AVS[i%AVS.length];el.textContent=a[0];el.style.background='radial-gradient(circle at 40% 30%,'+a[1]+'dd,'+a[1]+'66),#14213d';}
function refreshHome(){setTr(H.tr-(H.pend||0));$('#nName').textContent=H.name;paintAv($('#nPAv'),H.av);$('#nRobN').textContent=faNum(H.robots.length);try{demoBot.color=H.color;}catch(e){}
 const A=ARENAS[selA];$('#nArIc').textContent=A.i;$('#nArName').textContent=A.t;$('#nArSub').textContent=A.s;
 const ab=$('#nArenaBtn');let nb=ab.querySelector('.newB');if(A.isNew&&isNewPrac()){if(!nb){nb=document.createElement('span');nb.className='newB';nb.textContent='NEW';ab.append(nb);}}else if(nb)nb.remove();}
async function refreshLeaderboard(){
 const meta=$('#nLeagueMeta'),rows=$('#nLeagueRows'),mine=$('#nLeagueMe');if(!meta||!rows||!mine)return;
 try{
  const res=await fetch('api/leaderboard',{cache:'no-store'});if(!res.ok)throw new Error('leaderboard unavailable');const data=await res.json();
  meta.textContent=faNum(data.total||0)+' بازیکن ثبت‌شده · بر اساس جام فعلی';rows.innerHTML='';
  (data.entries||[]).slice(0,8).forEach(p=>{const row=document.createElement('div');row.className='lr'+(data.me&&data.me.rank===p.rank?' me':'');const r=document.createElement('span');r.className='rr';r.textContent=faNum(p.rank);const n=document.createElement('span');n.className='ln';n.textContent=p.name;const t=document.createElement('span');t.className='lt';t.textContent='🏆 '+faNum(p.tr);row.append(r,n,t);rows.append(row);});
  if(data.me){mine.textContent='رتبهٔ شما: '+faNum(data.me.rank)+'  ·  '+faNum(data.me.tr)+' جام';}
  else mine.textContent=H.named?'رتبهٔ شما: هنوز ثبت نشده':'برای ثبت رتبه، نامت را وارد کن';
 }catch(e){meta.textContent='اتصال به جدول لیگ برقرار نشد';rows.innerHTML='';mine.textContent='';}
}
async function syncServerProfile(){
 try{
  const response=await fetch('api/me',{cache:'no-store'}),me=await response.json();
  if(Number.isFinite(me.tr)&&me.tr>=0){H.tr=Math.round(me.tr);H.pend=0;save();refreshHome();}
  if(H.named)await fetch('api/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:H.name,color:H.color})});
  await refreshLeaderboard();
 }catch(e){refreshLeaderboard();}
}
function setQueueUi(active,message){
 const box=$('#nQueueInfo'),text=$('#nQueueText'),btn=$('#nPlay');
 if(active){box.classList.add('on');text.textContent=message||'در حال جست‌وجوی زمین مناسب…';btn.textContent='لغو صف';btn.disabled=false;}
 else{box.classList.remove('on');text.textContent='';btn.textContent='بازی';btn.disabled=false;}
}
$('#nLeagueRefresh').onclick=refreshLeaderboard;

/* ---------- ورود و خروج از صفحه‌ها ---------- */
/* زمین‌های قابل انتخاب: آنلاین و بتل رویال */
const ARENA_ARMAN={i:'🌐',t:'لیگ آنلاین',s:'۷ تا ۱۰ بازیکن · حداکثر ۳ ربات',d:'مسابقهٔ رتبه‌ای با بازیکنان واقعی؛ جای خالی با ربات‌های هم‌قدرت پر می‌شود.',locked:false};
const ARENA_BR={i:'⚔️',t:'زمین تمرینی',s:'بتل رویال · ۱۰ ربات',d:'در این زمین بدون ثبت جام، رباتت را تمرین بده.',isNew:true};
const ARENAS=[ARENA_ARMAN,ARENA_BR];
let selA=0;/* لیگ آنلاین به‌صورت پیش‌فرض انتخاب شده؛ زمین تمرینی همچنان در دسترس است */
/* برچسب NEW تا اولین بازی در زمین تمرینی؛ راهنمای لابی تا اولین بازی */
const lsGet=k=>{try{return localStorage.getItem(k);}catch(e){return null;}},lsSet=(k,v)=>{try{localStorage.setItem(k,v);}catch(e){}};
const isNewPrac=()=>!lsGet('ra_prac_seen');
let guide=lsGet('ra_lobby_guide')?2:0;/* 0: زمین را انتخاب کن، 1: دکمهٔ بازی، 2: تمام */
let flow=null,mi=0,run=null,sec='shoot',busy=false,opp='fix',dpsAcc=[],sceneVersion=0;
const _show=window.show;
window.show=function(id){if(id!=='arena'&&window.OnlineView)window.OnlineView.stop();if(id==='lobby'&&window.Brain&&window.Brain.hide)window.Brain.hide();/* ورود به لابی: پنجرهٔ پرامت همیشه بسته می‌شود */sceneVersion++;window.TutorialVoice.hide();clearInterval(qTimer);_show(id);camera.lead=0;if(id==='lobby'){$('#nCtl').classList.remove('on');setArena(0);flow=null;$('#arena').classList.remove('nm');document.body.classList.remove('nmode');$('#nTop').style.display=$('#nBar').style.display=$('#nCard').style.display='none';setQueueUi(false);refreshHome();refreshLeaderboard();$('#nHome').classList.add('on');if(H.pend)setTimeout(playTrophies,700);}else $('#nHome').classList.remove('on');$('#nEnd').style.display='none';};
$('#exitBtn').onclick=window.toLobby;
$('#nExit').onclick=()=>{run=null;window.toLobby();};

/* با رفتن نشانک روی نماد ربات، کادر پیام دوباره ظاهر می‌شود و بعد از خروج دوباره محو می‌شود */
document.addEventListener('mouseover',e=>{if(e.target.closest&&e.target.closest('#nAv')){window._avHover=true;$('#nBub').classList.remove('hide');}});
document.addEventListener('mouseout',e=>{if(e.target.closest&&e.target.closest('#nAv')&&!(e.relatedTarget&&e.relatedTarget.closest&&e.relatedTarget.closest('#nAv'))){window._avHover=false;const b=$('#nBub');if(b.dataset.faded==='1')b.classList.add('hide');}});
let qTimer=0,qSeq=0;
/* fade: برای توضیح بازی؛ بعد از پایان صدا و ۳ ثانیه مکث، کادر آرام محو می‌شود (پیام‌های آفرین و بریم مرحلهٔ بعد محو نمی‌شوند) */
/* متن آموزش: عبارت بین دو ستاره (*انرژی*) بولد و رنگی نشان داده می‌شود؛ صدا و تایپ با متن ساده کار می‌کنند */
const TERM_CLS=[['صندوق','g'],['انرژی','e'],['دشمن','d'],['شلیک','s'],['پرامت','p'],['مکث','y'],['قبل','y'],['شروع دوباره','y']];
const plainTx=s=>s.replace(/\*/g,'');
function richTx(s,n){let out='',left=n==null?1e9:n;
 s.split('*').forEach((seg,k)=>{if(left<=0)return;const part=seg.slice(0,left);left-=part.length;if(!part)return;
  if(k%2){const c=(TERM_CLS.find(([w])=>seg.includes(w))||[0,'y'])[1];out+='<b class="tk tk-'+c+'">'+part+'</b>';}else out+=part;});
 return out;}
function typeQ(t,fade){const el=$('#nQ'),bub=$('#nBub'),id=++qSeq,pt=plainTx(t);clearInterval(qTimer);el.textContent='';el.classList.add('typing');let i=0;
 bub.classList.remove('hide');bub.dataset.faded='';bub.classList.remove('pop');void bub.offsetWidth;bub.classList.add('pop');
 const spoken=window.TutorialVoice.say(pt),started=performance.now();
 const done=()=>{clearInterval(qTimer);el.innerHTML=richTx(t);el.classList.remove('typing');};
 el.onclick=done;qTimer=setInterval(()=>{i++;el.innerHTML=richTx(t,i);if(i>=pt.length)done();},32);
 return spoken.then(async result=>{if(result!=='cancelled'){const minimum=result==='ended'?0:Math.max(1200,t.length*55);await sleep(Math.max(0,minimum-(performance.now()-started)));}
  if(fade&&id===qSeq){await sleep(3000);if(id===qSeq){bub.dataset.faded='1';if(!window._avHover)bub.classList.add('hide');}}return result;});}
function card(h,p,b1,f1,b2,f2){window.TutorialVoice.say(plainTx(p));$('#nCh').textContent=h;$('#nCp').innerHTML=richTx(p);const a=$('#nC1'),b=$('#nC2');a.textContent=b1;a.onclick=()=>{$('#nCard').style.display='none';f1();};
 if(b2){b.style.display='';b.textContent=b2;b.onclick=()=>{$('#nCard').style.display='none';f2();};}else b.style.display='none';$('#nCard').style.display='block';}

/* ---------- ساخت صحنه (از موتور موجود) ---------- */
function enterScene(mode,keepOnline){
 if(!keepOnline&&window.OnlineView)window.OnlineView.stop();/* اتصال صف هنگام ورود به زمین حفظ می‌شود */
 sceneVersion++;window.TutorialVoice.hide();clearInterval(qTimer);
 setArena(0);_show('arena');flow=mode;$('#nCtl').classList.remove('on');$('#nPrompt').style.display='';S.TS=1;$('#nHome').classList.remove('on');$('#arena').classList.remove('prac');$('#arena').classList.add('nm');document.body.classList.add('nmode');
 unlockUI();
 Math.random=realRand;S.mode='real';newGame();S.mode=mode==='mis'?'mission':'train';S.phase='';S.TS=1;acc=0;
 const B=battle;B.enemies=[];B.over=false;B.max=1e9;B.player.color=H.color;B.player.name=H.name;$('#nTop').style.display='flex';$('#nBar').style.display='block';
}
const enemy=(kind,dx,dy,sleep,hm)=>{const A=ARENA,z=mkZ(kind,170+dx,A.h/2+dy,!!sleep);z.angle=Math.PI;if(hm){z.hp*=hm;z.maxHp=z.hp;}battle.enemies.push(z);return z;};
const still=(k,dx,dy)=>{const z=enemy(k,dx,dy);z.still=[z.x,z.y];z.cool=1e9;z.color='#d83a3a';z.name='هدف';return z;};
/* زمین تمرین اولیه: راهروی عمودی. ربات از پایین شروع می‌کند، از موانع رد می‌شود و بالا به دشمن‌ها می‌رسد */
const at=(k,x,y)=>{const z=mkZ(k,x,y,false);z.angle=Math.PI/2*-1;z.still=[x,y];z.cool=1e9;z.color='#d83a3a';z.name='هدف';battle.enemies.push(z);return z;};
const AR0={w:ARENA.w,h:ARENA.h};
function setArena(pad){if(pad){ARENA.w=1500;ARENA.h=3000;}else{ARENA.w=AR0.w;ARENA.h=AR0.h;}}
/* خانه‌های هم‌نوعِ چسبیده (ساختمان یا دیوار) یک گروه‌اند و به‌صورت یک شکل واحد کشیده می‌شوند، نه ردیف‌های جدا */
function cellGroups(cells){const seen={},byCell={};
 for(const k of Object.keys(cells)){const t=cells[k];if((t!=='building'&&t!=='wall')||seen[k])continue;
  const g={t,set:new Set()},st=[k];seen[k]=1;
  while(st.length){const q=st.pop();g.set.add(q);byCell[q]=g;const[i,j]=q.split(',').map(Number);
   for(const[a,b]of[[1,0],[-1,0],[0,1],[0,-1]]){const n=(i+a)+','+(j+b);if(cells[n]===t&&!seen[n]){seen[n]=1;st.push(n);}}}}
 return byCell;}
/* دور شکل (همه‌ی حلقه‌ها، شامل سوراخ‌ها): لبه‌های خانه‌ها به هم زنجیر می‌شوند و فقط گوشه‌ها می‌مانند. جهت: ساعتگرد روی صفحه */
function groupLoops(g){
 if(g.loops)return g.loops;const S=50,has=(i,j)=>g.set.has(i+','+j),E=new Map();
 const add=(x0,y0,x1,y1)=>{const k=x0+','+y0;if(!E.has(k))E.set(k,[]);E.get(k).push([x1,y1]);};
 for(const q of g.set){const[i,j]=q.split(',').map(Number),x=i*S,y=j*S;
  if(!has(i,j-1))add(x,y,x+S,y);if(!has(i+1,j))add(x+S,y,x+S,y+S);if(!has(i,j+1))add(x+S,y+S,x,y+S);if(!has(i-1,j))add(x,y+S,x,y);}
 const loops=[];
 for(const [k0,outs] of E){while(outs.length){let[sx,sy]=k0.split(',').map(Number);const pts=[[sx,sy]];let[cx,cy]=outs.pop();
   for(let guard=0;guard<4000&&!(cx===sx&&cy===sy);guard++){pts.push([cx,cy]);const list=E.get(cx+','+cy);if(!list||!list.length)break;
    const pd=[cx-pts[pts.length-2][0],cy-pts[pts.length-2][1]];let bi=0;
    if(list.length>1){let best=-9;list.forEach((n,ix)=>{const d=[n[0]-cx,n[1]-cy],cr=pd[0]*d[1]-pd[1]*d[0];if(cr>best){best=cr;bi=ix;}});}
    [cx,cy]=list.splice(bi,1)[0];}
   /* فقط گوشه‌ها */
   const m=pts.length,cor=[];for(let i=0;i<m;i++){const a=pts[(i+m-1)%m],b=pts[i],n=pts[(i+1)%m];if((b[0]-a[0])*(n[1]-b[1])-(b[1]-a[1])*(n[0]-b[0])!==0)cor.push(b);}
   if(cor.length>=4)loops.push(cor);}}
 return g.loops=loops;}
function loopPath(c,loops,inset,rad){
 c.beginPath();
 for(const pts of loops){const m=pts.length,P=[];
  for(let i=0;i<m;i++){const a=pts[(i+m-1)%m],b=pts[i],n=pts[(i+1)%m];
   if(!inset){P.push(b);continue;}
   const d1=[Math.sign(b[0]-a[0]),Math.sign(b[1]-a[1])],d2=[Math.sign(n[0]-b[0]),Math.sign(n[1]-b[1])],n1=[-d1[1],d1[0]],n2=[-d2[1],d2[0]];
   P.push([b[0]+inset*(n1[0]+n2[0]),b[1]+inset*(n1[1]+n2[1])]);}
  const mid=(p,q)=>[(p[0]+q[0])/2,(p[1]+q[1])/2],s=mid(P[m-1],P[0]);c.moveTo(s[0],s[1]);
  for(let i=0;i<m;i++){const e=mid(P[i],P[(i+1)%m]);c.arcTo(P[i][0],P[i][1],e[0],e[1],rad);}
  c.closePath();}}
/* جای دریچه‌ها و چراغ‌ها: مثل ساختمان قبلی، ولی برای کل شکل. دریچه‌ها وسط خانه‌های داخلی و با فاصله از هم؛ چراغ فقط روی گوشه‌ی بالا-راستِ بیرون‌زده. */
function groupDeco(g){
 if(g.deco)return g.deco;const S=50,has=(i,j)=>g.set.has(i+','+j),cells=[...g.set].map(q=>q.split(',').map(Number)).sort((a,b)=>a[1]-b[1]||a[0]-b[0]);
 const vents=[],lights=[];
 for(const[i,j]of cells){
  if(!has(i,j-1)&&!has(i+1,j))lights.push([i*S+S-16,j*S+16]);
  if(has(i-1,j)&&has(i+1,j)&&has(i,j-1)&&has(i,j+1)){const x=i*S+S/2,y=j*S+S/2;if(vents.every(v=>Math.hypot(v[0]-x,v[1]-y)>=170))vents.push([x,y]);}}
 if(!vents.length){let cx=0,cy=0;for(const[i,j]of cells){cx+=i;cy+=j;}cx/=cells.length;cy/=cells.length;
  let best=cells[0],bd=1e9;for(const q of cells){const d=Math.hypot(q[0]-cx,q[1]-cy);if(d<bd){bd=d;best=q;}}vents.push([best[0]*S+S/2,best[1]*S+S/2]);}
 return g.deco={vents,lights};}
/* دیوار داخل زمین: یک تکه، فلزی و برجسته؛ کوتاه‌تر از ساختمان، با درز بین خانه‌ها و پیچ */
function drawWallGroup(c,g,loops){
 const S=50,has=(i,j)=>g.set.has(i+','+j);let minY=1e9,maxY=-1e9;
 for(const q of g.set){const j=+q.split(',')[1];minY=Math.min(minY,j*S);maxY=Math.max(maxY,j*S+S);}
 c.save();
 c.fillStyle='rgba(0,0,0,.4)';c.save();c.translate(8,11);loopPath(c,loops,0,7);c.fill();c.restore();
 c.fillStyle='#1b2434';c.save();c.translate(0,6);loopPath(c,loops,0,7);c.fill();c.restore();
 const gr=c.createLinearGradient(0,minY,0,maxY);gr.addColorStop(0,'#5a6a86');gr.addColorStop(1,'#3e4b63');
 c.fillStyle=gr;loopPath(c,loops,0,7);c.fill();
 c.strokeStyle='#91a3c6';c.lineWidth=2;c.stroke();
 c.strokeStyle='rgba(255,255,255,.13)';c.lineWidth=1.5;loopPath(c,loops,5,4);c.stroke();
 c.lineWidth=2;
 for(const q of g.set){const[i,j]=q.split(',').map(Number),x=i*S,y=j*S;
  if(has(i+1,j)){c.strokeStyle='rgba(10,16,28,.45)';c.beginPath();c.moveTo(x+S,y+7);c.lineTo(x+S,y+S-7);c.stroke();c.strokeStyle='rgba(255,255,255,.08)';c.beginPath();c.moveTo(x+S+2,y+7);c.lineTo(x+S+2,y+S-7);c.stroke();}
  if(has(i,j+1)){c.strokeStyle='rgba(10,16,28,.45)';c.beginPath();c.moveTo(x+7,y+S);c.lineTo(x+S-7,y+S);c.stroke();c.strokeStyle='rgba(255,255,255,.08)';c.beginPath();c.moveTo(x+7,y+S+2);c.lineTo(x+S-7,y+S+2);c.stroke();}
  for(const[px,py]of[[x+12,y+12],[x+S-12,y+S-12]]){c.fillStyle='#2a3448';c.beginPath();c.arc(px,py,3,0,7);c.fill();c.fillStyle='rgba(255,255,255,.28)';c.beginPath();c.arc(px-.8,py-.8,1.2,0,7);c.fill();}}
 c.restore();}
let FR=0;
function drawGroupPart(c,o,t){
 const g=o.grp;if(g.fr===FR)return;g.fr=FR;
 const loops=groupLoops(g);if(!loops.length)return;
 if(g.t==='wall')return drawWallGroup(c,g,loops);
 let minY=1e9,maxY=-1e9;for(const q of g.set){const j=+q.split(',')[1];minY=Math.min(minY,j*50);maxY=Math.max(maxY,j*50+50);}
 c.save();
 c.fillStyle='rgba(0,0,0,.38)';c.save();c.translate(12,16);loopPath(c,loops,0,10);c.fill();c.restore();
 c.fillStyle='#17243a';c.save();c.translate(0,9);loopPath(c,loops,0,9);c.fill();c.restore();
 const gr=c.createLinearGradient(0,minY,0,maxY);gr.addColorStop(0,'#2c4466');gr.addColorStop(1,'#223652');
 c.fillStyle=gr;loopPath(c,loops,0,9);c.fill();c.strokeStyle='#4a6f9f';c.lineWidth=2;c.stroke();
 c.strokeStyle='rgba(125,211,252,.18)';c.lineWidth=1.5;loopPath(c,loops,10,6);c.stroke();
 const dc=groupDeco(g);
 c.fillStyle='rgba(0,0,0,.28)';for(const v of dc.vents)for(let i=0;i<4;i++)c.fillRect(v[0]-22,v[1]-14+i*8,44,4);
 for(const l of dc.lights){const on=((t>>5)+((l[0]/7)|0))%3!==0;c.fillStyle=on?'#f87171':'#5b2430';c.beginPath();c.arc(l[0],l[1],4,0,7);c.fill();}
 c.restore();}
const _dob=window.drawObstacle;window.drawObstacle=function(c,o,t){if(o.grp)return drawGroupPart(c,o,t);return _dob.apply(this,arguments);};
const _rnd=window.render;window.render=function(){FR++;return _rnd.apply(this,arguments);};
/* ادغام خانه‌های هم‌نوع در مستطیل (همان الگوریتم ویرایشگر) */
function mergeCells(cells,cw,ch){const out=[],S=50;
 for(const t of new Set(Object.values(cells))){let act={};
  for(let j=0;j<=ch;j++){const runs=[];let i=0;
   while(j<ch&&i<cw){if(cells[i+','+j]===t){let k=i;while(k+1<cw&&cells[(k+1)+','+j]===t)k++;runs.push([i,k]);i=k+1;}else i++;}
   const nx={};for(const[a,b]of runs){const key=a+'-'+b;if(act[key]){act[key].h+=S;nx[key]=act[key];}else{const r={x:a*S,y:j*S,w:(b-a+1)*S,h:S,t};out.push(r);nx[key]=r;}}
   act=nx;}}
 return out.map(r=>[r.x,r.y,r.w,r.h,r.t]);}
const LAYK='ra_layouts_v1';
/* زمین‌های ذخیره‌شدهٔ ادیتور روی دیسک سرورند؛ هنگام باز شدن بازی در حافظهٔ مرورگر هم کپی می‌شوند */
fetch('api/layouts').then(r=>r.json()).then(j=>{if(j&&typeof j==='object'&&Object.keys(j).length)localStorage.setItem(LAYK,JSON.stringify(j));}).catch(()=>{});
/* جام مرجع روی سرور است: با باز شدن بازی همان را می‌گیریم (اگر سرور در دسترس نبود، مقدار محلی می‌ماند) */
syncServerProfile();setInterval(refreshLeaderboard,15000);
/* زمین پیش‌فرض مرحلهٔ دوم (سه دشمن)؛ اگر کاربر در ادیتور نسخهٔ جدید (ver 2) ذخیره نکرده باشد همین استفاده می‌شود */
const SHOOT_DEF={cw:22,ch:15,cells:{},w:1100,h:750,start:[575,625],enemies:[[725,325],[375,325],[525,275]],obs:[],start_cell:[11,12],enemies_cell:[[14,6],[7,6],[10,5]],cubes_cell:[],cubes:[],ver:2};
function layoutFor(kind){try{const j=JSON.parse(localStorage.getItem(LAYK)),v=j&&j[kind];if(v&&Array.isArray(v.obs)&&((kind!=='run'&&kind!=='shoot')||v.ver===2))return v;}catch(e){}return kind==='shoot'?JSON.parse(JSON.stringify(SHOOT_DEF)):kind==='royale'?JSON.parse(JSON.stringify(ROYALE_DEF)):null;}
/* زمین پیش‌فرض بتل رویال (royale-map.js): ۶۰×۶۰، دیوار ساختمانی، ۱۰ اسپاون؛ صندوق را در ادیتور بگذار */
const ROYALE_DEF=(()=>{const M=window.ROYALE_MAP,c=([i,j])=>[i*50+25,j*50+25],sp=M.spawns,cells={};
 M.rows.forEach((r,j)=>{for(let i=0;i<r.length;i++)if(r[i]==='#')cells[i+','+j]='building';});
 return {cw:M.cw,ch:M.ch,cells,w:M.cw*50,h:M.ch*50,start:c(sp[0]),enemies:[],obs:[],spawns:sp.map(c),chests:[],spawns_cell:sp,chests_cell:[],ver:2};})();
function trainPad(kind){const L=layoutFor(kind);ARENA.w=L?L.w:(kind==='run'?1300:1500);ARENA.h=L?L.h:(kind==='run'?1500:3000);/* newGame اندازه را بر اساس حالت می‌گذارد؛ هر صحنه‌ی بعدی دوباره newGame می‌زند */const B=battle,W=ARENA.w,Hh=ARENA.h,cx=W/2,T=25;
 const o=[{x:0,y:0,w:W,h:T,type:'wall'},{x:0,y:Hh-T,w:W,h:T,type:'wall'},{x:0,y:0,w:T,h:Hh,type:'wall'},{x:W-T,y:0,w:T,h:Hh,type:'wall'}];
 const D=L||DEFL[kind];
 if(L&&L.cells&&L.cw){const cl={};for(const k of Object.keys(L.cells)){const[i,j]=k.split(',').map(Number);if(i>=1&&j>=1&&i<L.cw-1&&j<L.ch-1)cl[k]=L.cells[k];}
  L.cells=cl;D.obs=mergeCells(cl,L.cw,L.ch);
  const clampX=x=>Math.min(Math.max(x,75),W-75),clampY=y=>Math.min(Math.max(y,75),Hh-75);
  D.start=[clampX(D.start[0]),clampY(D.start[1])];if(L.enemies)L.enemies=L.enemies.map(([x,y])=>[clampX(x),clampY(y)]);}
 const grpOf=L?cellGroups(L.cells):{};
 for(const [x,y,w,h,t] of D.obs){
  /* جعبه‌ها هیچ‌وقت یکی نمی‌شوند: هر خانه یک جعبه‌ی مربعی جدا (جعبه‌ی کش‌آمده زشت است) */
  if(t==='crate'){for(let i=0;i<Math.max(1,Math.round(w/50));i++)for(let j=0;j<Math.max(1,Math.round(h/50));j++)o.push({x:x+i*50,y:y+j*50,w:50,h:50,type:t,hp:40,maxHp:40});continue;}
  const r={x,y,w,h,type:t},g=grpOf[(x/50)+','+(y/50)];if(g){r.grp=g;(g.parts||(g.parts=[])).push(r);}o.push(r);}
 B.obstacles=o;B.floor=null;B.player.x=D.start[0];B.player.y=D.start[1];B.player.angle=-Math.PI/2;
 if(L){B.enemies=[];for(const [x,y] of L.enemies)at('walker',x,y);}}
const DEFL={run:{start:[625,1425],obs:[[50,600,550,50,'building'],[700,600,550,50,'building'],[50,650,450,100,'building'],[800,650,450,100,'building'],[450,750,50,700,'building'],[800,750,50,700,'building'],[600,1050,200,50,'crate'],[500,1300,200,50,'crate']]},shoot:{start:[750,750],obs:[]}};
function dummy(x,y){const z=mkZ('walker',x,y,false);z.dummy=true;z.hp=z.maxHp=4000;z.r=21;z.color='#d83a3a';z.name='هدف';z.cool=1e9;battle.enemies.push(z);}
function placeDummies(){const A=ARENA;for(const [fx,fy] of [[.5,.25],[.5,.75],[.8,.25],[.8,.75]])dummy(A.w*fx,A.h*fy);}

/* ---------- آموزش ---------- */
function startMission(i){mi=Math.min(i,MIS.length-1);const m=MIS[mi];sec=m.sec==='both'?'move':m.sec;
 enterScene('mis');$('#nTitle').textContent='مرحلهٔ '+faNum(mi+1)+' از '+faNum(MIS.length)+' · '+m.t;$('#nDps').textContent='';
 typeQ(m.q,true);$('#nOpp').style.display='none';
 window.Brain.reset();/* هر مرحله با کادر پرامت خالی شروع می‌شود */
 enterSceneRun(m.pad);buildScene(m);fitCam();S.TS=0;run=null;openPM();}
/* صحنهٔ هر مرحله: زمین، دشمن‌ها، و در صورت نیاز الماس یا صندوق گنج (صندوق یک هدف ثابت است که با شلیک می‌شکند) */
function buildScene(m){if(m.pad)trainPad(m.pad);if(!(m.pad&&layoutFor(m.pad)))m.setup(enemy,still,at);
 camera.lead=m.pad==='shoot'?.3:0;/* ربات پایین‌تر از وسط صفحه */
 const B=battle,P=B.player;B.gem=null;B.cubes=null;
 if(m.cubes){B.enemies=[];const Lc=layoutFor('run');B.cubes=(Lc&&Lc.cubes?Lc.cubes:[[725,1375],[625,1225],[525,1025],[725,875],[975,275],[825,475],[325,375],[575,275],[675,175],[375,175]]).map(([x,y])=>({x,y}));}
 if(m.chest){B.enemies=[];const z=mkZ('walker',P.x,P.y-380,false);z.chest=true;z.still=[z.x,z.y];z.cool=1e9;z.hp=z.maxHp=120;z.r=30;z.color='#f5b43a';z.name='صندوق';z.angle=Math.PI/2;B.enemies.push(z);B.gem={x:z.x,y:z.y,got:false,state:'chest',t0:0,src:z};}}
/* مقیاس اولیهٔ مرحلهٔ اول: فقط یک‌بار موقع شروع صحنه؛ بعدش زوم دست کاربر است */
function fitCam(){const m=MIS[mi];if(!(m&&m.pad==='run'))return;const cw=battleCanvas.clientWidth,ch=battleCanvas.clientHeight;if(!cw||!ch)return;const[a,b]=zoomBounds(cw,ch);camera.targetZoom=Math.max(a,Math.min(b,cw/1300));}
function beginRun(){sceneVersion++;window.TutorialVoice.stop();const m=MIS[mi],z=camera.targetZoom;enterSceneRun(MIS[mi].pad);buildScene(m);camera.zoom=camera.targetZoom=z;/* زوم را همان چیزی نگه می‌دارد که کاربر دیده بود */camera.lead=m.pad==='shoot'?.3:0;run={t0:0,lim:MIS[mi].lim,done:false,x0:battle.player.x,y0:battle.player.y};}
function enterSceneRun(pad){setArena(!!pad);Math.random=realRand;S.mode='real';newGame();S.mode='mission';acc=0;const B=battle;B.enemies=[];B.over=false;B.max=1e9;B.player.color=H.color;B.player.name=H.name;S.TS=1;}
function missionTick(){if(flow!=='mis'||!run||run.done||!battle)return;const B=battle,P=B.player,alive=B.enemies.filter(z=>z.alive).length,g=B.gem,now=performance.now();
 for(const z of B.enemies)if(z.still&&z.alive){z.x=z.still[0];z.y=z.still[1];z.cool=1e9;}
 const reach=!!MIS[mi].goalY&&P.y<MIS[mi].goalY;let got=false;
 if(B.cubes)B.cubes=B.cubes.filter(q=>{if(P.alive&&Math.hypot(P.x-q.x,P.y-q.y)<P.r+30){boom(q.x,q.y,'#86efac',10);sfx(740,.12,'triangle',.05);return false;}return true;});
 if(g&&!g.got){
  if(g.state==='chest'&&!g.src.alive){g.state='pop';g.t0=now;sfx(660,.25,'triangle',.06);}
  else if(g.state==='pop'&&now-g.t0>1300){g.state='fly';g.t0=now;}
  else if(g.state==='fly'&&now-g.t0>600)got=true;
  else if(g.state==='wait'&&P.alive&&Math.hypot(P.x-g.x,P.y-g.y)<P.r+45)got=true;
  if(got){g.got=true;g.state='got';boom(P.x,P.y,'#67e8f9',30);sfx(880,.3,'triangle',.07);}}
 if(!P.alive||(!alive&&!g&&!B.cubes)||(B.cubes&&!B.cubes.length)||reach||got||B.tick>=run.lim){run.done=true;B.over=true;finishRun({alive:P.alive,hp:P.alive?P.hp/P.maxHp:0,cleared:!alive,dist:Math.hypot(P.x-run.x0,P.y-run.y0),y:P.y,gem:!!(g&&g.got),cubes:!!(B.cubes&&!B.cubes.length)});}}
/* الماس و صندوق گنج: نقاشی داخل زمین */
function drawGem(c,g){if(g.state==='chest')return;const now=performance.now(),P=battle.player,bob=Math.sin(now/300)*6;let x=g.x,y=g.y+bob,sc=1;
 if(g.state==='pop')y=g.y-60*Math.min(1,(now-g.t0)/400)+bob;
 else if(g.state==='fly'){const q=Math.min(1,(now-g.t0)/600),y0=g.y-60;x=g.x+(P.x-g.x)*q;y=y0+(P.y-y0)*q;sc=1-.5*q;}
 c.save();c.translate(x,y);c.scale(sc,sc);
 c.scale(1.35,1.35);drawCube(c,{x:0,y:0});/* از صندوق همیشه انرژی بیرون می‌آید (الماس در بازی نیست) */
 c.restore();}
function drawChest(c,z){const R=z.r,x=z.x,y=z.y,hp=z.hp/z.maxHp,W=R*2.2,Hh=R*1.5;
 c.fillStyle='rgba(0,0,0,.4)';c.beginPath();c.ellipse(x+4,y+Hh*.55,W*.6,R*.45,0,0,7);c.fill();
 c.lineJoin='round';c.lineWidth=3;c.strokeStyle='#3b2410';
 c.fillStyle=z.flash>0?'#ffe9b0':'#8a5a2b';c.fillRect(x-W/2,y-Hh/2,W,Hh);c.strokeRect(x-W/2,y-Hh/2,W,Hh);
 c.fillStyle=z.flash>0?'#fff':'#a8702f';c.beginPath();c.moveTo(x-W/2,y-Hh*.05);c.lineTo(x-W/2,y-Hh/2);c.quadraticCurveTo(x,y-Hh*.95,x+W/2,y-Hh/2);c.lineTo(x+W/2,y-Hh*.05);c.closePath();c.fill();c.stroke();
 c.fillStyle='#f5b43a';c.fillRect(x-W/2,y-Hh*.12,W,Hh*.14);c.fillRect(x-W*.3,y-Hh/2,W*.08,Hh);c.fillRect(x+W*.22,y-Hh/2,W*.08,Hh);
 c.fillStyle='#fde68a';c.fillRect(x-5,y-Hh*.2,10,Hh*.3);c.strokeStyle='#92400e';c.lineWidth=2;c.strokeRect(x-5,y-Hh*.2,10,Hh*.3);
 if(hp<1){const bw=W,bx=x-bw/2,by=y-Hh/2-16;c.fillStyle='rgba(2,6,16,.75)';c.fillRect(bx-1.5,by-1.5,bw+3,8);c.fillStyle=hp>.5?'#84cc16':hp>.25?'#f59e0b':'#ef4444';c.fillRect(bx,by,bw*hp,5);}}
function drawCube(c,q){const x=q.x,y=q.y+Math.sin(performance.now()/350+x)*3,w=17;
 c.save();c.translate(x,y);const gl=c.createRadialGradient(0,0,2,0,0,38);gl.addColorStop(0,'rgba(132,255,80,.5)');gl.addColorStop(1,'rgba(132,255,80,0)');c.fillStyle=gl;c.beginPath();c.arc(0,0,38,0,7);c.fill();
 c.lineJoin='round';c.lineWidth=2.5;c.strokeStyle='#14532d';
 c.fillStyle='#bef264';c.beginPath();c.moveTo(0,-w);c.lineTo(w,-w/2);c.lineTo(0,0);c.lineTo(-w,-w/2);c.closePath();c.fill();c.stroke();
 c.fillStyle='#4ade80';c.beginPath();c.moveTo(-w,-w/2);c.lineTo(0,0);c.lineTo(0,w);c.lineTo(-w,w/2);c.closePath();c.fill();c.stroke();
 c.fillStyle='#16a34a';c.beginPath();c.moveTo(w,-w/2);c.lineTo(0,0);c.lineTo(0,w);c.lineTo(w,w/2);c.closePath();c.fill();c.stroke();c.restore();}
const _df=window.drawFloats;window.drawFloats=function(c){const g=battle&&battle.gem;if(battle&&battle.royale&&flow==='royale')drawZone(c);if(battle&&battle.cubes)for(const q of battle.cubes)drawCube(c,q);if(g&&!g.got)drawGem(c,g);return _df.apply(this,arguments);};
function finishRun(r){const m=MIS[mi],won=m.ok(r);
 if(won){H.done=Math.max(H.done,mi+1);save();const last=mi>=MIS.length-1;
  $('#nCard').style.display='none';const next=mi+1,msg2=last?null:'حالا بریم مرحلهٔ بعد.',version=sceneVersion;
  (async()=>{
   await typeQ('آفرین!');
   if(version!==sceneVersion)return;
   await sleep(600);if(version!==sceneVersion)return;
   if(msg2){await typeQ(msg2);
   if(version!==sceneVersion)return;
   await sleep(600);if(version!==sceneVersion)return;}
   if(last)window.toLobby();else startMission(next);
  })();}
 else card('هنوز نشد',m.bad,'دوباره اجرا',()=>beginRun());}

/* ---------- کارگاه طراحی ---------- */
function startWork(){sec='move';enterScene('work');$('#nTitle').textContent='طراحی ربات';typeQ('ربات روی هدف‌ها امتحان می‌شود. با *پرامت* بگو چه کار کند.',true);
 $('#nOpp').style.display='';$('#nOpp').textContent='حریف: ثابت';opp='fix';enterSceneWork();openPM();}
function enterSceneWork(){setArena(0);Math.random=realRand;S.mode='real';newGame();S.mode='train';acc=0;const B=battle;B.enemies=[];B.over=false;B.max=1e9;B.player.color=H.color;B.player.name=H.name;S.TS=1;dpsAcc=[];if(opp==='fix')placeDummies();else for(let i=0;i<3;i++)spawnZ();}
function spawnZ(){const A=ARENA,k=['walker','runner','walker'][(Math.random()*3)|0];battle.enemies.push(mkZ(k,A.w*(.55+Math.random()*.35),A.h*(.2+Math.random()*.6)));}
function workTick(){if(flow!=='work'||!battle)return;const B=battle;
 if(opp==='fix'){let sum=0;for(const z of B.enemies){if(z.dummy){if(z.hp<500)z.hp=z.maxHp;sum+=z.maxHp-z.hp;}}
  const n=performance.now();dpsAcc.push([n,sum]);while(dpsAcc.length&&n-dpsAcc[0][0]>3000)dpsAcc.shift();
  const dmg=dpsAcc.length>1?Math.max(0,dpsAcc[dpsAcc.length-1][1]-dpsAcc[0][1]):0;$('#nDps').textContent='آسیب در ثانیه: '+faNum(Math.round(dmg/3));}
 else{$('#nDps').textContent='';if(B.tick%200===0&&B.enemies.filter(z=>z.alive).length<4)spawnZ();if(!B.player.alive){B.player.alive=true;B.player.hp=B.player.maxHp;}}}
document.addEventListener('click',e=>{const b=e.target.closest('#nOpp');if(b){opp=opp==='fix'?'zomb':'fix';b.textContent='حریف: '+(opp==='fix'?'ثابت':'زامبی');enterSceneWork();}});

/* ---------- پرامت: همان صفحهٔ پرامت قبلی (#pm). بعد از بستنش، ربات با قانون‌های تازه دوباره امتحان می‌شود ---------- */
function openPM(){if(royOnline&&flow==='royale')return;/* در زمین آنلاین پنجرهٔ پرامت باز نمی‌شود */$('#nCard').style.display='none';
 const ex=[];/* جمله‌های آمادهٔ پیشنهادی هیچ‌وقت نشان داده نمی‌شوند */
 window.Brain.open(test=>{
  /* الگوریتم تازه همان لحظه جایگزین می‌شود (brain.js در rebuild برنامه را عوض می‌کند)؛ فقط اگر اجرا جریان ندارد دوباره شروع می‌شود */
  if(test){const B=battle;
   if(flow==='mis'){if(!(run&&!run.done&&B&&B.player&&B.player.alive))beginRun();}
   else if(flow==='work'){if(!(B&&B.player))enterSceneWork();}
   else if(flow==='royale'){if(!(B&&B.royale&&!B.royale.over&&B.player&&B.player.alive))startRoyale(true);}}
  },ex,sec==='shoot'?'shoot':'move');}
$('#nPrompt').onclick=openPM;
const _st=document.createElement('style');_st.textContent='body.bpanel #nPrompt{display:none}#nPrompt{padding:8px 18px;font-size:15px;margin-inline-start:8px}';document.head.append(_st);

/* ---------- محدودیت فقط در آموزش: ربات تا قانونش را نگیرد حرکت یا شلیک نمی‌کند ---------- */
const _rm=window.requestMotion;window.requestMotion=function(ent){if(flow==='mis'&&battle&&ent===battle.player&&!hasM())return;return _rm.apply(this,arguments);};
const _fb=window.fireBulletFrom;window.fireBulletFrom=function(owner,angle,isPlayer){if(flow==='mis'&&battle&&isPlayer&&!hasS())return;return _fb.apply(this,arguments);};
/* ---------- هدف تمرینی: جان ثابت، حرکت و حمله ندارد ---------- */
const _za=window.zombieAI;window.zombieAI=function(z){if(z&&(z.dummy||z.chest))return;return _za.apply(this,arguments);};
const _dz1=window.drawZombie;window.drawZombie=function(c,z,t){if(z.chest)return drawChest(c,z);return _dz1.apply(this,arguments);};
const _dz=window.drawZombie;window.drawZombie=function(c,z,t){if(!z.dummy)return _dz.apply(this,arguments);const R=z.r;
 c.fillStyle='rgba(0,0,0,.4)';c.beginPath();c.ellipse(z.x+3,z.y+R*.8,R*1.1,R*.6,0,0,7);c.fill();
 c.fillStyle=z.flash>0?'#fff':'#d83a3a';c.beginPath();c.arc(z.x,z.y,R,0,7);c.fill();c.strokeStyle='#5a1414';c.lineWidth=3;c.stroke();
 c.fillStyle='#fff';for(const s of [-1,1]){c.beginPath();c.arc(z.x+s*R*.95,z.y,R*.38,0,7);c.fill();}
 c.fillStyle='#fff';c.font='700 14px Vazirmatn,Tahoma';c.textAlign='center';c.fillText(faNum(Math.ceil(z.hp)),z.x,z.y-R-8);};

/* ---------- بتل رویال: ۱۰ ربات (تو + ۹ ربات)؛ زمین، اسپاون‌ها و صندوق‌ها از ادیتور (نوع «بتل رویال») ---------- */
const ROY_NAMES=['تو','بهمن','پویا','تینا','جمشید','سارا','شروین','کیان','مهسا','نیما'];
const ROY_COLS=['#22d3ee','#fb7185','#f59e0b','#a78bfa','#34d399','#f472b6','#60a5fa','#facc15','#2dd4bf','#c084fc'];
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=(Math.random()*(i+1))|0;[a[i],a[j]]=[a[j],a[i]];}return a;};
const blocked=(x,y,m)=>battle.obstacles.some(o=>x>o.x-m&&x<o.x+o.w+m&&y>o.y-m&&y<o.y+o.h+m);
function roySpawns(L){const pts=shuffle((L.spawns||[]).map(p=>p.slice()));
 for(let t=0;pts.length<10&&t<800;t++){const x=90+Math.random()*(ARENA.w-180),y=90+Math.random()*(ARENA.h-180);if(!blocked(x,y,30)&&pts.every(p=>Math.hypot(p[0]-x,p[1]-y)>160))pts.push([x,y]);}
 while(pts.length<10)pts.push([ARENA.w/2+pts.length*30,ARENA.h/2]);
 return pts.slice(0,10);}
let royOnline=false;/* زمین آنلاین = همان زمین تمرینی، بدون پنجرهٔ پرامت، با ربات‌های خاکستری و جام */
function startRoyale(noPanel,online,alreadyQueued){
 royOnline=!!online;enterScene('royale',!!alreadyQueued);sec='move';
 if(online){startOnlineArena(!!alreadyQueued);return;}/* زمین آنلاین: همهٔ محاسبات روی سرور است؛ اینجا فقط نمایش */
 trainPad('royale');if(online){$('#nPrompt').style.display='none';window.Brain.hide();noPanel=true;}
 const B=battle,L=layoutFor('royale'),P=B.player,cx=ARENA.w/2,cy=ARENA.h/2,pts=roySpawns(L);
 B.allied=false;B.cubes=[];B.gem=null;
 $('#nTitle').textContent=online?'زمین آنلاین · ۱۰ ربات':'زمین تمرینی · ۱۰ ربات';$('#nOpp').style.display='none';$('#nBar').style.display='none';$('#nCard').style.display='none';
 P.x=pts[0][0];P.y=pts[0][1];P.angle=Math.atan2(cy-P.y,cx-P.x);P.cubes=0;
 const bots=[],chests=[];
 for(let i=1;i<10;i++){const[x,y]=pts[i],z=mkZ('bot',x,y);z.hp=z.maxHp=100;z.name=online?'ربات':ROY_NAMES[i];z.color=online?'#9ca3af':ROY_COLS[i];z.royale=true;z.cubes=0;z.angle=Math.atan2(cy-y,cx-x);z.cool=30+((Math.random()*60)|0);B.enemies.push(z);bots.push(z);}
 for(const[x,y]of L.chests||[]){const z=mkZ('walker',x,y,false);z.chest=true;z.still=[x,y];z.cool=1e9;z.hp=z.maxHp=120;z.r=24;z.color='#f5b43a';z.name='صندوق';z.angle=Math.PI/2;B.enemies.push(z);chests.push(z);}
 B.royale={bots,chests,over:false,k:0,kMax:Math.floor(Math.min(ARENA.w,ARENA.h)/100)-4};camera.x=P.x;camera.y=P.y;S.TS=1;B.royale.hist=[];$('#nCtl').classList.remove('lost');if(!online)$('#nCtl').classList.add('on');$('#nPause').textContent='⏸ مکث';$('#nPause').classList.remove('on');
 if(!noPanel){if(!online&&!lsGet('ra_prac_tut'))startPracTut();else openPM();}}
/* ---------- آموزش دکمه‌های زمین تمرینی (فقط بار اول): دکمه‌ها یکی‌یکی توضیح داده می‌شوند ---------- */
const tcss=document.createElement('style');tcss.textContent='#nTutBk{position:fixed;inset:0;z-index:60;display:none}#nTut{position:fixed;z-index:61;display:none;width:min(270px,calc(100% - 20px));padding:14px 16px;border-radius:14px;background:#fff;color:#0a1230;border:3px solid #0a1230;box-shadow:0 6px 0 rgba(0,0,0,.4);font:800 16px/1.8 Vazirmatn,Tahoma,sans-serif;direction:rtl;text-align:center}#nTut .nb{width:100%;margin-top:10px;padding:10px;font-size:17px}#nTut small{display:block;opacity:.6;font-size:13px}';document.head.append(tcss);
document.body.insertAdjacentHTML('beforeend','<div id="nTutBk"></div><div id="nTut"><small id="nTutN"></small><div id="nTutT"></div><button class="nb g" id="nTutGo"></button></div>');
const PRAC_STEPS=[
 {sel:'#nPause',t:'*مکث*: بازی را نگه می‌دارد. دوباره بزنی، ادامه می‌یابد.'},
 {sel:'#nRew',t:'*۵ ثانیه قبل*: بازی را ۵ ثانیه به عقب می‌برد.'},
 ];
/* توضیح «شروع دوباره» جدا است: فقط بعد از اولین باخت نشان داده می‌شود */
const RESTART_STEP=[{sel:'#nRestart',t:'باختی! با *شروع دوباره* از اول شروع کن.'}];
function startPracTut(steps,key,reopenPanel){steps=steps||PRAC_STEPS;key=key||'ra_prac_tut';reopenPanel=reopenPanel!==false;let i=0;const bk=$('#nTutBk'),box=$('#nTut'),prevTS=1;if(reopenPanel)window.Brain.hide();S.TS=0;bk.style.display='block';
 const clear=()=>document.querySelectorAll('.hintGlow').forEach(x=>x.classList.remove('hintGlow'));
 const end=()=>{clear();bk.style.display=box.style.display='none';lsSet(key,'1');if(flow==='royale'&&battle&&battle.royale){S.TS=prevTS;if(reopenPanel)openPM();}};
 const step=()=>{clear();if(i>=steps.length){end();return;}const s=steps[i];
  const el=$(s.sel);el.classList.add('hintGlow');$('#nTutN').textContent=steps.length>1?faNum(i+1)+' از '+faNum(steps.length):'';$('#nTutT').innerHTML=richTx(s.t);$('#nTutGo').textContent=i===steps.length-1?'فهمیدم':'بعدی';
  box.style.display='block';const r=el.getBoundingClientRect(),w=box.offsetWidth,h=box.offsetHeight;
  box.style.left=Math.max(10,Math.min(innerWidth-w-10,r.left+r.width/2-w/2))+'px';box.style.top=(s.below?r.bottom+16:Math.max(10,r.top-h-16))+'px';};
 $('#nTutGo').onclick=()=>{i++;step();};step();}
function startOnlineArena(alreadyQueued){
 window.Brain.hide();$('#nPrompt').style.display='none';
 const B=battle;B.enemies=[];B.cubes=[];B.gem=null;B.allied=false;B.royale=null;S.TS=0;
 $('#nTitle').textContent='لیگ آنلاین · بتل رویال';$('#nOpp').style.display='none';$('#nBar').style.display='none';$('#nCard').style.display='none';$('#nDps').textContent=alreadyQueued?'زمین پیدا شد؛ در حال ورود…':'در حال اتصال به صف لیگ…';
 if(alreadyQueued)return;
 window.OnlineView.start({name:H.name,color:H.color,program:window.Brain.program(),
  onQueue:(q,message)=>setQueueUi(true,message),
  onMatchFound:info=>{setQueueUi(false);toast('زمین پیدا شد · '+faNum(info.players)+' بازیکن واقعی');startRoyale(true,true,true);},
  onEnd:(rank,srv)=>{showEnd(rank,srv);refreshLeaderboard();syncServerProfile();},
  onFail:msg=>{setQueueUi(false);toast(msg);window.toLobby();}});}
/* ربات حذف‌شده: ۱ انرژی، و اگر n انرژی داشت، نصفِ (n+۱) رو به پایین (۳→۲، ۴→۲، ۵→۳، ۶→۳) */
/* عدد قدرت کنار نوار جان هر ربات: ۱ + تعداد انرژی‌هایی که برداشته (موقع اسپاون ۱ است) */
const _drb=window.drawRobot;window.drawRobot=function(c,r,isPlayer){const res=_drb.apply(this,arguments);
 if(flow==='royale'&&battle&&(battle.royale||battle.royaleOnline)&&r.alive&&!r.nobar&&!r.chest){const bw=isPlayer?60:48,x=r.x-bw/2-15,y=r.y-r.r-17,n=(r.cubes||0)+1;
  c.save();c.fillStyle='#4ade80';c.strokeStyle='#14532d';c.lineWidth=2;roundRect(c,x-10,y-10,20,20,6);c.fill();c.stroke();
  c.fillStyle='#052e16';c.font='900 14px Vazirmatn,Tahoma,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(faNum(n),x,y+1);c.restore();}
 return res;};
const dropN=n=>Math.max(1,Math.floor(((n||0)+1)/2));
const ZONE_T=7*60;/* هر ۷ ثانیه یک بلاک (۶۰ تیک در ثانیه) */
const zoneD=B=>{const k=Math.min(B.royale.kMax,Math.floor(B.tick/ZONE_T));return k?50*(k+1):0;};
const _fb2=window.fireBulletFrom;window.fireBulletFrom=function(owner){if(owner&&battle)owner._lf=battle.tick;return _fb2.apply(this,arguments);};
/* حلقهٔ تازهٔ زون دیوار می‌شود (کسی نمی‌تواند واردش شود و گلوله هم رد نمی‌شود)؛ هر کس که داخلش بود به بیرونش هل داده می‌شود */
function growZone(B,k){const W=ARENA.w,Hh=ARENA.h,a=k===1?0:50*k,b=50*(k+1),T=b-a,R=B.royale;
 for(const r of [{x:a,y:a,w:W-2*a,h:T},{x:a,y:Hh-b,w:W-2*a,h:T},{x:a,y:b-T+T,w:T,h:Hh-2*b},{x:W-b,y:b,w:T,h:Hh-2*b}])B.obstacles.push({...r,type:'wall'});
 B.nav=null;B.floor=null;
 const cl=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
 for(const r of [B.player,...R.bots])if(r.alive){const m=b+r.r+2;r.x=cl(r.x,m,W-m);r.y=cl(r.y,m,Hh-m);}
 for(const q of B.cubes){q.x=cl(q.x,b+20,W-b-20);q.y=cl(q.y,b+20,Hh-b-20);}
 for(const z of R.chests)if(z.alive&&(z.x<b+z.r||z.x>W-b-z.r||z.y<b+z.r||z.y>Hh-b-z.r)){z.alive=false;z.dropped=1;}}
function drawZone(c){const B=battle,R=B.royale,W=ARENA.w,Hh=ARENA.h,d=zoneD(B),n=Math.min(R.kMax,Math.floor(B.tick/ZONE_T)+1),dn=50*(n+1);
 c.save();if(d){c.fillStyle='rgba(220,38,38,.30)';c.beginPath();c.rect(0,0,W,Hh);c.rect(d,d,W-2*d,Hh-2*d);c.fill('evenodd');c.strokeStyle='#ef4444';c.lineWidth=4;c.strokeRect(d,d,W-2*d,Hh-2*d);}
 if(R.k<R.kMax||!d){c.setLineDash([18,14]);c.strokeStyle='rgba(250,204,21,.8)';c.lineWidth=3;c.strokeRect(dn,dn,W-2*dn,Hh-2*dn);}c.restore();}
function dropCubes(x,y,n){const B=battle;for(let i=0;i<n;i++){const a=Math.random()*6.283,d=i?26+Math.random()*26:0;let qx=x+Math.cos(a)*d,qy=y+Math.sin(a)*d;if(qx<60||qx>ARENA.w-60||qy<60||qy>ARENA.h-60||blocked(qx,qy,14)){qx=x;qy=y;}B.cubes.push({x:qx,y:qy});}}
/* جام بعد از بازی: هر چه سطحت بالاتر باشد، همان رتبه جام کمتری می‌دهد (سطح ۱ نفر ۶ام: ۳+، سطح ۳ نفر ۶ام: ۰). رتبه‌های آخر منفی می‌شوند */
const ROY_BASE=[10,8,6,5,4,3,1,0,-1,-2];
const rewardOf=(rank,lv)=>{const d=Math.round(ROY_BASE[rank-1]-1.5*(lv-1));return rank===1?Math.max(d,3):d;};
const _est=document.createElement('style');_est.textContent=`
#nEnd{position:fixed;inset:0;z-index:12;display:none;overflow:hidden;background:radial-gradient(circle at 35% 45%,#6aa4ff,#2f6bff 55%,#1b3fa8);font-family:Vazirmatn,Tahoma,sans-serif;direction:rtl;color:#fff}
#nEndT{position:absolute;top:28px;left:34px;direction:rtl;font-size:clamp(30px,5vw,56px);font-weight:900;font-style:italic;text-shadow:0 4px 0 #0a1230,3px 3px 0 #0a1230,-3px 3px 0 #0a1230}
#nEndTr{position:absolute;top:calc(28px + clamp(44px,7vw,80px));left:38px;direction:ltr;display:flex;align-items:center;gap:8px;font-size:30px;font-weight:900;text-shadow:0 3px 0 #0a1230}
#nEndTr.neg b{color:#ff7a7a}#nEndTr.zero b{color:#dbe6ff}
#nEndBot{position:absolute;left:50%;top:52%;width:min(60vh,440px);height:min(60vh,440px);transform:translate(-50%,-50%)}
@keyframes nEndB{from{transform:translateY(0) rotate(-4deg)}to{transform:translateY(-6px) rotate(4deg)}}
#nEndH{position:absolute;left:54%;top:14%;font-size:44px;letter-spacing:6px;animation:nEndB 1.2s ease-in-out infinite alternate}
#nEndBtns{position:absolute;right:0;bottom:18px;display:flex;gap:14px;padding:0 24px;direction:rtl}
#nEndBtns .nb{padding:14px 30px;font-size:22px}
`;document.head.append(_est);
document.body.insertAdjacentHTML('beforeend','<div id="nEnd"><div id="nEndT"></div><div id="nEndTr"><span>🏆</span><b></b></div><canvas id="nEndBot" width="520" height="520"></canvas><div id="nEndBtns"><button class="nb y" id="nEndAgain">بازی دوباره</button><button class="nb b" id="nEndGo">ادامه</button></div></div>');
$('#nEndAgain').onclick=()=>{$('#nEnd').style.display='none';startRoyale(true,royOnline);};
$('#nEndGo').onclick=()=>{$('#nEnd').style.display='none';window.toLobby();};
function showEnd(rank,srv){/* زمین تمرینی جام نمی‌دهد؛ فقط می‌گوید نفر چندم شدی */
 S.TS=0;$('#nCard').style.display='none';window.Brain.hide();/* پایان مچ: پنجرهٔ پرامت بسته می‌شود */
 $('#nEndT').textContent=rank===1?'تو نفر اول شدی!':'تو نفر '+faNum(rank)+' شدی';
 if(royOnline){/* زمین آنلاین: جام را سرور داده است */
  /* جام را فقط سرور حساب می‌کند (server/players.js)؛ اینجا فقط نتیجه‌اش نشان داده و ذخیرهٔ محلی به‌روز می‌شود */
  const old=H.tr;if(srv&&typeof srv.total==='number')H.tr=srv.total;const eff=H.tr-old;H.pend=(H.pend||0)+eff;save();
  const t=$('#nEndTr');t.style.display='flex';t.className=eff<0?'neg':eff===0?'zero':'';t.querySelector('b').textContent=(eff>0?'+':eff<0?'−':'')+faNum(Math.abs(eff));}
 else $('#nEndTr').style.display='none';
 $('#nEnd').style.display='block';endRobot();}
/* ربات خودمان (همان نقاشی داخل بازی) بزرگ روی صفحهٔ پایان */
let endRaf=0;
function endRobot(){const cv=$('#nEndBot'),c=cv.getContext('2d');
 const f=t=>{if($('#nEnd').style.display==='none'){endRaf=0;return;}
  c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,520,520);c.setTransform(10,0,0,10,260,270);
  drawRobot(c,{x:0,y:0,r:17,color:H.color,angle:-.5+Math.sin(t/500)*.25,bodyAng:-.6,spd:0,tread:0,recoil:0,flash:0,alive:true,nobar:true,hp:1,maxHp:1,name:''},false,t/16);
  endRaf=requestAnimationFrame(f);};
 if(!endRaf)endRaf=requestAnimationFrame(f);}
/* انیمیشن جام در لابی: هر جام جدا به نوار بالا می‌پرد و نوار کم‌کم پر می‌شود؛ جام منفی از نوار بیرون می‌پرد */
const _fst=document.createElement('style');_fst.textContent='.nFly{position:fixed;left:0;top:0;font-size:30px;z-index:20;pointer-events:none;margin:-15px 0 0 -15px}';document.head.append(_fst);
function playTrophies(){const d=H.pend||0;if(!d||!$('#nHome').classList.contains('on'))return;H.pend=0;
 const n=Math.min(Math.abs(d),30),per=Math.abs(d)/n,r=$('#nTrN').getBoundingClientRect(),tx=r.left+r.width/2,ty=r.top+r.height/2,cx=innerWidth/2,cy=innerHeight/2,pos=d>0;
 let shown=H.tr-d;setTr(shown);
 for(let i=0;i<n;i++)setTimeout(()=>{
  const e=document.createElement('div');e.className='nFly';e.textContent='🏆';document.body.append(e);
  const sx=cx+(Math.random()-.5)*180,sy=cy+(Math.random()-.5)*120,f=pos?[sx,sy]:[tx,ty],t=pos?[tx,ty]:[sx,sy];
  if(!pos){shown-=per;setTr(shown);}
  const a=e.animate([{transform:`translate(${f[0]}px,${f[1]}px) scale(${pos?1.7:1})`,opacity:1},{transform:`translate(${t[0]}px,${t[1]}px) scale(${pos?.8:1.7})`,opacity:pos?1:0}],{duration:750,easing:'cubic-bezier(.45,0,.8,.55)',fill:'forwards'});
  a.onfinish=()=>{e.remove();if(pos){shown+=per;setTr(shown);$('#nTr').animate([{transform:'scale(1)'},{transform:'scale(1.12)'},{transform:'scale(1)'}],{duration:180});}};
 },i*140);
 setTimeout(()=>setTr(H.tr),n*140+950);}
function royaleTick(){if(flow!=='royale'||!battle||!battle.royale)return;const B=battle,R=B.royale,P=B.player;
 /* تاریخچه برای برگشت به عقب: هر نیم‌ثانیه یک عکس‌فوری (حداکثر ۳۰ ثانیه) */
 if(!R.hist)R.hist=[];if(!R.hist.length||B.tick-R.hist[R.hist.length-1].tick>=30){R.hist.push(royaleSnap());if(R.hist.length>60)R.hist.shift();}
 /* از صندوق همیشه انرژی بیرون می‌آید؛ ربات‌های حذف‌شده هم انرژی‌هایشان را جا می‌گذارند */
 for(const z of R.chests){if(z.alive){z.x=z.still[0];z.y=z.still[1];}else if(!z.dropped){z.dropped=1;dropCubes(z.x,z.y,1);boom(z.x,z.y,'#fde68a',24);sfx(660,.25,'triangle',.06);}}
 for(const z of R.bots)if(!z.alive&&!z.dropped){z.dropped=1;dropCubes(z.x,z.y,dropN(z.cubes));}
 if(!P.alive&&!P.dropped){P.dropped=1;dropCubes(P.x,P.y,dropN(P.cubes));}
 const rob=[P,...R.bots].filter(r=>r.alive);
 B.cubes=B.cubes.filter(q=>{for(const r of rob)if(Math.hypot(r.x-q.x,r.y-q.y)<r.r+30){r.cubes=(r.cubes||0)+1;r.maxHp+=10;r.hp=Math.min(r.maxHp,r.hp+10);B.floats.push({x:r.x,y:r.y-30,t:40,txt:'+۱ انرژی',col:'#86efac'});boom(q.x,q.y,'#86efac',8);if(r===P)sfx(740,.12,'triangle',.05);return false;}return true;});
 /* ترمیم: ۲ ثانیه بعد از آخرین شلیک، هر ۱ ثانیه ۱۰٪ جان؛ با شلیک دوباره قطع می‌شود */
 for(const r of rob)if(r.hp<r.maxHp&&B.tick-(r._lf||0)>=120&&B.tick-(r._lh||0)>=60){r._lh=B.tick;const h=Math.min(r.maxHp-r.hp,r.maxHp*.1);r.hp+=h;B.floats.push({x:r.x,y:r.y-30,t:40,txt:'+'+faNum(Math.round(h))+' ♥',col:'#4ade80'});}
 /* زون: هر ۲۰ ثانیه یک بلاک از حاشیه به دیوار تبدیل می‌شود */
 const nk=Math.min(R.kMax,Math.floor(B.tick/ZONE_T));while(R.k<nk)growZone(B,++R.k);
 const left=R.bots.filter(z=>z.alive).length;
 $('#nDps').textContent='زنده: '+faNum(left+(P.alive?1:0))+' از ۱۰ · انرژی: '+faNum(P.cubes||0)+(R.k<R.kMax?' · زون بعدی: '+faNum(Math.ceil((ZONE_T-B.tick%ZONE_T)/60)):'');
 if(R.over)return;
 const v=sceneVersion;
 if(!P.alive&&!royOnline){R.over=true;$('#nCtl').classList.add('lost');$('#nDps').textContent='باختی · برای بازی دوباره «شروع دوباره» را بزن';if(!lsGet('ra_prac_tut_r'))startPracTut(RESTART_STEP,'ra_prac_tut_r',false);return;}/* زمین تمرینی: بعد از باخت از بازی خارج نمی‌شود؛ فقط دکمهٔ شروع دوباره ظاهر می‌شود */
 if(!P.alive){R.over=true;const rank=left+1;setTimeout(()=>{if(v===sceneVersion)showEnd(rank);},1300);}
 else if(!left){R.over=true;setTimeout(()=>{if(v===sceneVersion)showEnd(1);},900);}}
/* هوش ربات‌های رویال: نزدیک‌ترین ربات (حتی ربات‌های دیگر)، وگرنه انرژی، وگرنه صندوق */
function royaleAI(z){const B=battle,R=B.royale,P=B.player;if(!R)return;
 let best=null,bd=1e9;
 for(const e of [P,...R.bots])if(e!==z&&e.alive){const d=Math.hypot(e.x-z.x,e.y-z.y);if(d<bd){bd=d;best=e;}}
 let cq=null,cd=1e9;for(const q of B.cubes||[]){const d=Math.hypot(q.x-z.x,q.y-z.y);if(d<cd){cd=d;cq=q;}}
 if(cq&&cd<800&&(!best||bd>380)){const s=simplePathStep(z,cq.x,cq.y,BASE_SPEED*.92);if(s)requestMotion(z,s.x,s.y);
  z.angle+=clamp(normAng(Math.atan2(cq.y-z.y,cq.x-z.x)-z.angle),-.2,.2);if(z.cool>0)z.cool--;return;}
 let tg=best;
 if(!best||bd>650){let ch=null,hd=1e9;for(const c of R.chests)if(c.alive){const d=Math.hypot(c.x-z.x,c.y-z.y);if(d<hd){hd=d;ch=c;}}if(ch&&hd<900)tg=ch;}
 if(!tg){if(z.cool>0)z.cool--;return;}
 if(z._tg!==tg){z._tg=tg;z.pv=null;}
 botAI(z,tg);}
/* هر انرژی: ۱۰ جان بیشتر و ۱۰٪ آسیب بیشتر برای صاحبش */
const _sb=window.stepBullet;window.stepBullet=function(bu){window._bo=bu.owner;try{return _sb.apply(this,arguments);}finally{window._bo=null;}};
const _dr=window.damageRobot;window.damageRobot=function(t,d){const o=window._bo;if(o&&o.cubes&&flow==='royale')d*=1+.1*o.cubes;return _dr.call(this,t,d);};
const _za2=window.zombieAI;window.zombieAI=function(z){if(z&&z.royale)return royaleAI(z);return _za2.apply(this,arguments);};

setInterval(()=>{missionTick();workTick();royaleTick();},100);
/* زمین تمرینی: مکث و برگشت ۵ ثانیه به عقب (فقط همین زمین؛ آنلاین و مأموریت‌ها این دکمه‌ها را ندارند) */
const _ctl=document.createElement('style');_ctl.textContent='#nCtl{display:none;gap:8px;align-items:center;direction:ltr;position:fixed;left:14px;bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:6}#nCtl.on{display:flex}#nRestart{display:none}#nCtl.lost #nRestart{display:inline-block}#nCtl button{padding:8px 14px;font-size:15px;white-space:nowrap}#nCtl button.on{border-color:#facc15}';document.head.append(_ctl);
$('#nTop').insertAdjacentHTML('beforeend','<span id="nCtl"><button class="nb r" id="nPracExit">🚪 خروج</button><button class="nb" id="nPause">⏸ مکث</button><button class="nb" id="nRew">⏪ ۵ ثانیه قبل</button><button class="nb y" id="nRestart">🔄 شروع دوباره</button></span>');
$('#nPracExit').onclick=()=>{$('#nCtl').classList.remove('lost','on');window.toLobby();};
$('#nRestart').onclick=()=>{$('#nCtl').classList.remove('lost');startRoyale(true,false);};
function royaleSnap(){const B=battle,R=B.royale,P=B.player;return {tick:B.tick,k:R.k,p:{x:P.x,y:P.y,angle:P.angle,hp:P.hp,maxHp:P.maxHp,alive:P.alive,cubes:P.cubes,dropped:P.dropped},bots:R.bots.map(z=>({x:z.x,y:z.y,angle:z.angle,hp:z.hp,maxHp:z.maxHp,alive:z.alive,cubes:z.cubes,dropped:z.dropped,cool:z.cool})),chests:R.chests.map(z=>({alive:z.alive,dropped:z.dropped})),cubes:B.cubes.map(q=>({x:q.x,y:q.y}))};}
function royaleRewind(){const B=battle;if(flow!=='royale'||!B||!B.royale||B.royale.over)return;const R=B.royale,P=B.player,h=R.hist||[];
 /* فقط به عکس‌فوری‌هایی برمی‌گردیم که زون همان مرحله را دارند (دیوار زون قابل برگشت نیست) */
 let idx=-1;for(let i=h.length-1;i>=0;i--)if(h[i].k===R.k&&h[i].tick<=B.tick-300){idx=i;break;}
 if(idx<0){toast('به این نقطه نمی‌شود برگشت');return;}
 const s=h[idx];h.length=idx+1;
 Object.assign(P,s.p);R.bots.forEach((z,i)=>Object.assign(z,s.bots[i]));R.chests.forEach((z,i)=>Object.assign(z,s.chests[i]));
 B.cubes=s.cubes.map(q=>({...q}));B.bullets=[];B.particles=[];B.floats=[];B.tick=s.tick;
 toast('به ۵ ثانیه قبل برگشتی');}
$('#nPause').onclick=()=>{const B=battle;if(!B||!B.royale||B.royale.over)return;const resume=S.TS===0;S.TS=resume?1:0;$('#nPause').textContent=resume?'⏸ مکث':'▶ ادامه';$('#nPause').classList.toggle('on',!resume);};
$('#nRew').onclick=royaleRewind;

/* ---------- دکمه‌های لابی ---------- */
async function queueOnlineArena(){
 if(window.OnlineView&&window.OnlineView.active()){window.OnlineView.stop();setQueueUi(false);toast('از صف لیگ خارج شدی');return;}
 const btn=$('#nPlay');btn.disabled=true;btn.textContent='اتصال…';
 try{if(H.named)await fetch('api/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:H.name,color:H.color})});}catch(e){}
 window.OnlineView.start({name:H.name,color:H.color,program:window.Brain.program(),
  onQueue:(q,message)=>setQueueUi(true,message),
  onMatchFound:info=>{setQueueUi(false);toast('زمین پیدا شد · '+faNum(info.players)+' بازیکن واقعی');startRoyale(true,true,true);},
  onEnd:(rank,srv)=>{showEnd(rank,srv);refreshLeaderboard();syncServerProfile();},
  onFail:msg=>{setQueueUi(false);toast(msg);window.toLobby();}});
}
$('#nPlay').onclick=()=>{if(ARENAS[selA].locked)return;guide=2;lsSet('ra_lobby_guide','1');placeHint();if(selA===0){queueOnlineArena();return;}lsSet('ra_prac_seen','1');startRoyale();};
$('#nDesign').onclick=()=>{if(H.done<MIS.length)startMission(H.done);else startWork();};
/* انتخاب زمین: فقط یک زمین دارد، و آن هم آنلاین است */
const FOCUS_SELECT=false;
function openArenas(){const g=$('#nArGrid');g.innerHTML='';$('#nArenaScr').classList.remove('picking');g.classList.remove('arDim');$('#nArenaScr').classList.remove('arDim');
 const close=()=>{g.classList.remove('arDim');$('#nArenaScr').classList.remove('arDim');g.querySelectorAll('.arCell').forEach(x=>x.classList.remove('open'));};
 ARENAS.forEach((A,n)=>{const w=document.createElement('div');w.className='arCell';const c=document.createElement('div');c.className=A.locked?'arC lock':'arC ok';if(n===selA&&!A.locked)c.style.outline='3px solid #facc15';
  c.innerHTML='<b class="arTop"><i class="arI" role="button" aria-label="توضیح">i</i></b><div><span class="ic"></span><span class="tx"><h3></h3><p></p></span></div>';
  c.querySelector('.ic').textContent=A.locked?'🔒':A.i;c.querySelector('h3').textContent=A.t;c.querySelector('p').textContent=A.s;
  c.querySelector('.arI').onclick=e=>{e.stopPropagation();toast(A.d);};
  if(A.isNew&&isNewPrac()){c.classList.add('yel');c.querySelector('h3').textContent='جدید!';}/* کارت زرد: فقط «جدید!» */
  if(A.locked){w.append(c);g.append(w);return;}
  const b=document.createElement('button');b.className='arSel';b.textContent='انتخاب';
  const pick=()=>{selA=n;if(guide===0)guide=1;refreshHome();$('#nArenaScr').classList.remove('on');placeHint();};
  b.onclick=e=>{e.stopPropagation();pick();};
  /* FOCUS_SELECT: سیستم قدیمی (فوکس + دکمهٔ «انتخاب») خاموش است ولی کدش مانده؛ حالا زدن روی خود کارت انتخاب می‌کند */
  c.onclick=e=>{e.stopPropagation();if(e.target.closest('.arSel'))return;
   if(c.classList.contains('yel')){lsSet('ra_prac_seen','1');c.classList.remove('yel');c.querySelector('h3').textContent=A.t;refreshHome();return;}/* اولین ضربه فقط «جدید!» را برمی‌دارد؛ ضربهٔ دوم انتخاب می‌کند */
   if(!FOCUS_SELECT){if(c.classList.contains('picked'))return;c.classList.add('picked');w.classList.add('mine');$('#nArenaScr').classList.add('picking');setTimeout(pick,170);return;}
   if(w.classList.contains('open')){close();return;}close();g.classList.add('arDim');$('#nArenaScr').classList.add('arDim');w.classList.add('open');};
  c.append(b);w.append(c);g.append(w);});
 $('#nArenaScr').onclick=close;$('#nArenaScr').classList.add('on');}
$('#nArenaBtn').onclick=()=>{openArenas();placeHint();};
/* ---------- راهنمای لابی: اول زمین را انتخاب کن، بعد «بازی» را بزن ---------- */
document.body.insertAdjacentHTML('beforeend','<div id="nHint"></div>');
const hcss=document.createElement('style');hcss.textContent='#nHint{position:fixed;z-index:8;display:none;max-width:240px;padding:10px 16px;border-radius:12px;background:#facc15;color:#1a1200;font:900 17px/1.6 Vazirmatn,Tahoma,sans-serif;direction:rtl;text-align:center;border:3px solid #0a1230;box-shadow:0 5px 0 rgba(0,0,0,.4);pointer-events:none;animation:nHintB 1s ease-in-out infinite}#nHint::after{content:"";position:absolute;left:50%;bottom:-12px;margin-left:-9px;border:9px solid transparent;border-top-color:#facc15;border-bottom:0}@keyframes nHintB{50%{transform:translateY(-7px)}}.hintGlow{animation:nGlow 1s ease-in-out infinite}@keyframes nGlow{50%{box-shadow:0 0 0 5px #facc15,0 0 26px 6px #facc15}}.newB{position:absolute;top:3px;left:12px;z-index:2;padding:1px 9px;border-radius:6px;background:#facc15;color:#1a1200;font:900 14px/20px Vazirmatn,Tahoma,sans-serif;letter-spacing:1px}.arC.lock{background:linear-gradient(135deg,#6b7280,#4b5563);filter:grayscale(1);opacity:.75;cursor:not-allowed}#nArenaBtn .newB{top:-12px;left:auto;right:18px;transform:none}#nArenaBtn{position:absolute}#nArGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important;max-width:880px;box-sizing:border-box;width:100%}.arTop{direction:ltr}#nArGrid .arC{height:190px;border-radius:6px;background:linear-gradient(135deg,#a43cff,#6a1fd0)}#nArGrid .arC.ok:not(.yel){background:linear-gradient(135deg,#a43cff,#6a1fd0)}#nArGrid .arC.yel{background:linear-gradient(135deg,#ffd93d,#f5a700)}#nArGrid .arC.lock{background:linear-gradient(135deg,#6f6c8c,#55536f);filter:none;opacity:1}#nArGrid .arC>div{flex:1;position:relative;align-items:flex-end;padding:10px 18px 16px}#nArGrid .arC .ic{position:absolute;left:14px;bottom:10px;font-size:78px;line-height:1;opacity:.95;filter:drop-shadow(0 4px 0 rgba(0,0,0,.35))}#nArGrid .arC.lock .ic{opacity:.55}#nArGrid .arC .tx{display:block;text-align:right;margin-right:0}#nArGrid .arC h3{font-size:30px;font-weight:900;color:#fff;margin:0;-webkit-text-stroke:5px #0a1230;paint-order:stroke fill;text-shadow:0 4px 0 #0a1230}#nArGrid .arC p{display:block!important;font-size:16px;font-weight:800;color:#fff;margin:2px 0 0;text-shadow:0 2px 0 #0a1230}#nArGrid .arCell.open .arC p{display:block!important}.arTop{position:absolute;top:0;left:0;right:0;height:26px;z-index:2;display:flex;align-items:center;justify-content:flex-end;padding:0 8px;transform:skewX(6deg)}.arI{width:20px;height:20px;border-radius:50%;background:#2f6bff;color:#fff;font:900 14px/20px Georgia,serif;text-align:center;font-style:normal;cursor:pointer;border:1.5px solid #fff}#nArGrid .arC.yel .ic,#nArGrid .arC.yel p{display:none!important}#nArGrid .arC.ok{cursor:pointer}#nArGrid .arCell:has(.picked){z-index:3}#nArGrid .arC.picked{animation:nPick .16s ease-in-out}@keyframes nPick{0%{transform:skewX(-6deg) scale(1)}50%{transform:skewX(-6deg) scale(1.12)}100%{transform:skewX(-6deg) scale(1)}}#nArGrid .arC.yel h3{font-size:38px}#nArGrid .arC.yel .tx{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;margin:0;width:100%;padding:0 16px}';
document.head.append(hcss);
/* افکت کلیک: دکمه‌ها یک لحظه بزرگ می‌شوند و برمی‌گردند (با خاصیت scale تا اسکیوی دکمه‌ها خراب نشود) */
const pcss=document.createElement('style');pcss.textContent='.clkPulse{animation:nClk .16s ease-in-out}@keyframes nClk{50%{scale:1.12}}';document.head.append(pcss);
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('button,.pnl,[role=button]');if(!b||b.disabled)return;b.classList.remove('clkPulse');void b.offsetWidth;b.classList.add('clkPulse');setTimeout(()=>b.classList.remove('clkPulse'),200);},true);
function placeHint(){const h=$('#nHint'),ab=$('#nArenaBtn'),pb=$('#nPlay');ab.classList.remove('hintGlow');pb.classList.remove('hintGlow');
 const blocked=!$('#nHome').classList.contains('on')||$('#nArenaScr').classList.contains('on')||['#nNameScr','#nAvScr'].some(s=>$(s).style.display==='flex')||document.querySelector('.nScr.on');
 if(guide>=2||blocked){h.style.display='none';return;}
 const t=guide===0?ab:pb;t.classList.add('hintGlow');h.textContent=guide===0?'اول یک زمین انتخاب کن 👇':'حالا دکمهٔ بازی را بزن 👇';h.style.display='block';
 const r=t.getBoundingClientRect(),w=h.offsetWidth;h.style.left=Math.max(8,Math.min(innerWidth-w-8,r.left+r.width/2-w/2))+'px';h.style.top=(r.top-h.offsetHeight-18)+'px';}
setInterval(placeHint,400);addEventListener('resize',placeHint);
/* ---------- جادهٔ جام: هر ۵۰ جام یک سطح ---------- */
document.body.insertAdjacentHTML('beforeend','<div class="nScr" id="nRoad"><button class="nX" id="nRoadX" aria-label="بستن">✕</button><h1>جادهٔ جام</h1><div class="sub">با جام بیشتر به سطح‌های بالاتر برس</div><div id="nRoadW"><div id="nRoadRow"></div></div></div><div class="nScr" id="nRobScr"><button class="nX" id="nRobX" aria-label="بستن">✕</button><h1 id="nRobH"></h1><div class="sub" id="nRobSub"></div><div id="nRobGrid"></div><div id="nRobDet" style="display:none"></div></div>');
document.body.insertAdjacentHTML('beforeend','<div id="nAvScr" style="position:fixed;inset:0;z-index:10;display:none;align-items:center;justify-content:center;background:rgba(4,6,13,.92);font-family:Vazirmatn,Tahoma,sans-serif;direction:rtl"><div class="box" style="width:min(430px,calc(100% - 28px));background:rgba(10,18,34,.97);border:1px solid var(--line);border-radius:22px;padding:24px;text-align:center;color:var(--txt)"><h2 style="font-size:23px;margin-bottom:16px">تصویر خودت را انتخاب کن</h2><div class="avG" id="nAvG"></div><button class="nb g" id="nAvGo" style="width:100%;padding:13px;font-size:18px">تأیید</button></div></div>');
const ROAD_N=14,TIER=['🥉','🥈','🥇','💎','👑'];
function openRoad(){const tr=H.tr-(H.pend||0),lv=lvlOf(tr),row=$('#nRoadRow');row.innerHTML='';
 for(let i=0;i<ROAD_N;i++){const thr=i*50,n=i+1,it=document.createElement('div'),done=tr>=thr,isNext=n===lv+1;it.className='rdI';
  const pct=tr>=thr+50?100:tr>thr?(tr-thr)/50*100:0;
  it.innerHTML=(isNext?'<div class="rdNext">هدف بعدی</div>':'')+'<div class="rdC'+(done?' done':' lock')+(isNext?' next':'')+'"><div class="ci">'+(done?TIER[Math.min(4,i>>1)]:'🔒')+'</div><b>سطح '+faNum(n)+'</b><i>'+faNum(thr)+' جام</i></div><div class="rdTrack"><i style="width:'+pct+'%"></i><div class="rdHex'+(done?'':' lock')+'">'+faNum(n)+'</div><div class="rdT">'+faNum(thr)+'</div>'+(n===lv?'<div class="rdMe" style="left:'+((tr-thr)/50*190)+'px">🏆 '+faNum(tr)+'</div>':'')+'</div>';
  row.append(it);}
 $('#nRoad').classList.add('on');$('#nRoadW').scrollLeft=Math.max(0,(lv-2)*190);}
$('#nTrP').onclick=openRoad;$('#nRoadX').onclick=()=>$('#nRoad').classList.remove('on');
/* ---------- ربات‌ها: ربات‌های خودم + کارت ساخت ربات جدید؛ با زدن روی ربات صفحهٔ جزئیات ---------- */
let detI=-1;
function openRobots(){detI=-1;$('#nRobDet').style.display='none';$('#nRobScr').classList.remove('det');const g=$('#nRobGrid');g.style.display='';g.innerHTML='';
 H.robots.forEach((r,i)=>{const c=document.createElement('div');c.className='rbC';
  c.innerHTML='<canvas width="300" height="300"></canvas><div class="rn"></div>'+(i===H.sel?'<span class="cur">در بازی ✓</span>':'');c.querySelector('.rn').textContent=r.n;
  try{drawBot(c.querySelector('canvas'),r.c,5.6);}catch(e){}
  c.onclick=()=>openDetail(i);g.append(c);});
 if(H.robots.length<8){const a=document.createElement('div');a.className='rbC add';a.textContent='+';a.setAttribute('role','button');a.setAttribute('aria-label','ساخت ربات جدید');a.onclick=()=>{if(H.robots.length>=8)return;const used=new Set(H.robots.map(r=>r.c)),col=(SKINS.find(s=>!used.has(s[0]))||SKINS[0])[0];H.robots.push({n:'ربات '+faNum(H.robots.length+1),c:col});save();refreshHome();openDetail(H.robots.length-1);};g.append(a);}
 $('#nRobH').textContent='ربات‌های من';$('#nRobSub').textContent='روی ربات بزن تا جزئیاتش را ببینی';$('#nRobScr').classList.add('on');}
function openDetail(i){detI=i;const r=H.robots[i],d=$('#nRobDet'),tr=H.tr-(H.pend||0),lv=lvlOf(tr);$('#nRobGrid').style.display='none';d.style.display='block';$('#nRobScr').classList.add('det');
 d.innerHTML='<button class="bk" aria-label="بازگشت">←</button><div class="ban"><b id="nRdT"></b><i>ربات من</i></div><div class="inf"><div class="trb"><span>🏆</span><span>'+faNum(tr)+'</span></div><p>رباتی که خودت می‌سازی. با نوشتن قانون به آن یاد می‌دهی چطور حرکت و شلیک کند.</p></div><div class="stg"><canvas width="640" height="640"></canvas></div>'+
 '<div class="rp"><h3><span class="lvb">'+faNum(lv)+'</span><span>سطح</span><span class="bar"><i style="width:'+(tr%50)/50*100+'%"></i></span></h3><div class="row"><span class="ri">🏆</span>جام<em>'+faNum(tr)+'</em></div><div class="row"><span class="ri">⭐</span>سطح بعدی<em>'+faNum(lv*50)+'</em></div><div class="row"><span class="ri">📜</span>قانون‌ها<em>'+faNum(Array.isArray(rules)&&H.sel===i?rules.length:0)+'</em></div></div>'+
 '<div class="pop" id="nRdP"></div><div class="btm"><div class="ib"><button id="nRdE" aria-label="تغییر نام">✏️</button><button id="nRdK" aria-label="تغییر رنگ">🎨</button><button id="nRdX" aria-label="حذف">🗑</button></div><button class="sel" id="nRdSel"></button></div>';
 const cv=d.querySelector('canvas'),pop=d.querySelector('#nRdP'),tt=d.querySelector('#nRdT');tt.textContent=r.n;
 const paint=()=>{try{drawBot(cv,r.c,12);}catch(e){}};paint();
 d.querySelector('.bk').onclick=openRobots;
 const show=(btn,fill)=>{const on=btn.classList.contains('on');d.querySelectorAll('.ib button').forEach(x=>x.classList.remove('on'));pop.classList.remove('on');if(on)return;btn.classList.add('on');pop.innerHTML='';fill();pop.classList.add('on');};
 d.querySelector('#nRdE').onclick=e=>show(e.currentTarget,()=>{const inp=document.createElement('input');inp.maxLength=16;inp.value=r.n;inp.oninput=()=>{r.n=inp.value.trim().slice(0,16)||'ربات';tt.textContent=r.n;save();};pop.append(inp);setTimeout(()=>inp.focus(),30);});
 d.querySelector('#nRdK').onclick=e=>show(e.currentTarget,()=>{const sw=document.createElement('div');sw.className='sw';SKINS.forEach(([col])=>{const x=document.createElement('i');x.style.background=col;if(col===r.c)x.className='on';x.onclick=()=>{r.c=col;if(i===H.sel)H.color=col;save();refreshHome();sw.querySelectorAll('i').forEach(y=>y.classList.remove('on'));x.classList.add('on');paint();};sw.append(x);});pop.append(sw);});
 const db=d.querySelector('#nRdX');if(H.robots.length<2)db.style.display='none';
 db.onclick=e=>show(e.currentTarget,()=>{const b=document.createElement('button');b.className='nb r';b.style.cssText='width:100%;padding:11px;font-size:17px';b.textContent='حذف این ربات؟ (غیرقابل بازگشت)';b.onclick=()=>{H.robots.splice(i,1);if(H.sel>=H.robots.length)H.sel=0;else if(H.sel>i)H.sel--;H.color=H.robots[H.sel].c;save();refreshHome();openRobots();};pop.append(b);});
 const sb=d.querySelector('#nRdSel'),lab=()=>{sb.textContent=i===H.sel?'انتخاب‌شده ✓':'انتخاب';sb.disabled=i===H.sel;};lab();
 sb.onclick=()=>{H.sel=i;H.color=r.c;save();refreshHome();lab();toast('این ربات وارد بازی می‌شود');};}
$('#nRobBtn').onclick=openRobots;
$('#nRobX').onclick=()=>{if(detI>=0)openRobots();else $('#nRobScr').classList.remove('on');};
/* انتخاب تصویر پروفایل */
function pickAvatar(after){const g=$('#nAvG'),scr=$('#nAvScr');let cur=H.av%AVS.length;g.innerHTML='';
 AVS.forEach((a,i)=>{const e=document.createElement('i');paintAv(e,i);if(i===cur)e.className='on';e.onclick=()=>{cur=i;g.querySelectorAll('i').forEach(x=>x.classList.remove('on'));e.classList.add('on');};g.append(e);});
 scr.style.display='flex';$('#nAvGo').onclick=()=>{H.av=cur;save();scr.style.display='none';refreshHome();if(after)after();};}
$('#nPAv').onclick=()=>pickAvatar();
$('#nArBack').onclick=()=>$('#nArenaScr').classList.remove('on');

/* ---------- شروع ---------- */
refreshHome();show('lobby');
/* اولین ورود: صفحهٔ نام، بعد مرحلهٔ الماس */
function askName(){const s=$('#nNameScr'),i=$('#nNameIn');s.style.display='flex';setTimeout(()=>i.focus(),50);
 const go=()=>{const v=i.value.replace(/\s+/g,' ').trim().slice(0,16);if(!v){i.focus();toast('نامت را بنویس');return;}
  H.name=v;H.named=1;save();s.style.display='none';refreshHome();syncServerProfile();pickAvatar(()=>startMission(0));};
 $('#nNameGo').onclick=go;i.onkeydown=e=>{if(e.key==='Enter')go();};}
if(!H.named&&H.done===0)setTimeout(askName,300);
/* سرور (sim-host) همین توابع را صدا می‌زند تا منطق بازی دقیقاً همان باشد */

})();
