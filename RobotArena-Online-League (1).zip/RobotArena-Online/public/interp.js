'use strict';
/* درون‌یابی snapshotهای سرور (۱۵ در ثانیه) برای نمایش نرم. توابع خالص؛ هم در مرورگر (window.Interp) و هم در Node (تست). */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.Interp=factory();})(typeof self!=='undefined'?self:this,function(){
const TICK_MS=1000/60,TWO_PI=Math.PI*2;
const lerp=(a,b,u)=>a+(b-a)*u;
/* کوتاه‌ترین مسیر چرخش: از ۳۵۹° به ۱° نباید یک دور کامل برگردد */
const lerpAngle=(a,b,u)=>{const d=((b-a+Math.PI)%TWO_PI+TWO_PI)%TWO_PI-Math.PI;return a+d*u;};

/* ساعت: زمان محلی ← تیک سرور. نمونه‌ای که زودتر رسیده دقیق‌تر است (تأخیر شبکه فقط اضافه می‌کند)،
   پس کمینه را فوری می‌پذیریم و نمونه‌های دیرتر را آهسته جذب می‌کنیم. */
function createClock(){
 let off=null;
 return{
  observe(tick,nowMs){const s=nowMs-tick*TICK_MS;if(off===null||s<off)off=s;else off+=(s-off)*.02;},
  tickAt(nowMs){return off===null?0:(nowMs-off)/TICK_MS;},
  get ready(){return off!==null;}};
}

/* buf: snapshotها به ترتیب t صعودی. خروجی: وضعیت ربات‌ها در لحظهٔ tick (اعشاری) */
function sample(buf,tick,maxExtrap){
 maxExtrap=maxExtrap===undefined?6:maxExtrap;
 if(!buf.length)return null;
 const first=buf[0],last=buf[buf.length-1];
 let a,b,u;
 if(tick<=first.t){a=b=first;u=0;}
 else if(tick>=last.t){a=buf.length>1?buf[buf.length-2]:last;b=last;u=a===b?1:1+Math.min(tick-last.t,maxExtrap)/(b.t-a.t);}
 else{let i=buf.length-1;while(buf[i-1].t>tick)i--;a=buf[i-1];b=buf[i];u=(tick-a.t)/(b.t-a.t);}
 const dt=b.t-a.t||1,ext=u>1;
 const robots=b.r.map((rb,i)=>{
  const ra=a.r[i]||rb,vx=(rb[1]-ra[1])/dt,vy=(rb[2]-ra[2])/dt;
  const alive=ext?rb[8]:(u>=.5?rb[8]:ra[8]);
  return{id:rb[0],x:lerp(ra[1],rb[1],u),y:lerp(ra[2],rb[2],u),angle:lerpAngle(ra[3]/100,rb[3]/100,Math.min(u,1)),bodyAng:lerpAngle(ra[4]/100,rb[4]/100,Math.min(u,1)),
   hp:lerp(ra[5],rb[5],Math.min(u,1)),maxHp:rb[6],cubes:rb[7],alive:!!alive,vx,vy};});
 const chests=b.c.map((cb,i)=>{const ca=a.c[i]||cb;return{id:cb[0],alive:!!(u>=.5?cb[1]:ca[1]),hp:lerp(ca[2],cb[2],Math.min(u,1))};});
 return{t:tick,k:b.k,left:b.left,robots,chests};
}
/* snapshotهای قدیمی را دور می‌ریزد ولی همیشه یکی قبل از tick را نگه می‌دارد */
function prune(buf,tick){while(buf.length>2&&buf[1].t<=tick)buf.shift();return buf;}
return{TICK_MS,lerp,lerpAngle,createClock,sample,prune};
});
