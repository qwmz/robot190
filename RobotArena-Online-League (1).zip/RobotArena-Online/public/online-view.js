'use strict';
/* نمایش زمین آنلاین: همهٔ محاسبات روی سرور است. این فایل فقط
   ۱) برنامهٔ ربات را قبل از بازی به سرور می‌فرستد،
   ۲) snapshotهای ۱۵ در ثانیه را می‌گیرد و بین آن‌ها درون‌یابی می‌کند (interp.js)،
   ۳) از رخدادهای سرور انفجار، ذره، صدا و متن شناور می‌سازد،
   و با همان render/drawRobot بازی (روی یک battle نمایشی) رسم می‌کند. هیچ منطق بازی اینجا نیست. */
(function(){
const DELAY_TICKS=6;/* نمایش ۱۰۰ms عقب‌تر از سرور تا همیشه دو snapshot در دست باشد */
const FRAME_MS=1000/60;
let V=null,installed=false;

/* حلقهٔ k ام زون (همان زمین‌ساز سرور: engine/royale.js zoneRects) */
function zoneRects(k,W,H){const a=k===1?0:50*k,b=50*(k+1),T=b-a;
 return[{x:a,y:a,w:W-2*a,h:T},{x:a,y:H-b,w:W-2*a,h:T},{x:a,y:b,w:T,h:H-2*b},{x:W-b,y:b,w:T,h:H-2*b}];}

function newState(ctx){return{ctx,id:null,token:null,es:null,init:null,buf:[],evq:[],clock:Interp.createClock(),ents:[],robots:[],chests:[],
 bullets:new Map(),me:0,initTick:-1,queueTimer:0,k:0,kMax:26,myRank:0,matchFound:false,finished:false,rt:0,lastNow:0,pAcc:0,spec:null,proxy:null,cubesById:new Map(),ended:false};}

async function start(ctx){
 stop();
 const st=V=newState(ctx);
 let r;
 try{
  r=await fetch('api/arena/join',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({prog:ctx.program||undefined,name:ctx.name,color:ctx.color})});
  const j=await r.json();
  if(V!==st){if(r.ok&&j.id&&j.token){try{fetch('api/arena/leave',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:j.id,token:j.token}),keepalive:true});}catch(e){}}return;}
  if(!r.ok){ctx.onFail(j.error||'اتصال به سرور ممکن نشد');return;}
  st.id=j.id;st.token=j.token;
 }catch(e){if(V===st)ctx.onFail('اتصال به سرور ممکن نشد');return;}
 install();
 const es=st.es=new EventSource('api/arena/stream?id='+encodeURIComponent(st.id)+'&token='+encodeURIComponent(st.token));
 es.addEventListener('matchfound',e=>{if(V===st){st.matchFound=true;const info=JSON.parse(e.data);if(ctx.onMatchFound)ctx.onMatchFound(info);}});
 es.addEventListener('init',e=>{if(V===st)onInit(JSON.parse(e.data));});
 es.addEventListener('s',e=>{if(V===st)onSnap(JSON.parse(e.data));});
 es.addEventListener('queue',e=>{if(V===st&&!st.init)onQueue(JSON.parse(e.data));});
 es.addEventListener('result',e=>{if(V===st)st.result=JSON.parse(e.data);});/* جامِ حساب‌شدهٔ سرور */
 es.addEventListener('end',e=>{if(V===st)onEnd(JSON.parse(e.data));});
 es.onerror=()=>{if(V!==st||st.ended)return;if(es.readyState===EventSource.CLOSED){st.es=null;ctx.onFail('اتصال با سرور قطع شد');}};
}

function stop(){
 const st=V;V=null;
 if(!st)return;
 if(st.es)st.es.close();
 clearInterval(st.queueTimer);
 if(st.id&&!st.finished&&!st.ended){try{fetch('api/arena/leave',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:st.id,token:st.token}),keepalive:true});}catch(e){}}
}

function onInit(init){
 const B=battle;
 V.init=init;V.buf=[];V.evq=[];V.bullets.clear();V.cubesById.clear();
 ARENA.w=init.w;ARENA.h=init.h;V.kMax=init.kMax;
 B.obstacles=init.obstacles.map(o=>({...o}));B.floor=null;B.nav=null;B.decals=[];B.particles=[];B.floats=[];B.bullets=[];B.cubes=[];B.gem=null;B.allied=false;
 B.royaleOnline=true;B.over=false;B.max=1e9;
 for(const q of init.cubes){const c={id:q.id,x:q.x,y:q.y};B.cubes.push(c);V.cubesById.set(c.id,c);}
 V.robots=init.robots.map(r=>({id:r.id,kind:'bot',name:r.name,color:r.color,r:r.r,x:0,y:0,angle:0,bodyAng:0,hp:100,maxHp:100,alive:true,cubes:0,spd:0,tread:0,flash:0,recoil:0,nobar:false}));
 V.chests=init.chests.map(c=>({id:c.id,kind:'walker',chest:true,name:'صندوق',color:'#f5b43a',r:c.r,x:c.x,y:c.y,angle:Math.PI/2,hp:120,maxHp:120,alive:true,flash:0}));
 V.ents=[...V.robots,...V.chests];
 V.k=init.snapshot.k;
 const s=init.snapshot;V.buf.push(s);V.clock.observe(s.t,performance.now());
 apply(Interp.sample(V.buf,s.t),0);
 V.me=init.you||0;V.initTick=s.t;V.queueTimer&&clearInterval(V.queueTimer);
 const me=V.robots[V.me];B.player=me;camera.x=me.x;camera.y=me.y;
 V.rt=s.t-DELAY_TICKS;V.lastNow=0;
 S.TS=0;/* موتور محلی هیچ تیکی نمی‌زند */
}
/* انتظار در صف: «n از ۱۰ · شروع تا s ثانیه» با شمارندهٔ محلی */
function onQueue(q){
 const st=V,until=performance.now()+q.leftMs;
 const paint=()=>{if(V!==st||st.init)return clearInterval(st.queueTimer);
  const s=Math.max(0,Math.ceil((until-performance.now())/1000));
  const message='در صف لیگ: '+faNum(q.n)+' نفر · رتبهٔ فعلی '+(q.rank?faNum(q.rank):'—')+' · بازشدن محدوده در '+faNum(s)+' ثانیه';
  $('#nDps').textContent=message;if(st.ctx.onQueue)st.ctx.onQueue(q,message);};
 clearInterval(st.queueTimer);paint();st.queueTimer=setInterval(paint,250);
}
function onSnap(s){
 V.clock.observe(s.t,performance.now());
 const ev=s.ev;delete s.ev;
 V.buf.push(s);
 /* بعد از اتصال مجدد، رخدادهایی که پیش از وضعیت تازه رخ داده‌اند تکراری‌اند */
 for(const e of ev)if(e[1]>V.initTick)V.evq.push(e);
}
function onEnd(d){
 V.ended=true;if(d.result&&!V.result)V.result=d.result;
 if(V.es){V.es.close();V.es=null;}
 /* اگر رخداد رتبه هنوز در صف نمایش است کمی صبر می‌کنیم؛ وگرنه از پاسخ پایانی می‌خوانیم */
 setTimeout(()=>{if(!V||V.finished)return;
  const rk=d.ranks&&d.ranks[V.me];
  if(rk||d.result)finish(rk||d.result.rank);else if(d.aborted)V.ctx.onFail('مسابقه قطع شد');},2500);
}
/* صفحهٔ پایان باید جام سرور را داشته باشد؛ تا ۳ ثانیه منتظرش می‌مانیم */
function finishWhenReady(rank,tries){
 const st=V;if(!st||st.finished)return;
 if(st.result||tries>=30)return finish(rank);
 setTimeout(()=>finishWhenReady(rank,tries+1),100);}
function finish(rank){
 const st=V;if(!st||st.finished)return;
 st.finished=true;
 if(st.es){st.es.close();st.es=null;}
 if(!st.ended&&st.id){try{fetch('api/arena/leave',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:st.id,token:st.token}),keepalive:true});}catch(e){}}
 st.ctx.onEnd(rank,st.result||null);
}

/* ---------- اعمال وضعیت درون‌یابی‌شده روی اشیای نمایشی ---------- */
function apply(sm,dtTicks){
 if(!sm)return;
 sm.robots.forEach((s,i)=>{const r=V.robots[i];if(!r)return;
  r.x=s.x;r.y=s.y;r.angle=s.angle;r.bodyAng=s.bodyAng;r.hp=s.hp;r.maxHp=s.maxHp;r.cubes=s.cubes;r.alive=s.alive;
  r.spd=Math.hypot(s.vx,s.vy);r.tread+=r.spd*dtTicks;});
 sm.chests.forEach((s,i)=>{const c=V.chests[i];if(!c)return;c.alive=s.alive;c.hp=s.hp;});
 V.k=Math.max(V.k,sm.k);V.left=sm.left;
}

/* ---------- رخدادها ← جلوه‌ها ---------- */
function fl(x,y,txt,col){battle.floats.push({x,y,t:40,txt,col});}
function onEvent(e){
 const B=battle,ME=V.me,T=e[1];
 switch(e[0]){
  case 'shot':{const o=V.ents[e[3]];V.bullets.set(e[2],{x0:e[4],y0:e[5],vx:e[6],vy:e[7],t0:T,color:o&&o.id===ME?'#22d3ee':(o?o.color:'#fde68a')});
   if(o){o.recoil=5;for(let i=0;i<5;i++){const a=Math.atan2(e[7],e[6])+(Math.random()-.5),s=1+Math.random()*3;B.particles.push({x:o.x+Math.cos(a)*o.r,y:o.y+Math.sin(a)*o.r,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:6+Math.random()*8,max:14,color:'#fde68a',size:1.5+Math.random()*1.5});}}
   if(e[3]===ME)sfx(700,.06,'square',.025);break;}
  case 'bdie':{V.bullets.delete(e[2]);if(e[5]!=='life')spark(e[3],e[4],e[5]==='hit'?'#fde68a':'#94a3b8',e[5]==='hit'?7:4);break;}
  case 'hit':{const t=V.ents[e[2]];if(!t)break;t.flash=6;fl(t.x+(Math.random()-.5)*16,t.y-26,'-'+e[3],e[2]===ME?'#f87171':'#fde68a');
   if(e[2]===ME){B.shake=10;B.hitFlash=1;sfx(120,.2,'sawtooth',.06);}else if(e[4]===ME)sfx(520,.08,'triangle',.05);break;}
  case 'die':{const t=V.ents[e[2]];const x=e[4],y=e[5];boom(x,y,t?t.color:'#fde68a',t&&t.chest?24:50);
   if(t&&!t.chest){B.decals.push({x,y,r:34+Math.random()*16});if(B.decals.length>30)B.decals.shift();}
   if(e[2]===ME)B.shake=14;sfx(t&&t.chest?660:90,t&&t.chest?.25:.5,t&&t.chest?'triangle':'sawtooth',.07);break;}
  case 'heal':{const t=V.ents[e[2]];if(t)fl(t.x,t.y-30,'+'+faNum(e[3])+' ♥','#4ade80');break;}
  case 'cube':{const c={id:e[2],x:e[3],y:e[4]};B.cubes.push(c);V.cubesById.set(c.id,c);break;}
  case 'pick':{const c=V.cubesById.get(e[3]),t=V.ents[e[2]];
   if(c){B.cubes=B.cubes.filter(q=>q!==c);V.cubesById.delete(c.id);boom(c.x,c.y,'#86efac',8);}
   if(t)fl(t.x,t.y-30,'+۱ انرژی','#86efac');if(e[2]===ME)sfx(740,.12,'triangle',.05);break;}
  case 'zone':{const k=e[2];V.k=Math.max(V.k,k);
   if(!B.obstacles.some(o=>o.zone===k)){for(const r of zoneRects(k,ARENA.w,ARENA.h))B.obstacles.push({...r,type:'wall',zone:k});}
   const b=50*(k+1),cl=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));/* سرور انرژی‌های بیرون را به داخل می‌رانَد؛ همان قاعده */
   for(const q of B.cubes){q.x=cl(q.x,b+20,ARENA.w-b-20);q.y=cl(q.y,b+20,ARENA.h-b-20);}break;}
  case 'obs_del':{const i=B.obstacles.findIndex(o=>o.id===e[2]);if(i>=0)B.obstacles.splice(i,1);break;}
  case 'spark':spark(e[2],e[3],e[4]?'#d6a86a':'#fbbf24',4);break;
  case 'rank':{if(e[2]===ME&&!V.myRank){V.myRank=Number.isFinite(e[4])?e[4]:e[3];const rank=V.myRank,st=V;setTimeout(()=>{if(V===st)finishWhenReady(rank,0);},rank===1?900:1300);}break;}
 }
}

/* ---------- هر فریم رسم (قبل از render اصلی) ---------- */
function frame(){
 if(!V||!V.init||!battle)return;
 const now=performance.now(),B=battle;
 if(!V.lastNow)V.lastNow=now;
 const dtMs=Math.min(100,now-V.lastNow);V.lastNow=now;
 const prevRt=V.rt;
 V.rt=Math.max(prevRt,V.clock.tickAt(now)-DELAY_TICKS);
 const rt=V.rt,dtTicks=Math.min(3,Math.max(0,rt-prevRt));
 apply(Interp.sample(V.buf,rt),dtTicks);
 Interp.prune(V.buf,rt);
 while(V.evq.length&&V.evq[0][1]<=rt)onEvent(V.evq.shift());
 /* گلوله‌ها: موقعیت = مبدأ + سرعت × (زمان - لحظهٔ شلیک) */
 B.bullets=[];
 for(const[id,b]of V.bullets){const dt=rt-b.t0;if(dt>120){V.bullets.delete(id);continue;}B.bullets.push({x:b.x0+b.vx*dt,y:b.y0+b.vy*dt,vx:b.vx,vy:b.vy,color:b.color});}
 /* ذره‌ها، متن‌های شناور و فلش‌ها با نرخ ثابت ۶۰Hz */
 V.pAcc+=dtMs;let n=0;while(V.pAcc>=FRAME_MS&&n++<5){V.pAcc-=FRAME_MS;updateParticles();updateFx();}
 if(V.pAcc>FRAME_MS*5)V.pAcc=0;
 B.tick=Math.floor(rt);
 /* فقط زنده‌ها کشیده می‌شوند */
 const me=V.robots[V.me];
 B.enemies=[...V.robots.filter(r=>r!==me&&r.alive),...V.chests.filter(c=>c.alive)];
 if(me.alive){B.player=me;V.spec=null;}
 else{/* تماشا: دوربین به نزدیک‌ترین ربات زنده می‌رود */
  if(!V.spec||!V.spec.alive){let best=null,bd=1e9;for(const r of V.robots)if(r.alive){const d=Math.hypot(r.x-me.x,r.y-me.y);if(d<bd){bd=d;best=r;}}V.spec=best;}
  const t=V.spec||me,p=V.proxy||(V.proxy={});
  Object.assign(p,{x:t.x,y:t.y,angle:t.angle,bodyAng:t.bodyAng,hp:t.alive?t.hp:0,maxHp:t.maxHp,r:17,color:t.color,name:t.name,cubes:t.cubes,alive:false,spd:0,tread:0,flash:0,recoil:0,nobar:true});
  B.player=p;}
 const left=V.left===undefined?10:V.left,zt=ZONE_TICKS_UI();
 const nz=V.k<V.kMax?' · زون بعدی: '+faNum(Math.max(0,Math.ceil((zt-rt%zt)/60))):'';
 $('#nDps').textContent='زنده: '+faNum(left)+' از ۱۰ · انرژی: '+faNum(me.cubes||0)+nz;
}
const ZONE_TICKS_UI=()=>V&&V.init?V.init.zoneTicks:420;

/* ---------- نصب یک‌بارهٔ قلاب‌ها روی توابع سراسری بازی ---------- */
function install(){
 if(installed)return;installed=true;
 const _render=window.render;
 window.render=function(){try{frame();}catch(e){console.error(e);}return _render.apply(this,arguments);};
 const _df=window.drawFloats;
 window.drawFloats=function(c){
  if(V&&V.init&&battle&&battle.royaleOnline){/* حاشیهٔ زون */
   const W=ARENA.w,Hh=ARENA.h,k=V.k,d=k?50*(k+1):0,dn=50*(Math.min(V.kMax,k+1)+1);
   c.save();if(d){c.fillStyle='rgba(220,38,38,.30)';c.beginPath();c.rect(0,0,W,Hh);c.rect(d,d,W-2*d,Hh-2*d);c.fill('evenodd');c.strokeStyle='#ef4444';c.lineWidth=4;c.strokeRect(d,d,W-2*d,Hh-2*d);}
   if(k<V.kMax||!d){c.setLineDash([18,14]);c.strokeStyle='rgba(250,204,21,.8)';c.lineWidth=3;c.strokeRect(dn,dn,W-2*dn,Hh-2*dn);}c.restore();}
  return _df.apply(this,arguments);};
}
window.OnlineView={start,stop,active:()=>!!V};
})();
