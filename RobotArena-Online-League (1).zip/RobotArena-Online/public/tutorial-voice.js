/* Local, prerecorded Persian narration. No TTS service is called during play. */
'use strict';
(function(){
 const audio=new Audio();audio.preload='auto';audio.volume=.92;
 let enabled=true,job=null,token=0,lastText='',state='idle',watchdog=0;
 try{enabled=localStorage.getItem('ra_tutorial_voice')!=='off';}catch{}
 const style=document.createElement('style');style.textContent=`
 #tutorialVoice{position:fixed;left:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:36;display:flex;flex-wrap:wrap;align-items:center;gap:6px;max-width:calc(100vw - 24px);padding:8px 10px;border:1px solid #34465b;border-radius:14px;background:rgba(10,18,34,.96);color:#dce7f7;direction:rtl;font:12px Vazirmatn,Tahoma,sans-serif;box-shadow:0 4px 18px #0005}
 #tutorialVoice[hidden]{display:none}#tutorialVoice button{font:inherit;color:inherit;background:#1b3048;border:1px solid #405771;border-radius:8px;padding:7px 10px;cursor:pointer}#tutorialVoice button:focus-visible{outline:2px solid #67e8f9;outline-offset:2px}#tutorialVoiceStatus{min-width:72px}#tutorialVoice[data-speaking=true] #tutorialVoiceStatus{color:#67e8f9}
 @media(max-width:480px){#tutorialVoice{left:8px;bottom:8px;font-size:11px;padding:6px;gap:4px}}
 `;document.head.append(style);
 const bar=document.createElement('div');bar.id='tutorialVoice';bar.hidden=true;
 bar.setAttribute('aria-label','راهنمای صوتی آموزش');
 bar.innerHTML='<span id="tutorialVoiceStatus" role="status" aria-live="polite" title="صدای فارسی تولیدشده با هوش مصنوعی">راهنمای صوتی</span><button type="button" id="tutorialVoiceReplay">تکرار صدا</button><button type="button" id="tutorialVoiceToggle"></button>';
 /* کنترل صدا روی صفحه نمایش داده نمی‌شود؛ بار فقط در حافظه می‌ماند تا منطق پخش کار کند */
 const status=bar.querySelector('#tutorialVoiceStatus'),toggle=bar.querySelector('#tutorialVoiceToggle'),replay=bar.querySelector('#tutorialVoiceReplay');
 function render(){
  toggle.textContent=enabled?'قطع صدا':'وصل صدا';toggle.setAttribute('aria-pressed',String(enabled));
  replay.disabled=!lastText;bar.dataset.speaking=String(state==='playing');
  status.textContent=!enabled?'صدا خاموش':({playing:'در حال پخش…',blocked:'برای پخش، تکرار را بزن',error:'صدا بارگیری نشد',paused:'صدا متوقف است',loading:'آماده‌سازی صدا…'}[state]||'راهنمای صوتی');
 }
 function stopMedia(){token++;clearTimeout(watchdog);audio.onended=audio.onerror=audio.onplaying=null;audio.pause();try{audio.currentTime=0;}catch{}}
 function finish(result){clearTimeout(watchdog);const pending=job;job=null;if(pending)pending.resolve(result);}
 function stop(){stopMedia();finish('cancelled');state='idle';render();}
 function play(text){
  stopMedia();const clip=window.TUTORIAL_CLIPS[text],id=token;
  if(!clip){state='error';render();finish('error');return;}
  audio.src=clip.file;state='loading';render();
  const fail=reason=>{if(id!==token)return;stopMedia();state=reason;render();finish(reason);};
  audio.onended=()=>{if(id!==token)return;state='idle';render();finish('ended');};
  audio.onerror=()=>fail('error');
  audio.onplaying=()=>{if(id!==token)return;clearTimeout(watchdog);watchdog=setTimeout(()=>fail('error'),Math.max(10000,(clip.duration-audio.currentTime)*1000+10000));state='playing';render();};
  // A network failure must never prevent the lesson from advancing.
  watchdog=setTimeout(()=>fail('error'),15000);
  if(document.hidden){clearTimeout(watchdog);state='paused';render();return;}
  audio.play().catch(e=>fail(e.name==='NotAllowedError'?'blocked':'error'));
 }
 function say(text){
  stop();lastText=text;bar.hidden=false;
  if(!enabled){render();return Promise.resolve('muted');}
  return new Promise(resolve=>{job={resolve};play(text);});
 }
 replay.onclick=()=>{if(!lastText)return;if(!enabled){enabled=true;try{localStorage.setItem('ra_tutorial_voice','on');}catch{}}play(lastText);};
 toggle.onclick=()=>{enabled=!enabled;try{localStorage.setItem('ra_tutorial_voice',enabled?'on':'off');}catch{}
  if(enabled&&lastText)play(lastText);else{stopMedia();finish('muted');state='idle';render();}
 };
 document.addEventListener('visibilitychange',()=>{
  if(document.hidden){if(state==='playing'||state==='loading'){audio.pause();clearTimeout(watchdog);state='paused';render();}}
  else if(state==='paused'&&enabled){const id=token;audio.play().catch(()=>{if(id!==token)return;state='blocked';render();finish('blocked');});}
 });
 window.addEventListener('pagehide',stop);
 window.TutorialVoice={say,stop,hide(){stop();bar.hidden=true;lastText='';},get speaking(){return state==='playing';}};
 render();
})();
