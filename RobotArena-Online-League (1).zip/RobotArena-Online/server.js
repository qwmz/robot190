'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const ai=require('./ai');
const aiProgram=require('./ai-program');
const crypto=require('node:crypto');
const{createMatchManager}=require('./server/matches');
const{createPlayerStore}=require('./server/players');
function createServer(options={}){
 const aiRates=new Map();
 const players=options.players||createPlayerStore(options.playersFile||path.join(__dirname,'data','players.json'));
 const arena=createMatchManager({layoutsFile:options.layoutsFile,players,...(options.arena||{})});
 /* هویت مهمان: کوکی HttpOnly با توکن تصادفی؛ بدون آن، یکی ساخته و روی پاسخ گذاشته می‌شود. خروجی: کلید ذخیره (هش توکن) */
 const guestKey=(req,res)=>{
  const m=/(?:^|;\s*)ra_guest=([0-9a-f]{32})(?:;|$)/.exec(req.headers.cookie||'');let tok=m&&m[1];
  if(!tok){tok=crypto.randomBytes(16).toString('hex');res.setHeader('Set-Cookie','ra_guest='+tok+'; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000'+(req.headers['x-forwarded-proto']==='https'?'; Secure':''));}
  return players.keyOf(tok);};
const layoutsFile=options.layoutsFile||path.join(__dirname,'data','layouts.json');
const interpret=options.interpret||ai.interpret,program=options.program||aiProgram.program,aiOn=()=>!!(options.interpret||options.program||process.env.ANTHROPIC_API_KEY);
 const publicDir=path.join(__dirname,'public');
 const send=(res,code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
 const server=http.createServer(async(req,res)=>{
  try{
   res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
   const url=new URL(req.url,'http://localhost');
   if(req.method==='GET'&&url.pathname==='/api/layouts'){let j={};try{j=JSON.parse(fs.readFileSync(layoutsFile,'utf8'));}catch{}return send(res,200,j);}
   if(req.method==='POST'&&url.pathname.startsWith('/api/')){
    if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)return send(res,403,{error:'مبدأ درخواست مجاز نیست'});
    if(!String(req.headers['content-type']).startsWith('application/json'))return send(res,415,{error:'JSON required'});
    const limit=url.pathname==='/api/layouts'?600000:16384;let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>limit){send(res,413,{error:'درخواست بیش از حد بزرگ است'});return;}}
    let data;try{data=JSON.parse(body);}catch{return send(res,400,{error:'JSON نامعتبر'});}if(!data||typeof data!=='object'||Array.isArray(data))return send(res,400,{error:'درخواست نامعتبر'});
    if(url.pathname==='/api/layouts'){
     if(!/^(::1|127\.0\.0\.1|::ffff:127\.0\.0\.1)$/.test(req.socket.remoteAddress||''))return send(res,403,{error:'ذخیرهٔ زمین فقط از روی همین کامپیوتر ممکن است'});
     const out={};for(const k of ['run','shoot','royale'])if(data[k]&&typeof data[k]==='object'&&!Array.isArray(data[k]))out[k]=data[k];
     fs.mkdirSync(path.dirname(layoutsFile),{recursive:true});fs.writeFileSync(layoutsFile+'.tmp',JSON.stringify(out));fs.renameSync(layoutsFile+'.tmp',layoutsFile);
     return send(res,200,{ok:true});
    }
    if(url.pathname==='/api/profile'){
     if(data.name!==undefined&&typeof data.name!=='string'||data.color!==undefined&&typeof data.color!=='string')return send(res,400,{error:'درخواست نامعتبر'});
     const profile=players.profile(guestKey(req,res),data.name,data.color);return send(res,200,profile);
    }
    if(url.pathname==='/api/arena/join'){
     if(data.name!==undefined&&typeof data.name!=='string'||data.color!==undefined&&typeof data.color!=='string')return send(res,400,{error:'درخواست نامعتبر'});
     const r=arena.join({prog:data.prog,name:data.name,color:data.color,ip:req.socket.remoteAddress,playerKey:guestKey(req,res)});
     return r.error?send(res,r.status,{error:r.error,details:r.details}):send(res,200,{id:r.id,token:r.token});
    }
    if(url.pathname==='/api/arena/leave'){
     const ok=arena.leave(String(data.id),data.token);return send(res,ok?200:404,{ok});
    }
    if(url.pathname==='/api/program'){
     if(!aiOn())return send(res,503,{error:'ai-disabled'});
     const ip=req.socket.remoteAddress,now=Date.now();let r=aiRates.get(ip);if(!r||now-r.start>60000){r={start:now,n:0};aiRates.set(ip,r);}if(++r.n>40)return send(res,429,{error:'کمی صبر کن و دوباره تلاش کن'});
     if(typeof data.t!=='string'||data.t.length>600)return send(res,400,{error:'درخواست نامعتبر'});
     try{return send(res,200,{r:await program(data.t,{tab:data.tab})});}catch(e){return send(res,502,{error:'ai-failed'});}
    }
    if(url.pathname==='/api/interpret'){
     if(!aiOn())return send(res,503,{error:'ai-disabled'});
     const ip=req.socket.remoteAddress,now=Date.now();let r=aiRates.get(ip);if(!r||now-r.start>60000){r={start:now,n:0};aiRates.set(ip,r);}if(++r.n>40)return send(res,429,{error:'کمی صبر کن و دوباره تلاش کن'});
     if(!data.s||typeof data.s!=='object'||Array.isArray(data.s)||!Object.keys(data.s).every(k=>Object.hasOwn(ai.SECTIONS,k)&&Array.isArray(data.s[k])&&data.s[k].every(x=>typeof x==='string')))return send(res,400,{error:'درخواست نامعتبر'});
     try{return send(res,200,{r:await interpret(data.s)});}catch(e){return send(res,502,{error:'ai-failed'});}
    }
    return send(res,404,{error:'مسیر یافت نشد'});
   }
   if(req.method==='GET'&&url.pathname==='/api/me')return send(res,200,players.get(guestKey(req,res)));
   if(req.method==='GET'&&url.pathname==='/api/leaderboard')return send(res,200,players.leaderboard(guestKey(req,res),10));
   if(req.method==='GET'&&url.pathname==='/api/arena/status')return send(res,200,arena.stats());
   if(req.method==='GET'&&url.pathname==='/api/arena/stream'){
    if(!arena.subscribe(url.searchParams.get('id'),url.searchParams.get('token'),res))return send(res,404,{error:'مسابقه یافت نشد'});
    return;
   }
   if(req.method==='GET'||req.method==='HEAD'){
    if(/^\/audio\/tutorial\/[a-z0-9-]+\.mp3$/.test(url.pathname)){
     const audioPath=path.join(publicDir,url.pathname.slice(1));
     let stat;try{stat=fs.statSync(audioPath);}catch{return send(res,404,{error:'یافت نشد'});}
     res.writeHead(200,{'Content-Type':'audio/mpeg','Content-Length':stat.size,'Cache-Control':'public, max-age=86400'});
     if(req.method==='HEAD')return res.end();
     const stream=fs.createReadStream(audioPath);stream.on('error',()=>res.destroy());stream.pipe(res);return;
    }
    const files={'/':'index.html','/index.html':'index.html','/home.js':'home.js','/tutorial-clips.js':'tutorial-clips.js','/tutorial-voice.js':'tutorial-voice.js','/behavior.js':'../behavior.js','/brain.js':'brain.js','/editor.html':'editor.html','/royale-map.js':'royale-map.js','/interp.js':'interp.js','/online-view.js':'online-view.js'};const name=files[url.pathname];
    if(!name)return send(res,404,{error:'یافت نشد'});
    res.writeHead(200,{'Content-Type':name.endsWith('.js')?'text/javascript; charset=utf-8':'text/html; charset=utf-8','Cache-Control':'no-store, must-revalidate'});
    if(req.method==='HEAD')return res.end();fs.createReadStream(path.join(publicDir,name)).pipe(res);return;
   }send(res,405,{error:'روش مجاز نیست'});
  }catch(e){if(!res.headersSent)send(res,400,{error:'درخواست نامعتبر'});else res.end();}
 });
 function stop(){server.close();server.closeAllConnections();arena.close();}
 return {server,stop};
}
/* فایل .env کنار server.js (خط‌های KEY=VALUE) خوانده می‌شود؛ متغیری که از قبل در محیط تنظیم شده باشد عوض نمی‌شود */
function loadEnv(file){let txt;try{txt=require('fs').readFileSync(file,'utf8');}catch{return;}
 for(const line of txt.split(/\r?\n/)){const m=line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);if(!m||line.trim().startsWith('#'))continue;
  let v=m[2];if(/^(['"]).*\1$/.test(v))v=v.slice(1,-1);if(v&&process.env[m[1]]===undefined)process.env[m[1]]=v;}}
if(require.main===module){loadEnv(require('path').join(__dirname,'.env'));const app=createServer();const port=Number(process.env.PORT)||3000;app.server.listen(port,process.env.HOST||'0.0.0.0',()=>console.log('RobotArena: http://localhost:'+port));for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>app.stop());}
module.exports={createServer};
