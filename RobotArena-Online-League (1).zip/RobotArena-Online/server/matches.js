'use strict';
/*
 * مدیر مسابقه‌ها و صف سراسری لیگ.
 * بازیکنان واقعی در گروه‌های ۷ تا ۱۰ نفره قرار می‌گیرند؛ موتور موجود باقیماندهٔ ظرفیت
 * هر زمین را با ربات‌های خاکستری هم‌قدرت تکمیل می‌کند.
 */
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const{Worker}=require('node:worker_threads');
const Behavior=require('../behavior');
const{planMatches,MIN_PLAYERS,MAX_PLAYERS,DEFAULT_RANK_WINDOW,DEFAULT_RELAX_AFTER_MS}=require('./matchmaking');

const DEFAULT_PROG=Behavior.compile({move:{k:'goto',to:'nearest'},target:{k:'pick',who:'nearest'},fire:{k:'fire',on:true,range:680}}).prog;
const HEARTBEAT_MS=15000, PENDING_MS=120000, KEEP_MS=30000, MAX_MATCH_MS=10*60*1000;
const same=(a,b)=>typeof a==='string'&&typeof b==='string'&&a.length===b.length&&crypto.timingSafeEqual(Buffer.from(a),Buffer.from(b));

function createMatchManager(opts={}){
 const speed=opts.speed||1,maxMatches=opts.maxMatches||20,joinRateLimit=opts.joinRateLimit||80,store=opts.players||null;
 const schedulerMs=opts.schedulerMs===undefined?(opts.queueMs===undefined?1000:Math.max(10,Math.min(1000,opts.queueMs))):Math.max(10,opts.schedulerMs);
 const idleMs=opts.idleMs||10000,rankWindow=opts.rankWindow===undefined?DEFAULT_RANK_WINDOW:opts.rankWindow;
 const relaxAfterMs=opts.relaxAfterMs===undefined?DEFAULT_RELAX_AFTER_MS:opts.relaxAfterMs;
 const layoutsFile=opts.layoutsFile||path.join(__dirname,'..','data','layouts.json');
 const nWorkers=opts.workers||Math.max(1,Math.min(4,os.cpus().length-1));
 const workers=[],load=[],tickets=new Map(),matches=new Map(),joinRates=new Map();
 let closed=false,scheduling=false;

 /* ---------- worker ها ---------- */
 function spawnWorker(i){
  const w=new Worker(path.join(__dirname,'worker.js'),{workerData:{speed}});
  w.on('message',onMessage);
  w.on('error',e=>console.error('worker',i,e));
  w.on('exit',()=>{if(closed)return;
   for(const M of[...matches.values()])if(M.worker===i)endMatch(M,null);
   load[i]=0;workers[i]=spawnWorker(i);});
  return w;
 }
 for(let i=0;i<nWorkers;i++){load[i]=0;workers[i]=spawnWorker(i);}

 /* ---------- SSE ---------- */
 const sse=(res,ev,data)=>{try{res.write('event: '+ev+'\ndata: '+JSON.stringify(data)+'\n\n');}catch{}};
 const toTicket=(T,ev,data)=>{for(const res of T.subs)sse(res,ev,data);};
 const toMatch=(M,ev,data)=>{for(const T of M.tickets)toTicket(T,ev,data);};
 const closeSubs=T=>{for(const res of T.subs)try{res.end();}catch{}T.subs.clear();};
 const initFor=(init,T)=>({...init,you:T.robotId});

 /* ---------- صف سراسری و وضعیت ---------- */
 const queued=()=>[...tickets.values()].filter(T=>T.state==='queued');
 const rankOf=T=>store&&T.playerKey?store.rankOf(T.playerKey):Number.MAX_SAFE_INTEGER;
 function queueInfo(T){
  const q=queued(),rank=rankOf(T);
  const ordered=q.slice().sort((a,b)=>rankOf(a)-rankOf(b)||(a.joinedAt-b.joinedAt)||a.id.localeCompare(b.id));
  return{n:q.length,max:MAX_PLAYERS,min:MIN_PLAYERS,position:ordered.indexOf(T)+1,waitMs:Math.max(0,Date.now()-T.joinedAt),leftMs:Math.max(0,T.joinedAt+relaxAfterMs-Date.now()),rank,matches:matches.size};
 }
 function sendQueue(){for(const T of queued())toTicket(T,'queue',queueInfo(T));}
 function loadLayout(){try{const j=JSON.parse(fs.readFileSync(layoutsFile,'utf8'));return j&&j.royale&&j.royale.cells?j.royale:undefined;}catch{return undefined;}}

 /* ---------- نتیجهٔ انسانی؛ ربات‌های تکمیل ظرفیت در جام اثر ندارند ---------- */
 function settle(T,rank){
  if(T.settled||!store||!T.playerKey||!(rank>=1&&rank<=MAX_PLAYERS))return;
  T.settled=store.settle(T.playerKey,rank);
  toTicket(T,'result',T.settled);
 }
 function retire(T,msg){
  if(T.state==='done')return;
  T.state='done';clearTimeout(T.timer);
  T.finalData={ranks:msg.ranks||{},tick:msg.tick||0,aborted:!!msg.aborted,result:T.settled};
  toTicket(T,'end',T.finalData);
  closeSubs(T);
  const t=setTimeout(()=>tickets.delete(T.id),KEEP_MS);t.unref();
 }

 /* ---------- پایان مسابقه ---------- */
 function endMatch(M,msg){
  if(M.over)return;
  M.over=true;clearTimeout(M.idle);
  load[M.worker]=Math.max(0,load[M.worker]-1);
  const publicRanks={};
  if(msg&&msg.ranks){
   const ordered=M.tickets.filter(T=>Number.isFinite(msg.ranks[T.robotId])).sort((a,b)=>msg.ranks[a.robotId]-msg.ranks[b.robotId]);
   let humanRank=0;
   for(const T of ordered){
    humanRank++;
    if(!T.settled)settle(T,humanRank);
    publicRanks[T.robotId]=T.settled?T.settled.rank:humanRank;
   }
  }
  for(const T of M.tickets){
   if(T.state==='done')continue;
   if(msg&&msg.ranks&&publicRanks[T.robotId]===undefined){
    const ordered=M.tickets.filter(x=>Number.isFinite(msg.ranks[x.robotId])).sort((a,b)=>msg.ranks[a.robotId]-msg.ranks[b.robotId]);
    const idx=ordered.indexOf(T);const fallback=idx>=0?idx+1:M.humanCount;
    if(!T.settled)settle(T,fallback);publicRanks[T.robotId]=T.settled?T.settled.rank:fallback;
   }
   retire(T,msg?{ranks:publicRanks,tick:msg.tick,aborted:!!msg.aborted}:{aborted:true});
  }
  matches.delete(M.id);
  sendQueue();runMatchmaking();
 }
 function stopMatch(M){
  if(M.over)return;
  workers[M.worker].postMessage({type:'stop',id:M.id});
  /* قطع کامل اتصال به معنی شکست قطعی نیست؛ نتیجهٔ این زمین لغو می‌شود و جام تغییر نمی‌کند. */
  endMatch(M,{ranks:{},aborted:true});
 }
 function checkIdle(M){
  if(M.over)return;
  const watching=M.tickets.some(T=>T.state!=='done'&&T.subs.size>0);
  if(watching){clearTimeout(M.idle);M.idle=null;return;}
  if(M.idle)return;
  M.idle=setTimeout(()=>{M.idle=null;stopMatch(M);},idleMs);M.idle.unref();
 }

 function onMessage(m){
  const M=matches.get(m.id);if(!M)return;
  if(m.type==='init'){M.init=m.init;for(const T of M.tickets)toTicket(T,'init',initFor(m.init,T));checkIdle(M);}
  else if(m.type==='state'){const T=tickets.get(m.req);if(T&&T.M===M)toTicket(T,'init',initFor(m.init,T));}
  else if(m.type==='snap'){
   for(const e of m.ev)if(e[0]==='rank'){
    const T=M.tickets.find(t=>t.robotId===e[2]);
    if(T&&T.state!=='done')settle(T,Number.isFinite(e[4])?e[4]:e[3]);
   }
   toMatch(M,'s',{...m.snap,ev:m.ev});
  }
  else if(m.type==='end')endMatch(M,m);
  else if(m.type==='error'){console.error('match error',m.error);endMatch(M,null);}
 }

 /* ---------- ساخت زمین‌های رتبه‌ای ---------- */
 function launchMatch(group){
  const ts=group.filter(T=>T.state==='queued');
  if(ts.length<MIN_PLAYERS||matches.size>=maxMatches)return false;
  const id=crypto.randomBytes(8).toString('hex'),w=load.indexOf(Math.min(...load));load[w]++;
  const M={id,worker:w,init:null,tickets:ts,idle:null,over:false,humanCount:ts.length};
  matches.set(id,M);
  ts.forEach((T,i)=>{T.state='running';T.M=M;T.robotId=i;clearTimeout(T.timer);T.lobby=null;});
  for(const T of ts)toTicket(T,'matchfound',{players:ts.length,bots:MAX_PLAYERS-ts.length,capacity:MAX_PLAYERS});
  workers[w].postMessage({type:'start',id,seed:crypto.randomBytes(4).readInt32LE(),layout:loadLayout(),
   players:ts.map(T=>({name:T.spec.name,color:T.spec.color,prog:T.spec.prog})),maxMs:MAX_MATCH_MS});
  return true;
 }
 function runMatchmaking(){
  if(closed||scheduling||matches.size>=maxMatches)return;
  scheduling=true;
  try{
   const active=queued();
   const groups=planMatches(active,rankOf,Date.now(),{minPlayers:MIN_PLAYERS,maxPlayers:MAX_PLAYERS,
    rankWindow,relaxAfterMs,maxGroups:maxMatches-matches.size});
   for(const group of groups)launchMatch(group);
   sendQueue();
  }finally{scheduling=false;}
 }

 /* ---------- API ---------- */
 function join({prog,name,color,ip,playerKey}){
  const now=Date.now();let r=joinRates.get(ip);if(!r||now-r.start>60000){r={start:now,n:0};joinRates.set(ip,r);}
  if(++r.n>joinRateLimit)return{status:429,error:'کمی صبر کن و دوباره تلاش کن'};
  let compiled=DEFAULT_PROG;
  if(prog!==undefined&&prog!==null){
   if(typeof prog!=='object'||Array.isArray(prog))return{status:400,error:'برنامهٔ ربات نامعتبر است'};
   const c=Behavior.compile(prog);if(!c.ok)return{status:400,error:'برنامهٔ ربات نامعتبر است',details:c.errors};compiled=c.prog;
  }
  if(playerKey)for(const T of tickets.values())if(T.playerKey===playerKey&&T.state!=='done')return{status:409,error:'تو همین حالا در صف یا مسابقه‌ای'};
  if(queued().length>= (opts.maxQueue||2000))return{status:503,error:'صف مسابقه فعلاً پر است؛ کمی بعد دوباره تلاش کن'};
  const id=crypto.randomBytes(8).toString('hex'),token=crypto.randomBytes(16).toString('hex');
  const spec={name:typeof name==='string'&&name.trim()?name.trim().slice(0,16):'ربات من',color:/^#[0-9a-f]{6}$/i.test(color)?color:'#22d3ee',prog:compiled};
  if(store&&playerKey)store.profile(playerKey,spec.name,spec.color);
  const T={id,token,playerKey:playerKey||null,spec,state:'queued',joinedAt:now,M:null,robotId:null,subs:new Set(),settled:null,timer:null};
  T.timer=setTimeout(()=>{if(T.state==='queued'){retire(T,{aborted:true});sendQueue();}},PENDING_MS);T.timer.unref();
  tickets.set(id,T);sendQueue();
  return{id,token};
 }
 function subscribe(id,token,res){
  const T=tickets.get(id);if(!T||!same(token,T.token))return false;
  res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
  res.write('retry: 2000\n\n');
  if(T.state==='done'){
   if(T.M&&T.M.init)sse(res,'matchfound',{players:T.M.humanCount,bots:MAX_PLAYERS-T.M.humanCount,capacity:MAX_PLAYERS});
   if(T.M&&T.M.init)sse(res,'init',initFor(T.M.init,T));
   if(T.settled)sse(res,'result',T.settled);
   sse(res,'end',T.finalData||{aborted:true});res.end();return true;
  }
  T.subs.add(res);
  const hb=setInterval(()=>{try{res.write(': hb\n\n');}catch{}},HEARTBEAT_MS);hb.unref();
  res.on('close',()=>{clearInterval(hb);T.subs.delete(res);if(T.M)checkIdle(T.M);});
  if(T.state==='queued'){sse(res,'queue',queueInfo(T));runMatchmaking();}
  else{
   sse(res,'matchfound',{players:T.M.humanCount,bots:MAX_PLAYERS-T.M.humanCount,capacity:MAX_PLAYERS});
   checkIdle(T.M);workers[T.M.worker].postMessage({type:'state',id:T.M.id,req:T.id});
  }
  return true;
 }
 function leave(id,token){
  const T=tickets.get(id);if(!T||!same(token,T.token))return false;
  if(T.state==='queued'){retire(T,{aborted:true});sendQueue();}
  else if(T.state==='running'){
   const M=T.M,rank=Math.max(1,M.tickets.filter(x=>x.state!=='done'&&!x.settled).length);
   settle(T,rank);workers[M.worker].postMessage({type:'forfeit',id:M.id,robotId:T.robotId});
   retire(T,{ranks:{[T.robotId]:rank},aborted:true});
   if(M.tickets.every(t=>t.state==='done'))stopMatch(M);
  }
  return true;
 }

 const scheduler=setInterval(()=>{sendQueue();runMatchmaking();},schedulerMs);scheduler.unref();
 function close(){
  closed=true;clearInterval(scheduler);
  for(const T of tickets.values()){clearTimeout(T.timer);closeSubs(T);}
  for(const M of matches.values())clearTimeout(M.idle);
  tickets.clear();matches.clear();
  return Promise.all(workers.map(w=>w.terminate()));
 }
 return{join,subscribe,leave,close,stats:()=>({matches:matches.size,tickets:tickets.size,queued:queued().length,load:[...load],minPlayers:MIN_PLAYERS,maxPlayers:MAX_PLAYERS,relaxAfterMs})};
}
module.exports={createMatchManager,DEFAULT_PROG,MAX_PLAYERS,MIN_PLAYERS};
