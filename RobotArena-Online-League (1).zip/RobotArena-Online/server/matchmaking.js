'use strict';

/*
 * Dynamic Rank-Based Matchmaking
 * - Matches contain 7..10 real players. The arena engine fills remaining slots
 *   with its existing identical grey bots (0..3).
 * - Queue members are kept in contiguous leaderboard-rank windows.
 * - After 60 seconds, rank-window limits are relaxed so old tickets do not stall.
 */
const MIN_PLAYERS = 7;
const MAX_PLAYERS = 10;
const DEFAULT_RANK_WINDOW = 30;
const DEFAULT_RELAX_AFTER_MS = 60_000;

function makeSizes(used, groups) {
  const base = Math.floor(used / groups);
  const extra = used % groups;
  return Array.from({ length: groups }, (_, i) => base + (i < extra ? 1 : 0));
}

function planMatches(queue, rankOf, now = Date.now(), options = {}) {
  const minPlayers = options.minPlayers || MIN_PLAYERS;
  const maxPlayers = options.maxPlayers || MAX_PLAYERS;
  const rankWindow = options.rankWindow === undefined ? DEFAULT_RANK_WINDOW : options.rankWindow;
  const relaxAfterMs = options.relaxAfterMs === undefined ? DEFAULT_RELAX_AFTER_MS : options.relaxAfterMs;
  const maxGroups = Math.max(0, options.maxGroups === undefined ? Infinity : options.maxGroups);
  if (!Array.isArray(queue) || queue.length < minPlayers || !maxGroups) return [];

  const ranked = queue.map(ticket => ({ ticket, rank: Math.max(1, Number(rankOf(ticket)) || Number.MAX_SAFE_INTEGER) }))
    .sort((a, b) => a.rank - b.rank || (a.ticket.joinedAt || 0) - (b.ticket.joinedAt || 0) || String(a.ticket.id).localeCompare(String(b.ticket.id)));

  let count = Math.min(Math.floor(ranked.length / minPlayers), maxGroups);

  while (count > 0) {
    const used = Math.min(ranked.length, count * maxPlayers);
    const sizes = makeSizes(used, count);
    let best = null;

    // If only part of the queue can be used (e.g. 13 waiting), find the
    // tightest contiguous leaderboard window while giving older tickets priority.
    for (let start = 0; start <= ranked.length - used; start++) {
      const groups = [];
      let cursor = start;
      let spreadCost = 0;
      let valid = true;
      for (const size of sizes) {
        const slice = ranked.slice(cursor, cursor + size);
        cursor += size;
        const spread = slice[slice.length - 1].rank - slice[0].rank;
        const groupRelaxed = slice.some(x => now - (x.ticket.joinedAt ?? now) >= relaxAfterMs);
        if (!groupRelaxed && spread > rankWindow) { valid = false; break; }
        spreadCost += spread * spread;
        groups.push(slice.map(x => x.ticket));
      }
      if (!valid) continue;
      const selected = groups.flat();
      const waitingPriority = selected.reduce((sum, t) => sum + Math.max(0, now - (t.joinedAt ?? now)), 0);
      const score = spreadCost * 1000 - waitingPriority / 1000;
      if (!best || score < best.score) best = { score, groups };
    }

    if (best) return best.groups;
    count--;
  }
  return [];
}

module.exports = {
  planMatches,
  MIN_PLAYERS,
  MAX_PLAYERS,
  DEFAULT_RANK_WINDOW,
  DEFAULT_RELAX_AFTER_MS
};
