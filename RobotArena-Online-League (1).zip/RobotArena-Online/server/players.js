'use strict';
/* پروفایل، جام و جدول لیگ روی دیسک سرور. هویت = هش کوکی مهمان؛ توکن خام ذخیره نمی‌شود. */
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const{rewardOf}=require('../engine');

const levelOf=tr=>Math.floor(Math.max(0,tr)/50)+1;
const keyOf=token=>crypto.createHash('sha256').update(String(token)).digest('hex');
const validToken=t=>typeof t==='string'&&/^[0-9a-f]{32}$/.test(t);

function createPlayerStore(file){
 let db={version:2,players:{}};
 try{
  const j=JSON.parse(fs.readFileSync(file,'utf8'));
  if(j&&typeof j==='object'&&j.players&&typeof j.players==='object')db={version:2,players:j.players};
 }catch(e){
  if(e.code!=='ENOENT'){try{fs.renameSync(file,file+'.bad-'+Date.now());}catch{}}
 }
 function save(){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file+'.tmp',JSON.stringify(db));fs.renameSync(file+'.tmp',file);}
 const peek=key=>db.players[key]||null;
 function ensure(key){
  let p=db.players[key];
  if(!p){const now=Date.now();p=db.players[key]={name:'ربات من',color:'#22d3ee',tr:0,matches:0,wins:0,created:now,updated:now};}
  return p;
 }
 const view=p=>p?{name:p.name,color:p.color,tr:p.tr,level:levelOf(p.tr),matches:p.matches,wins:p.wins}:{name:'ربات من',color:'#22d3ee',tr:0,level:1,matches:0,wins:0};
 function sorted(){return Object.entries(db.players).map(([key,p])=>({key,...view(p),created:p.created||0,updated:p.updated||0}))
  .sort((a,b)=>b.tr-a.tr||b.wins-a.wins||a.created-b.created||a.key.localeCompare(b.key));}
 function rankOf(key){const i=sorted().findIndex(p=>p.key===key);return i<0?null:i+1;}
 return{
  keyOf,validToken,levelOf,
  get:key=>({...view(peek(key)),rank:rankOf(key)}),
  profile(key,name,color){
   const existed=!!peek(key),p=ensure(key);let ch=!existed;
   if(typeof name==='string'&&name.trim()){const n=name.trim().slice(0,16);if(n!==p.name){p.name=n;ch=true;}}
   if(typeof color==='string'&&/^#[0-9a-f]{6}$/i.test(color)&&color!==p.color){p.color=color;ch=true;}
   if(ch){p.updated=Date.now();save();}
   return {...view(p),rank:rankOf(key)};
  },
  rankOf,
  leaderboard(key,limit=8){
   const all=sorted(),meIndex=key?all.findIndex(p=>p.key===key):-1;
   const entries=all.slice(0,Math.max(1,Math.min(20,limit))).map((p,i)=>({rank:i+1,name:p.name,color:p.color,tr:p.tr,level:p.level,matches:p.matches,wins:p.wins}));
   const me=meIndex<0?null:{rank:meIndex+1,name:all[meIndex].name,tr:all[meIndex].tr,level:all[meIndex].level};
   return {entries,me,total:all.length};
  },
  settle(key,rank){
   const p=ensure(key),safeRank=Math.max(1,Math.min(10,Math.floor(Number(rank)||10))),old=p.tr,d=rewardOf(safeRank,levelOf(old));
   p.tr=Math.max(0,old+d);p.matches++;if(safeRank===1)p.wins++;p.updated=Date.now();save();
   return{rank:safeRank,delta:p.tr-old,total:p.tr,level:levelOf(p.tr)};
  }
 };
}
module.exports={createPlayerStore,levelOf,keyOf,validToken};
