'use strict';
/* اجراکنندهٔ مسابقه‌ها: یک حلقهٔ ۶۰Hz برای چند مسابقه. داخل worker_thread اجرا می‌شود (worker.js)،
   ولی مستقل از آن است تا تست‌پذیر باشد. هر SNAP_EVERY تیک یک snapshot + رخدادهای انباشته می‌فرستد (۶۰/۴ = ۱۵ در ثانیه). */
const engine=require('../engine');
const SNAP_EVERY=4,TICK_MS=1000/60;

function createRunner({send,speed=1}){
 const matches=new Map();
 let timer=null,last=process.hrtime.bigint();
 function loop(){
  const now=process.hrtime.bigint(),dt=Number(now-last)/1e6;last=now;
  for(const[id,s]of matches){
   s.acc=Math.min(s.acc+dt*speed,TICK_MS*10*speed);/* سقف جبران تأخیر */
   while(s.acc>=TICK_MS&&!s.m.over){
    s.acc-=TICK_MS;s.m.step();s.ev.push(...s.m.drainEvents());
    if(s.m.tick%SNAP_EVERY===0){send({type:'snap',id,snap:s.m.snapshot(),ev:s.ev});s.ev=[];}}
   if(s.m.over){
    send({type:'snap',id,snap:s.m.snapshot(),ev:s.ev});
    send({type:'end',id,ranks:s.m.ranks(),tick:s.m.tick});
    matches.delete(id);}
   else if(s.maxMs&&Date.now()-s.t0>s.maxMs){matches.delete(id);send({type:'end',id,ranks:s.m.ranks(),tick:s.m.tick,aborted:true});}
  }
  if(!matches.size&&timer){clearInterval(timer);timer=null;}
 }
 function start(msg){
  const m=engine.createMatch({seed:msg.seed,layout:msg.layout,players:msg.players});
  matches.set(msg.id,{m,acc:0,ev:[],t0:Date.now(),maxMs:msg.maxMs||0});
  send({type:'init',id:msg.id,init:m.init()});
  if(!timer){last=process.hrtime.bigint();timer=setInterval(loop,8);}
 }
 function handle(msg){
  if(msg.type==='start')start(msg);
  /* وضعیت کامل فعلی برای اتصال مجدد؛ req شناسهٔ درخواست‌کننده است و در پاسخ برمی‌گردد */
  else if(msg.type==='state'){const s=matches.get(msg.id);if(s)send({type:'state',id:msg.id,req:msg.req,init:s.m.init()});}
  else if(msg.type==='forfeit'){const s=matches.get(msg.id);if(s)s.m.forfeit(msg.robotId);}
  else if(msg.type==='stop'){matches.delete(msg.id);if(!matches.size&&timer){clearInterval(timer);timer=null;}}
 }
 return{handle,size:()=>matches.size,close(){if(timer)clearInterval(timer);timer=null;matches.clear();}};
}
module.exports={createRunner,SNAP_EVERY};
