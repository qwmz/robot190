'use strict';
const{parentPort,workerData}=require('node:worker_threads');
const{createRunner}=require('./runner');
const runner=createRunner({send:m=>parentPort.postMessage(m),speed:(workerData&&workerData.speed)||1});
parentPort.on('message',m=>{try{runner.handle(m);}catch(e){parentPort.postMessage({type:'error',id:m&&m.id,error:String(e&&e.message||e)});}});
