const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const {createServer}=require('../server');const ai=require('../ai');

test('inline scripts of index.html compile',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../public/index.html'),'utf8');
 const blocks=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);assert.ok(blocks.length>=2);
 for(const b of blocks)new vm.Script(b);
});

test('model output is validated: closed catalog, exact values clamped, OR/AND kept',()=>{
 const inp={move:['a','b','c','d','e'],shoot:['f'],skill:[]};
 const out=ai.validate({r:[
  {t:'move',i:0,ok:true,c:'surrounded',o:[{c:'cornered',x:[{c:'hp_low',v:40}]}],x:[{c:'hp_low',v:31.4},{c:'nope'},{c:'near',v:9999,n:true}],a:[{a:'breakout'},{a:'shield'},{a:'__proto__'}]},
  {t:'move',i:1,ok:true,c:'__proto__',a:[{a:'hold'}]},
  {t:'move',i:2,ok:true,c:'near',v:150,a:[{a:'keep',v:-5},{a:'approach'}]},
  {t:'move',i:3,ok:false,m:'x'},
  {t:'shoot',i:0,ok:true,c:'always',a:[{a:'fire_range',v:333},{a:'t_far'},{a:'rapid'}]},
  {t:'move',i:99,ok:true,c:'always',a:[{a:'hold'}]},{t:'__proto__',i:0}]},inp);
 assert.equal(out.move[0].status,'ok');assert.deepEqual(out.move[0].acts,[{a:'breakout'}]);assert.ok(out.move[0].warn);
 assert.deepEqual(out.move[0].x,[{c:'hp_low',cv:31},{c:'near',cv:400,n:true}]);
 assert.deepEqual(out.move[0].alts,[{c:'cornered',x:[{c:'hp_low',cv:40}]}]);
 assert.equal(out.move[1].status,'bad');assert.equal(out.move[2].status,'bad');assert.equal(out.move[3].status,'bad');
 assert.equal(out.move[4].status,'bad');// بدون خروجی از مدل → «نفهمیدم»
 assert.deepEqual(out.shoot[0].acts,[{a:'fire_range',av:333},{a:'t_far'},{a:'rapid'}]);
 assert.deepEqual(ai.validate(null,{move:['q'],shoot:[],skill:[]}).move.map(x=>x.status),['bad']);
});

test('one request for all tabs, only new sentences, nothing trusted',async()=>{
 delete process.env.ANTHROPIC_API_KEY;let calls=0,sent;
 const fake=async(url,init)=>{calls++;sent=JSON.parse(init.body);return{ok:true,json:async()=>({content:[{type:'tool_use',name:'emit_rules',input:{r:[
  {t:'move',i:0,ok:true,c:'surrounded',a:[{a:'cover'}]},{t:'shoot',i:0,ok:true,c:'near',v:200,a:[{a:'cease_fire'}]},{t:'skill',i:0,ok:true,c:'rm -rf',a:[{a:'shield'}]}]}}]})};};
 const r=await ai.interpret({move:['محاصره شدم پناه بگیر'],shoot:['نزدیک شد شلیک نکن'],skill:['ایکس']},{apiKey:'k',fetch:fake});
 assert.equal(calls,1);assert.equal(sent.tool_choice.name,'emit_rules');
 assert.match(sent.messages[0].content,/\[move\]\n0:محاصره شدم پناه بگیر\n\[shoot\]\n0:نزدیک شد شلیک نکن\n\[skill\]\n0:ایکس/);
 assert.equal(r.move[0].status,'ok');assert.equal(r.shoot[0].acts[0].a,'cease_fire');assert.equal(r.skill[0].status,'bad');
 // همان جمله‌ها دوباره: صفر درخواست؛ جملهٔ تازه: فقط همان فرستاده می‌شود
 await ai.interpret({move:['محاصره شدم پناه بگیر'],shoot:['نزدیک شد شلیک نکن'],skill:[]},{apiKey:'k',fetch:fake});assert.equal(calls,1);
 await ai.interpret({move:['محاصره شدم پناه بگیر','جملهٔ تازه'],shoot:[],skill:[]},{apiKey:'k',fetch:fake});assert.equal(calls,2);
 assert.match(sent.messages[0].content,/^\[move\]\n0:جملهٔ تازه$/);
 assert.ok(ai.SYSTEM.length<6000,'compact prompt: '+ai.SYSTEM.length);
});

test('OpenRouter keys use the OpenAI-style endpoint with a forced tool call',async()=>{
 let url,sent,auth;
 const fake=async(u,init)=>{url=u;sent=JSON.parse(init.body);auth=init.headers.Authorization;return{ok:true,json:async()=>({choices:[{message:{tool_calls:[{function:{arguments:JSON.stringify({r:[{t:'move',i:0,ok:true,c:'cornered',a:[{a:'cover'}]}]})}}]}}]})};};
 const r=await ai.interpret({move:['تست یکتا برای اوپن‌روتر']},{apiKey:'sk-or-v1-test',fetch:fake});
 assert.match(url,/openrouter\.ai\/api\/v1\/chat\/completions/);assert.equal(auth,'Bearer sk-or-v1-test');
 assert.equal(sent.model,'anthropic/claude-haiku-5.5');assert.equal(sent.tool_choice.function.name,'emit_rules');assert.equal(sent.messages[0].role,'system');
 assert.equal(r.move[0].c,'cornered');assert.deepEqual(r.move[0].acts,[{a:'cover'}]);
});

test('/api/interpret: disabled without key, validates shape',async()=>{
 delete process.env.ANTHROPIC_API_KEY;
 const post=(base,data)=>fetch(base+'/api/interpret',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 let app=createServer();await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 try{const base='http://127.0.0.1:'+app.server.address().port;assert.equal((await post(base,{s:{move:['x']}})).status,503);}finally{app.stop();}
 app=createServer({interpret:async s=>({move:s.move.map(t=>({text:t,status:'ok',c:'always',acts:[{a:'hold'}]}))})});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+app.server.address().port;
 try{const j=await(await post(base,{s:{move:['همیشه بایست']}})).json();assert.equal(j.r.move[0].c,'always');
  assert.equal((await post(base,{s:{__proto__x:['a']}})).status,400);assert.equal((await post(base,{s:{move:[5]}})).status,400);assert.equal((await post(base,{text:'x'})).status,400);
 }finally{app.stop();}
});

test('validate accepts the three-array model format and a compact schema',()=>{
 const out=ai.validate({move:[{i:0,ok:true,c:'near',v:150,a:[{a:'retreat'}]}],shoot:[{i:1,ok:true,c:'always',a:[{a:'cease_fire'}]}],skill:[]},{move:['a'],shoot:['b','c'],skill:[]});
 assert.equal(out.move[0].c,'near');assert.equal(out.shoot[0].status,'bad','missing item → bad');assert.equal(out.shoot[1].acts[0].a,'cease_fire');
 assert.ok(JSON.stringify(ai.tool()).length<3500,'item schema defined once ($defs)');
});
