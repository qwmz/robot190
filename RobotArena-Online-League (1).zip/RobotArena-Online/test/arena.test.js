'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const http=require('node:http');
const{createServer}=require('../server');
const E=require('../engine');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
function start(arena){
 const playersFile=path.join(fs.mkdtempSync(path.join(os.tmpdir(),'ra-players-')),'players.json');
 const app=createServer({playersFile,arena:{workers:1,queueMs:40,...arena}});
 return new Promise(ok=>app.server.listen(0,'127.0.0.1',()=>ok({app,port:app.server.address().port,playersFile})));
}
function post(port,p,body,cookie){
 return new Promise((ok,bad)=>{const data=JSON.stringify(body),headers={'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)};if(cookie)headers.Cookie=cookie;
  const req=http.request({port,path:p,method:'POST',headers},res=>{let t='';res.on('data',c=>t+=c);res.on('end',()=>ok({status:res.statusCode,json:JSON.parse(t||'{}'),setCookie:res.headers['set-cookie']}));});req.on('error',bad);req.end(data);});
}
function getJson(port,p,cookie){return new Promise((ok,bad)=>http.get({port,path:p,headers:cookie?{Cookie:cookie}:{}},res=>{let t='';res.on('data',c=>t+=c);res.on('end',()=>ok({status:res.statusCode,json:JSON.parse(t||'{}'),setCookie:res.headers['set-cookie']}));}).on('error',bad));}
const cookieOf=r=>(r.setCookie||[]).map(c=>c.split(';')[0]).find(c=>c.startsWith('ra_guest='));
function stream(port,id,token,onEvent){return new Promise((ok,bad)=>{const events=[];http.get({port,path:'/api/arena/stream?id='+id+'&token='+token},res=>{
 if(res.statusCode!==200){res.resume();return ok({status:res.statusCode,events});}assert.match(res.headers['content-type'],/text\/event-stream/);let buf='';res.setEncoding('utf8');
 res.on('data',c=>{buf+=c;let i;while((i=buf.indexOf('\n\n'))>=0){const blk=buf.slice(0,i);buf=buf.slice(i+2);const m=/^event: (\w+)\ndata: (.*)$/m.exec(blk);if(m){const e={name:m[1],data:JSON.parse(m[2])};events.push(e);if(onEvent)onEvent(e);}}});
 res.on('end',()=>ok({status:200,events}));res.on('error',bad);
 }).on('error',bad);});}
function streamUntil(port,id,token,stopName,{keep}={}){return new Promise((ok,bad)=>{const events=[];let done=false;const req=http.get({port,path:'/api/arena/stream?id='+id+'&token='+token},res=>{
 if(res.statusCode!==200){res.resume();return ok({status:res.statusCode,events,req});}let buf='';res.setEncoding('utf8');res.on('data',c=>{buf+=c;let i;while((i=buf.indexOf('\n\n'))>=0){const blk=buf.slice(0,i);buf=buf.slice(i+2);const m=/^event: (\w+)\ndata: (.*)$/m.exec(blk);if(m){const e={name:m[1],data:JSON.parse(m[2])};events.push(e);if(!done&&e.name===stopName){done=true;if(!keep)req.destroy();ok({status:200,events,req});}}}});res.on('end',()=>{if(!done)ok({status:200,events,req});});res.on('error',()=>{});
 });req.on('error',e=>{if(!done)bad(e);});});}
const newGuest=async port=>cookieOf(await getJson(port,'/api/me'));
const AGGR={move:{k:'goto',to:'nearest'},target:{k:'pick',who:'nearest'},fire:{k:'fire',on:true,range:680}};
async function joinedGroup(port,n,{firstName='p0',firstCookie=null,prog=AGGR}={}){
 const out=[];for(let i=0;i<n;i++){const ck=i===0&&firstCookie?firstCookie:await newGuest(port);const j=await post(port,'/api/arena/join',{name:i===0?firstName:'p'+i,prog},ck);assert.equal(j.status,200);out.push({cookie:ck,...j.json});}return out;
}

 test('۷ بازیکن واقعی یک زمین می‌سازند و سه ربات ظرفیت را کامل می‌کنند؛ جام با رتبهٔ انسانی است',async()=>{
 const{app,port}=await start({speed:40});try{
  const group=await joinedGroup(port,7,{firstName:'الف'});const rs=await Promise.all(group.map(x=>stream(port,x.id,x.token)));
  const inits=rs.map(r=>r.events.find(e=>e.name==='init').data);
  assert.equal(new Set(inits.map(x=>x.you)).size,7);
  assert.equal(inits[0].robots.length,10);assert.equal(inits[0].robots.filter(x=>x.human).length,7);
  assert.equal(rs[0].events.find(e=>e.name==='matchfound').data.bots,3);
  const ranks=rs[0].events.at(-1).data.ranks;assert.deepEqual(Object.values(ranks).sort((a,b)=>a-b),[1,2,3,4,5,6,7]);
  for(const r of rs){const result=r.events.find(e=>e.name==='result').data;assert.equal(result.rank,ranks[r.events.find(e=>e.name==='init').data.you]);}
 }finally{app.stop();}
});

test('۱۰ بازیکن واقعی بدون انتظار اضافی وارد زمین می‌شوند',async()=>{
 const{app,port}=await start({speed:5,schedulerMs:30});try{
  const group=await joinedGroup(port,10);const rs=await Promise.all(group.map(x=>streamUntil(port,x.id,x.token,'init',{keep:true})));
  assert.equal(new Set(rs.map(r=>r.events.find(e=>e.name==='init').data.you)).size,10);
  assert.equal(rs[0].events.find(e=>e.name==='init').data.robots.filter(r=>r.human).length,10);
  for(const r of rs)r.req.destroy();
 }finally{app.stop();}
});

test('کمتر از ۷ نفر در صف می‌مانند؛ لغو صف امن است',async()=>{
 const{app,port}=await start({schedulerMs:30});try{
  const j=await post(port,'/api/arena/join',{});const r=await streamUntil(port,j.json.id,j.json.token,'queue');
  assert.equal(r.events[0].data.n,1);assert.equal(r.events[0].data.min,7);assert.equal(r.events.some(e=>e.name==='init'),false);
  assert.equal((await getJson(port,'/api/arena/status')).json.queued,1);
  assert.equal((await post(port,'/api/arena/leave',{id:j.json.id,token:j.json.token})).status,200);
  assert.equal((await getJson(port,'/api/arena/status')).json.queued,0);
 }finally{app.stop();}
});

test('یک بازیکن هم‌زمان فقط یک بلیت دارد؛ پس از لغو دوباره مجاز است',async()=>{
 const{app,port}=await start({schedulerMs:10000});try{
  const ck=await newGuest(port),a=await post(port,'/api/arena/join',{},ck);assert.equal(a.status,200);
  assert.equal((await post(port,'/api/arena/join',{},ck)).status,409);
  await post(port,'/api/arena/leave',{id:a.json.id,token:a.json.token},ck);
  assert.equal((await post(port,'/api/arena/join',{},ck)).status,200);
 }finally{app.stop();}
});

test('اتصال مجدد به زمین آنلاین همان جایگاه و وضعیت تازه را می‌گیرد',async()=>{
 const{app,port}=await start({speed:5,schedulerMs:30});try{
  const group=await joinedGroup(port,7);const others=await Promise.all(group.slice(1).map(x=>streamUntil(port,x.id,x.token,'init',{keep:true})));
  const first=await new Promise((ok,bad)=>{http.get({port,path:'/api/arena/stream?id='+group[0].id+'&token='+group[0].token},res=>{let buf='';res.setEncoding('utf8');res.on('data',c=>{buf+=c;if((buf.match(/event: s\n/g)||[]).length>=15){res.destroy();ok(buf);}});res.on('error',()=>{});}).on('error',bad);});
  const initA=JSON.parse(/event: init\ndata: (.*)/.exec(first)[1]);const r=await stream(port,group[0].id,group[0].token);
  const fresh=r.events.find(e=>e.name==='init').data;assert.ok(fresh.snapshot.t>initA.snapshot.t+20);assert.equal(fresh.you,initA.you);assert.equal(r.events.at(-1).name,'end');
  assert.ok(r.events.find(e=>e.name==='result'));for(const x of others)x.req.destroy();
 }finally{app.stop();}
});

test('زمین: snapshotهای ۱۵ هرتز و رتبهٔ انسانی بازیکنان',async()=>{
 const{app,port}=await start({speed:40,schedulerMs:30});try{
  const group=await joinedGroup(port,7,{firstName:'تست'});const rs=await Promise.all(group.map(x=>stream(port,x.id,x.token)));
  const r=rs[0],init=r.events.find(e=>e.name==='init').data;assert.equal(init.robots.length,10);assert.ok(init.robots.some(r=>r.human&&r.name==='تست'));
  const snaps=r.events.filter(e=>e.name==='s').map(e=>e.data);assert.ok(snaps.length>20);
  for(let i=1;i<snaps.length-1;i++)assert.equal(snaps[i].t-snaps[i-1].t,4);
  assert.deepEqual(Object.values(r.events.at(-1).data.ranks).sort((a,b)=>a-b),[1,2,3,4,5,6,7]);
  assert.ok(snaps.some(s=>s.ev.some(e=>e[0]==='shot')));
 }finally{app.stop();}
});

test('فایل‌های نمایش آنلاین و API جدول لیگ ارائه می‌شوند',async()=>{
 const{app,port}=await start({});const get=p=>new Promise((ok,bad)=>http.get({port,path:p},res=>{let t='';res.on('data',c=>t+=c);res.on('end',()=>ok({status:res.statusCode,type:res.headers['content-type'],t}));}).on('error',bad));
 try{
  for(const f of['/interp.js','/online-view.js']){const r=await get(f);assert.equal(r.status,200);assert.match(r.type,/javascript/);}
  const page=(await get('/')).t;assert.ok(page.includes('home.js'));const home=(await get('/home.js')).t;assert.ok(home.includes('nLeague')&&home.includes('لیگ آنلاین'));
  const profile=await post(port,'/api/profile',{name:'جدولی',color:'#112233'});assert.equal(profile.status,200);
  const board=await getJson(port,'/api/leaderboard',cookieOf(profile));assert.equal(board.json.total,1);assert.equal(board.json.entries[0].name,'جدولی');assert.equal(board.json.me.rank,1);
 }finally{app.stop();}
});

test('برنامهٔ نامعتبر و ورودی‌های بد رد می‌شوند',async()=>{
 const{app,port}=await start({});try{
  assert.equal((await post(port,'/api/arena/join',{prog:{move:{k:'rm -rf'}}})).status,400);
  assert.equal((await post(port,'/api/arena/join',{prog:[1]})).status,400);
  assert.equal((await post(port,'/api/arena/join',{name:5})).status,400);
  assert.equal((await stream(port,'nope','x')).status,404);
  const j=await post(port,'/api/arena/join',{});assert.equal(j.status,200);
  assert.equal((await stream(port,j.json.id,'0'.repeat(32))).status,404);
 }finally{app.stop();}
});

test('سقف مسابقه‌های هم‌زمان صف را از بین نمی‌برد؛ محدودیت نرخ join فعال است',async()=>{
 const{app,port}=await start({maxMatches:1,schedulerMs:30});try{
  const first=await joinedGroup(port,7);const active=await Promise.all(first.map(x=>streamUntil(port,x.id,x.token,'init',{keep:true})));
  const waiting=await joinedGroup(port,7);const queued=await Promise.all(waiting.map(x=>streamUntil(port,x.id,x.token,'queue',{keep:true})));
  assert.equal((await getJson(port,'/api/arena/status')).json.queued,7);
  for(const r of [...active,...queued])r.req.destroy();
 }finally{app.stop();}
 const b=await start({maxMatches:99,schedulerMs:60000,joinRateLimit:10});try{let last;for(let i=0;i<12;i++)last=await post(b.port,'/api/arena/join',{});assert.equal(last.status,429);}finally{b.app.stop();}
});

test('هویت مهمان، کوکی امن، ذخیرهٔ پروفایل و جام سروری',async()=>{
 const{app,port,playersFile}=await start({speed:40,schedulerMs:30});try{
  const me0=await getJson(port,'/api/me'),ck=cookieOf(me0);assert.ok(ck);assert.match(me0.setCookie[0],/HttpOnly/);assert.match(me0.setCookie[0],/SameSite=Lax/);
  assert.deepEqual([me0.json.tr,me0.json.level],[0,1]);assert.equal(fs.existsSync(playersFile),false);
  const group=await joinedGroup(port,7,{firstName:'سارا',firstCookie:ck});const rs=await Promise.all(group.map(x=>stream(port,x.id,x.token)));
  const index=rs[0].events.find(e=>e.name==='init').data.you,result=rs[0].events.find(e=>e.name==='result').data;
  assert.equal(result.rank,rs[0].events.at(-1).data.ranks[index]);assert.equal(result.delta,E.rewardOf(result.rank,1));
  const me=await getJson(port,'/api/me',ck);assert.deepEqual([me.json.name,me.json.tr,me.json.matches],['سارا',result.total,1]);
  const raw=fs.readFileSync(playersFile,'utf8'),tok=ck.split('=')[1];assert.ok(!raw.includes(tok));assert.ok(raw.includes('سارا'));
  const other=await getJson(port,'/api/me');assert.equal(other.json.matches,0);
 }finally{app.stop();}
});

test('ترک پیش از شروع جریمه ندارد و ترک وسط بازی آخرین رتبهٔ انسانی می‌گیرد',async()=>{
 const{app,port}=await start({idleMs:150,speed:5,schedulerMs:30});try{
  const ck=await newGuest(port),a=await post(port,'/api/arena/join',{},ck);await post(port,'/api/arena/leave',{id:a.json.id,token:a.json.token},ck);
  assert.equal((await getJson(port,'/api/me',ck)).json.matches,0);
  const group=await joinedGroup(port,7,{firstCookie:ck});let left=false;
  const rs=await Promise.all(group.map((x,i)=>stream(port,x.id,x.token,e=>{if(i===0&&e.name==='init'&&!left){left=true;post(port,'/api/arena/leave',{id:x.id,token:x.token},x.cookie);}})));
  const result=rs[0].events.find(e=>e.name==='result').data;assert.equal(result.rank,7);assert.equal(rs[0].events.at(-1).data.aborted,true);
  const humanRanks=rs.map(r=>r.events.find(e=>e.name==='result')?.data.rank).filter(Number.isFinite).sort((a,b)=>a-b);assert.deepEqual(humanRanks,[1,2,3,4,5,6,7]);
  const me=await getJson(port,'/api/me',ck);assert.equal(me.json.matches,1);
 }finally{app.stop();}
});
