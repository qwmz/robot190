const {test}=require('node:test');const assert=require('node:assert/strict');
const B=require('../behavior');const aiProgram=require('../ai-program');

const sq={move:{k:'seq',loop:true,steps:[{t:30,n:{k:'go',dir:'up'}},{t:30,n:{k:'go',dir:'right'}},{t:30,n:{k:'go',dir:'down'}},{t:30,n:{k:'go',dir:'left'}}]},fire:'always',target:'weakest'};

test('sequence with loop runs steps in order over time',()=>{
 const c=B.compile(sq);assert.deepEqual(c.errors,[]);const run=B.runner(c.prog);const dirs=[];
 for(let t=0;t<=30*60*4+5;t++){const o=run.step({tick:t,sensor:()=>0});if(t%60===0)dirs.push(o.move.dir);}
 assert.deepEqual([dirs[0],dirs[29],dirs[30],dirs[60],dirs[90],dirs[119],dirs[120]],['up','up','right','down','left','left','up']);
});

test('if/else and sensors with thresholds',()=>{
 const c=B.compile({move:{k:'if',c:{s:'hp',op:'<',v:35},then:{k:'flee'},else:{k:'go',dir:'toward'}}});let hp=80;
 const run=B.runner(c.prog),x=()=>({tick:0,sensor:n=>n==='hp'?hp:0});
 assert.equal(run.step(x()).move.kind,'go');hp=20;assert.equal(run.step(x()).move.kind,'flee');
});

test('states switch with transitions and counters',()=>{
 const c=B.compile({move:{k:'states',start:'a',s:{a:{n:{k:'go',dir:'up'},to:[{c:{s:'enemies',op:'>=',v:2},go:'b',set:{n:{add:1}}}]},b:{n:{k:'flee'},to:[{c:{s:'enemies',op:'<',v:1},go:'a'}]}}}});
 assert.deepEqual(c.errors,[]);let e=0;const run=B.runner(c.prog),x=()=>({tick:0,sensor:n=>n==='enemies'?e:0});
 assert.equal(run.step(x()).move.kind,'go');e=3;assert.equal(run.step(x()).move.kind,'flee');assert.equal(run.vars.n,1);e=0;assert.equal(run.step(x()).move.kind,'go');
});

test('goto with reach advances to the next waypoint',()=>{
 const c=B.compile({move:{k:'seq',steps:[{reach:true,n:{k:'goto',x:.1,y:.1}},{reach:true,n:{k:'goto',x:.9,y:.9}}]}});let arrived=false;
 const run=B.runner(c.prog),x=()=>({tick:0,sensor:()=>0,reached:()=>arrived});
 assert.equal(run.step(x()).move.px,.1);arrived=true;assert.equal(run.step(x()).move.px,.9);
});

test('validation: unknown bricks rejected, numbers clamped, limits enforced',()=>{
 assert.equal(B.compile({move:{k:'eval',code:'x'}}).prog,null);
 assert.equal(B.compile({move:{k:'if',c:{s:'__proto__',op:'<',v:1},then:{k:'stop'}}}).prog,null);
 const c=B.compile({move:{k:'go',dir:99999,spd:50},fire:{k:'fire',on:true,range:99999}});
 assert.equal(c.prog.move.dir,99999%360);assert.equal(c.prog.move.spd,1.2);assert.equal(c.prog.fire.range,900);
 let deep={k:'stop'};for(let i=0;i<30;i++)deep={k:'if',c:{always:true},then:deep};
 assert.ok(B.compile({move:deep}).errors.length>0);
 const big={k:'seq',steps:Array.from({length:200},()=>({t:1,n:{k:'stop'}}))};assert.ok(B.compile({move:big}).prog.move.steps.length<=16);
 assert.equal(B.compile(null).prog,null);assert.equal(B.compile({}).prog,null);
});

test('describe gives Persian lines and features report what the program uses',()=>{
 const c=B.compile(sq);const d=B.describe(c.prog).join('\n');assert.match(d,/برو بالا/);assert.match(d,/ضعیف‌ترین/);
 const f=B.features(c.prog);assert.ok(f.move&&f.fire&&f.target);
 const f2=B.features(B.compile({move:{k:'if',c:{s:'hp',op:'<',v:30},then:{k:'flee'}}}).prog);assert.ok(f2.sensors.has('hp')&&f2.move&&!f2.fire);
});

test('AI program: validated output accepted; invalid output triggers one repair; unclear asks',async()=>{
 const mk=outs=>{let i=0;return async()=>({ok:true,json:async()=>({choices:[{message:{tool_calls:[{function:{arguments:JSON.stringify(outs[Math.min(i++,outs.length-1)])}}]}}]})});};
 const ok=await aiProgram.program('تست یک',{apiKey:'sk-or-v1-test',fetch:mk([{program:sq}])});
 assert.equal(ok.status,'ok');assert.ok(ok.prog.move);
 let calls=0;const f=mk([{program:{move:{k:'nope'}}},{program:{move:{k:'flee'}}}]);
 const fixed=await aiProgram.program('تست دو',{apiKey:'sk-or-v1-test',fetch:async(...a)=>{calls++;return f(...a);}});
 assert.equal(fixed.status,'ok');assert.equal(calls,2);
 const ask=await aiProgram.program('تست سه',{apiKey:'sk-or-v1-test',fetch:mk([{program:null,ask:'کدام دشمن؟'}])});
 assert.equal(ask.status,'ask');
 await assert.rejects(()=>aiProgram.program('x',{apiKey:''}),/ai-disabled/);
});
