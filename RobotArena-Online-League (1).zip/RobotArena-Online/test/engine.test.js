'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../engine');
const Behavior=require('../behavior');

const PROG=Behavior.compile({
 move:{k:'if',c:{s:'safe_cube',op:'==',v:1},then:{k:'goto',to:'safe_cube'},else:{k:'goto',to:'nearest'}},
 target:{k:'pick',who:'nearest'},fire:{k:'fire',on:true,range:680}}).prog;
const players=()=>[{name:'من',color:'#22d3ee',prog:PROG}];

function run(seed,ticks,pl){
 const m=E.createMatch({seed,players:pl});
 const events=[];let n=0;
 while(!m.over&&n<ticks){m.step();n++;events.push(...m.drainEvents());}
 return{m,events,n};
}

test('برنامهٔ نمونه معتبر است',()=>{assert.ok(PROG,'compile باید برنامه بدهد');});

test('مسابقهٔ بذری قطعی است: دو اجرا با یک بذر دقیقاً یکی‌اند',()=>{
 const a=run(7,3000,players()),b=run(7,3000,players());
 assert.equal(JSON.stringify(a.m.snapshot()),JSON.stringify(b.m.snapshot()));
 assert.equal(JSON.stringify(a.events),JSON.stringify(b.events));
 const c=run(8,3000,players());
 assert.notEqual(JSON.stringify(a.m.snapshot()),JSON.stringify(c.m.snapshot()),'بذر دیگر باید نتیجهٔ دیگری بدهد');
});

test('مسابقهٔ ۱۰ ربات تمام می‌شود و رتبه‌ها یک جایگشت از ۱ تا ۱۰ هستند',()=>{
 const{m,n}=run(3,200000,players());
 assert.ok(m.over,'مسابقه باید تمام شود (n='+n+')');
 const ranks=Object.values(m.ranks()).sort((x,y)=>x-y);
 assert.deepEqual(ranks,[1,2,3,4,5,6,7,8,9,10]);
});

test('رتبهٔ انسانیِ حذف‌های بعدی، حذف‌شده‌های قبلی و ربات‌ها را نادیده می‌گیرد',()=>{
 const pl=Array.from({length:7},(_,i)=>({name:'بازیکن '+i,color:'#22d3ee',prog:PROG}));
 const m=E.createMatch({seed:17,players:pl});
 const B=m.B;
 /* سه انسان قبلاً حذف شده‌اند و رتبه‌های انسانی ۷، ۶ و ۵ گرفته‌اند. */
 for(let i=0;i<3;i++){B.robots[i].alive=false;B.ranks[i]=7-i;}
 /* دو انسان دیگر هم‌زمان حذف می‌شوند؛ باید رتبه‌های انسانی ۴ و ۳ بگیرند. */
 B.robots[3].alive=false;B.robots[4].alive=false;
 for(let i=0;i<6;i++)m.step();
 const events=m.drainEvents().filter(e=>e[0]==='rank');
 const humanRanks=new Map(events.map(e=>[e[2],e[4]]));
 assert.equal(humanRanks.get(3),4);assert.equal(humanRanks.get(4),3);
});

test('وضعیت اولیه، snapshot و رخدادها شکل درست دارند',()=>{
 const{m,events}=run(5,1200,players());
 const init=m.init();
 assert.equal(init.robots.length,10);
 assert.equal(init.tickRate,60);
 assert.ok(init.obstacles.length>4);
 const s=m.snapshot();
 assert.equal(s.r.length,10);
 for(const r of s.r){assert.equal(r.length,9);assert.ok(r.every(Number.isFinite));}
 const kinds=new Set(events.map(e=>e[0]));
 assert.ok(kinds.has('shot'),'باید شلیک داشته باشیم');
 for(const e of events)assert.equal(typeof e[1],'number');
 /* ربات‌ها داخل زمین و بیرون دیوارها می‌مانند */
 for(const r of m.B.robots)if(r.alive){assert.ok(r.x>0&&r.x<m.B.w&&r.y>0&&r.y<m.B.h);}
 assert.ok(JSON.stringify(s).length<1200,'snapshot باید جمع‌وجور باشد: '+JSON.stringify(s).length);
});

test('زون با گذشت زمان دیوار می‌سازد و ربات‌ها را به داخل می‌راند',()=>{
 const m=E.createMatch({seed:11,players:[]});
 const walls0=m.B.obstacles.length;
 for(let i=0;i<E.ZONE_T*3+10&&!m.over;i++)m.step();
 assert.ok(m.B.k>=3||m.over);
 if(!m.over){assert.equal(m.B.obstacles.length,walls0+4*m.B.k);
  const b=50*(m.B.k+1);for(const r of m.B.robots)if(r.alive)assert.ok(r.x>=b&&r.x<=m.B.w-b&&r.y>=b&&r.y<=m.B.h-b);}
});

test('جام: رتبه بهتر جام بیشتر و سطح بالاتر جام کمتر',()=>{
 assert.equal(E.rewardOf(1,1),10);
 assert.ok(E.rewardOf(1,5)>=3);
 assert.ok(E.rewardOf(6,1)>E.rewardOf(6,3));
 assert.ok(E.rewardOf(10,1)<0);
});

test('سرعت: یک مسابقه کامل بسیار سریع‌تر از زمان واقعی است',()=>{
 const t0=process.hrtime.bigint();
 const{n}=run(21,12000,players());
 const ms=Number(process.hrtime.bigint()-t0)/1e6;
 const perTick=ms/n;
 console.log('  هر تیک: '+perTick.toFixed(3)+'ms روی '+n+' تیک');
 assert.ok(perTick<8,'هر تیک باید زیر ۸ میلی‌ثانیه باشد: '+perTick);
});
