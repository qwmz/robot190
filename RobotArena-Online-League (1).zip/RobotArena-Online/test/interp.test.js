'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const I=require('../public/interp');
const Behavior=require('../behavior');

const snap=(t,x,ang,alive=1,hp=100)=>({t,k:0,left:10,r:[[0,x,50,ang,ang,hp,100,0,alive]],c:[[10,1,120]]});
const near=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<e,a+' ≠ '+b);

test('lerpAngle کوتاه‌ترین مسیر را می‌رود',()=>{
 const mid=I.lerpAngle(3.0,-3.0,.5);assert.ok(Math.abs(Math.abs(mid)-Math.PI)<.2,'وسط راه باید نزدیک π باشد: '+mid);
 near(I.lerpAngle(0,1,.5),.5);
});

test('sample: موقعیت بین دو snapshot خطی است',()=>{
 const buf=[snap(0,0,0),snap(4,40,0)];
 near(I.sample(buf,1).robots[0].x,10);near(I.sample(buf,2).robots[0].x,20);near(I.sample(buf,3.5).robots[0].x,35);
});

test('sample: زاویه‌ها از ×۱۰۰ برگردانده و درون‌یابی می‌شوند',()=>{
 const buf=[snap(0,0,0),snap(4,0,100)];
 near(I.sample(buf,2).robots[0].angle,.5);
});

test('sample: قبل از اولین snapshot ثابت می‌ماند و بعد از آخرین تا سقف برون‌یابی ادامه می‌دهد',()=>{
 const buf=[snap(8,0,0),snap(12,40,0)];
 near(I.sample(buf,0).robots[0].x,0);
 near(I.sample(buf,14).robots[0].x,60);/* سرعت ۱۰ در تیک، ۲ تیک بعد از آخرین */
 near(I.sample(buf,100).robots[0].x,40+6*10);/* سقف ۶ تیک */
});

test('sample: مرگ و جان',()=>{
 const buf=[snap(0,0,0,1,100),snap(4,0,0,0,0)];
 assert.equal(I.sample(buf,1).robots[0].alive,true);
 assert.equal(I.sample(buf,3).robots[0].alive,false);
 near(I.sample(buf,2).robots[0].hp,50);
});

test('prune: همیشه یک snapshot قبل از زمان فعلی می‌ماند',()=>{
 const buf=[snap(0,0,0),snap(4,0,0),snap(8,0,0),snap(12,0,0)];
 I.prune(buf,9);assert.deepEqual(buf.map(s=>s.t),[8,12]);
 I.prune(buf,100);assert.equal(buf.length,2);
});

test('ساعت: کمینهٔ تأخیر فوری و تأخیر بیشتر آهسته جذب می‌شود',()=>{
 const c=I.createClock();assert.equal(c.ready,false);
 c.observe(0,1000);near(c.tickAt(1000),0);
 c.observe(60,1000+1000+200);/* پیام ۲۰۰ms دیر رسید */
 const t=c.tickAt(2000);assert.ok(t<60&&t>58,'تأخیر ۲۰۰ms فقط کمی ساعت را جابه‌جا می‌کند: '+t);
 c.observe(120,3000-50);/* پیام زودتر از انتظار */
 near(c.tickAt(2950),120);
});

test('برنامهٔ کامپایل‌شده دوباره کامپایل می‌شود (کاربر خروجی compile را به سرور می‌فرستد)',()=>{
 const first=Behavior.compile({move:{k:'states',start:'a',s:{a:{n:{k:'goto',to:'cube'},to:[{c:{s:'hp',op:'<',v:30},go:'b'}]},b:{n:{k:'flee'},to:[]}}},
  target:{k:'if',c:{s:'enemies_within',r:300,op:'>=',v:2},then:{k:'pick',who:'weakest'},else:{k:'pick',who:'nearest'}},fire:{k:'fire',on:true,range:500}});
 assert.ok(first.ok);
 const again=Behavior.compile(JSON.parse(JSON.stringify(first.prog)));
 assert.ok(again.ok,JSON.stringify(again.errors));
 assert.deepEqual(Behavior.describe(again.prog),Behavior.describe(first.prog));
});
