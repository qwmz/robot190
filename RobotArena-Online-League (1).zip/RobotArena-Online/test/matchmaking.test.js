'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const{planMatches}=require('../server/matchmaking');

const players=n=>Array.from({length:n},(_,i)=>({id:'p'+(i+1),joinedAt:1000+i}));
const rank=t=>Number(t.id.slice(1));

test('بیشترین تعداد زمین با حداقل ۷ و حداکثر ۱۰ بازیکن واقعی',()=>{
 const expected=new Map([[7,[7]],[9,[9]],[10,[10]],[11,[10]],[13,[10]],[14,[7,7]],[18,[9,9]],[21,[7,7,7]],[27,[9,9,9]],[35,[7,7,7,7,7]],[43,[8,7,7,7,7,7]],[65,[8,8,7,7,7,7,7,7,7]]]);
 for(const[n,sizes]of expected){const groups=planMatches(players(n),rank,5000,{rankWindow:1000,relaxAfterMs:60000});assert.deepEqual(groups.map(g=>g.length),sizes,'P='+n);}
});

test('گروه‌ها پیوسته و نزدیک به رتبه‌اند؛ بازمانده در صف می‌ماند',()=>{
 const q=players(13);const groups=planMatches(q,rank,5000,{rankWindow:30});
 assert.equal(groups.length,1);assert.equal(groups[0].length,10);
 const indices=groups[0].map(t=>Number(t.id.slice(1))).sort((a,b)=>a-b);
 assert.equal(indices.at(-1)-indices[0],9);
});

test('بعد از ۶۰ ثانیه محدودیت فاصله رتبه باز می‌شود',()=>{
 const q=players(7),rankWide=t=>Number(t.id.slice(1))*100;
 assert.deepEqual(planMatches(q,rankWide,5000,{rankWindow:30,relaxAfterMs:60000}),[]);
 assert.equal(planMatches(q,rankWide,62000,{rankWindow:30,relaxAfterMs:60000}).length,1);
});


test('۶۰ ثانیه فقط محدودیت زمینِ شامل بازیکنِ منتظرِ قدیمی را باز می‌کند',()=>{
 const q=players(14);q.forEach((p,i)=>{p.joinedAt=i<7?1000:61000;});
 const wide=t=>Number(t.id.slice(1))*100;
 const groups=planMatches(q,wide,62000,{rankWindow:30,relaxAfterMs:60000});
 assert.equal(groups.length,1);
 const ids=groups[0].map(t=>Number(t.id.slice(1)));
 assert.ok([1,2,3,4,5,6,7].every(id=>ids.includes(id)));
 assert.ok(ids.every(id=>id<=10));
});
