'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const{createPlayerStore,keyOf,validToken,levelOf}=require('../server/players');
const{rewardOf}=require('../engine');

const tmp=()=>path.join(fs.mkdtempSync(path.join(os.tmpdir(),'ra-st-')),'players.json');

test('سطح و جام: هر ۵۰ جام یک سطح، جام زیر صفر نمی‌رود',()=>{
 assert.equal(levelOf(0),1);assert.equal(levelOf(49),1);assert.equal(levelOf(50),2);
 const s=createPlayerStore(tmp()),k=keyOf('a'.repeat(32));
 assert.equal(s.settle(k,1).delta,rewardOf(1,1));
 const low=createPlayerStore(tmp());
 assert.equal(low.settle(k,10).delta,0,'از صفر پایین‌تر نمی‌رود');
 assert.equal(low.get(k).tr,0);
});

test('با بالا رفتن سطح، همان رتبه جام کمتری می‌دهد (از روی سطح سرور)',()=>{
 const s=createPlayerStore(tmp()),k=keyOf('b'.repeat(32));
 const first=s.settle(k,3).delta;
 for(let i=0;i<20;i++)s.settle(k,1);
 assert.ok(s.get(k).level>1);
 const later=s.settle(k,3).delta;
 assert.ok(later<first,first+' → '+later);
 assert.equal(s.get(k).matches,22);
});

test('ماندگاری روی دیسک و فایل خراب',()=>{
 const f=tmp(),k=keyOf('c'.repeat(32));
 const a=createPlayerStore(f);a.profile(k,'  نیما  ','#112233');a.settle(k,2);
 const b=createPlayerStore(f);
 assert.deepEqual([b.get(k).name,b.get(k).color,b.get(k).tr],['نیما','#112233',rewardOf(2,1)]);
 fs.writeFileSync(f,'{not json');
 const c=createPlayerStore(f);assert.equal(c.get(k).tr,0);
 assert.ok(fs.readdirSync(path.dirname(f)).some(n=>n.startsWith('players.json.bad-')),'فایل خراب باید کنار گذاشته شود');
});

test('نام و رنگ نامعتبر نادیده گرفته می‌شوند؛ توکن نامعتبر رد می‌شود',()=>{
 const s=createPlayerStore(tmp()),k=keyOf('d'.repeat(32));
 const p=s.profile(k,'x'.repeat(40),'red');
 assert.equal(p.name.length,16);assert.equal(p.color,'#22d3ee');
 assert.equal(validToken('d'.repeat(32)),true);
 for(const t of['','zz','D'.repeat(32),'d'.repeat(31),null,5])assert.equal(validToken(t),false);
});
