const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const {createServer}=require('../server');
const publicDir=path.join(__dirname,'../public');
function harness(){
 const nodes={};const events={};const storage=new Map();const pending=[];
 const element=()=>({hidden:false,dataset:{},setAttribute(){},append(){},querySelector(selector){return nodes[selector]||(nodes[selector]=element());}});
 const document={head:element(),body:element(),hidden:false,createElement:element,addEventListener(k,f){events[k]=f;}};
 let media;
 class FakeAudio{constructor(){media=this;this.currentTime=0;this.paused=true;}pause(){this.paused=true;}play(){this.paused=false;if(this.rejected)return Promise.reject(Object.assign(new Error(),{name:'NotAllowedError'}));this.onplaying?.();return Promise.resolve();}}
 const window={TUTORIAL_CLIPS:{hello:{file:'hello.mp3',duration:4},next:{file:'next.mp3',duration:3}},addEventListener(){}};
 vm.runInNewContext(fs.readFileSync(path.join(publicDir,'tutorial-voice.js'),'utf8'),{window,document,Audio:FakeAudio,localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},setTimeout:f=>{pending.push(f);return pending.length;},clearTimeout(){}});
 return {voice:window.TutorialVoice,nodes,media,events,document,storage};
}
test('narration resolves on actual completion; replay keeps lesson waiting',async()=>{
 const {voice,nodes,media}=harness();let done=false;const p=voice.say('hello').then(x=>{done=true;return x;});
 assert.equal(voice.speaking,true);nodes['#tutorialVoiceReplay'].onclick();await Promise.resolve();assert.equal(done,false);
 media.onended();assert.equal(await p,'ended');assert.equal(voice.speaking,false);
});
test('new speech cancels previous audio, stale events cannot stop current speech',async()=>{
 const {voice,media}=harness();const old=voice.say('hello'),stale=media.onended;const current=voice.say('next');
 assert.equal(await old,'cancelled');stale();assert.equal(voice.speaking,true);media.onended();assert.equal(await current,'ended');
});
test('mute, replay, tab visibility and leaving the scene stop/resume correctly',async()=>{
 const {voice,nodes,media,events,document,storage}=harness();const p=voice.say('hello');
 document.hidden=true;events.visibilitychange();assert.equal(media.paused,true);
 document.hidden=false;events.visibilitychange();assert.equal(voice.speaking,true);
 nodes['#tutorialVoiceToggle'].onclick();assert.equal(await p,'muted');assert.equal(media.paused,true);assert.equal(storage.get('ra_tutorial_voice'),'off');
 assert.equal(await voice.say('next'),'muted');nodes['#tutorialVoiceReplay'].onclick();assert.equal(voice.speaking,true);
 voice.hide();assert.equal(media.paused,true);assert.equal(voice.speaking,false);
});
test('autoplay denial and missing clips do not leave promises hanging',async()=>{
 const {voice,media,nodes}=harness();media.rejected=true;assert.equal(await voice.say('hello'),'blocked');
 assert.match(nodes['#tutorialVoiceStatus'].textContent,/تکرار/);assert.equal(await voice.say('unknown'),'error');
});
test('all bundled narration assets and scripts are served with correct types',async()=>{
 const app=createServer();await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
 try{
  const context={window:{}};vm.runInNewContext(fs.readFileSync(path.join(publicDir,'tutorial-clips.js'),'utf8'),context);
  const clips=Object.values(context.window.TUTORIAL_CLIPS);assert.equal(clips.length,10);
  for(const clip of clips){const r=await fetch(base+'/'+clip.file);assert.equal(r.status,200);assert.equal(r.headers.get('content-type'),'audio/mpeg');assert.equal((await r.arrayBuffer()).byteLength,fs.statSync(path.join(publicDir,clip.file)).size);assert.ok(clip.duration>1);}
  for(const script of ['tutorial-clips.js','tutorial-voice.js']){const r=await fetch(base+'/'+script);assert.equal(r.status,200);assert.match(r.headers.get('content-type'),/javascript/);}
  const head=await fetch(base+'/'+clips[0].file,{method:'HEAD'});assert.equal(head.status,200);assert.equal(await head.text(),'');
  assert.equal((await fetch(base+'/audio/tutorial/missing.mp3')).status,404);
  assert.equal((await fetch(base+'/audio/tutorial/%2e%2e%2fserver.js')).status,404);
 }finally{app.stop();}
});
